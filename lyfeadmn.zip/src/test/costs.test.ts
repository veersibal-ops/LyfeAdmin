import { describe, expect, it } from "vitest";
import { monthlyCost, totals, yearlyCost } from "@/lib/costs";

describe("subscription cost estimates", () => {
  it("weekly subscriptions count 52 payments a year", () => {
    expect(yearlyCost(10, "weekly")).toBe(520);
  });
  it("yearly subscriptions are spread over 12 months", () => {
    expect(monthlyCost(120, "yearly")).toBe(10);
  });
  it("quarterly subscriptions count 4 payments a year", () => {
    expect(yearlyCost(30, "quarterly")).toBe(120);
  });
  it("paused subscriptions are excluded from totals", () => {
    expect(
      totals([
        { amount: 15, frequency: "monthly", active: true },
        { amount: 100, frequency: "monthly", active: false },
      ]),
    ).toEqual({ monthly: 15, yearly: 180 });
  });
});
