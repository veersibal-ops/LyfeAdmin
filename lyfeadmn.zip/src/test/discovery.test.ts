import { describe, expect, it } from "vitest";
import { extractedReceipt, mayRequestNotificationPermission, receiptInput } from "@/lib/discovery";
import { isPwaBlocked } from "@/lib/pwa";

describe("permission and discovery rules", () => {
  it("does not repeat requests after denial", () => expect(mayRequestNotificationPermission("denied", true, false)).toBe(false));
  it("does not request from a preview iframe", () => expect(mayRequestNotificationPermission("default", true, true)).toBe(false));
  it("requires explicit consent for the selected receipt", () => expect(receiptInput.safeParse({ name: "receipt.txt", type: "text/plain", data: "YQ==", consent: false }).success).toBe(false));
  it("preserves unknown renewal information", () => expect(extractedReceipt.parse({ name: "Example", amount: 10, currency: "AUD", frequency: null, next_renewal: null }).next_renewal).toBeNull());
  it("never registers the offline worker in numbered previews", () => expect(isPwaBlocked("preview-2--example.lovable.app", true, false, false)).toBe(true));
  it("permits offline worker on a published custom domain", () => expect(isPwaBlocked("lifeadmin.example.com", true, false, false)).toBe(false));
});