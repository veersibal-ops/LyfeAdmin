import { describe, it, expect } from "vitest";
import { assistantAction, assistantParts, decodeAssistant, encodeAssistant } from "@/lib/assistant";

describe("assistant proposals", () => {
  it("does not treat plain conversation text as an executable action", () => {
    expect(decodeAssistant('Create a reminder {"kind":"reminder"}').action).toBeUndefined();
  });
  it("requires a concrete dated reminder rather than an invented missing date", () => {
    expect(
      assistantAction.safeParse({
        kind: "reminder",
        title: "Dentist",
        description: "",
        due_at: "tomorrow",
      }).success,
    ).toBe(false);
    expect(
      assistantAction.parse({
        kind: "reminder",
        title: "Dentist",
        description: "",
        due_at: "2026-11-18T09:00:00+11:00",
      }),
    ).toMatchObject({ due_at: "2026-11-18T09:00:00+11:00" });
  });
  it("renders proposed changes as awaiting confirmation, not completed actions", () => {
    const content = encodeAssistant("Please review", {
      kind: "checklist",
      title: "Moving",
      items: ["Book movers"],
    });
    expect(assistantParts(content)[1]).toMatchObject({
      state: "approval-requested",
      input: { items: ["Book movers"] },
    });
  });
});
