import { describe, expect, it } from "vitest";
import { reminderStats, upcomingRenewals } from "@/lib/dashboard-stats";

const now = new Date(2026, 10, 17, 12, 0);
const at = (d: number, h: number) => new Date(2026, 10, d, h).toISOString();

describe("dashboard reminder stats", () => {
  const rs = [
    { id: "a", due_at: at(17, 9), completed: false }, // earlier today, not done
    { id: "b", due_at: at(17, 18), completed: true }, // later today, done
    { id: "c", due_at: at(15, 9), completed: false }, // two days ago
    { id: "d", due_at: at(14, 9), completed: true }, // past but done
    { id: "e", due_at: at(19, 9), completed: false }, // in two days
  ];
  const s = reminderStats(rs, now);
  it("due today counts every reminder dated today", () => {
    expect(s.today.map((r) => r.id)).toEqual(["a", "b"]);
    expect(s.todayDone).toBe(1);
  });
  it("overdue counts incomplete reminders whose time has passed", () => {
    expect(s.overdue.map((r) => r.id).sort()).toEqual(["a", "c"]);
  });
  it("lists each reminder once in the today panel", () => {
    expect(s.attention.map((r) => r.id)).toEqual(["a", "c", "b"]);
  });
  it("upcoming excludes today and completed", () => {
    expect(s.upcoming.map((r) => r.id)).toEqual(["e"]);
  });
});

describe("upcoming renewals", () => {
  it("shows active future renewals soonest first", () => {
    const subs = [
      { id: 1, active: true, next_renewal: "2026-12-01" },
      { id: 2, active: true, next_renewal: "2026-11-20" },
      { id: 3, active: false, next_renewal: "2026-11-18" },
      { id: 4, active: true, next_renewal: "2026-11-10" },
    ];
    expect(upcomingRenewals(subs, now).map((x) => x.id)).toEqual([2, 1]);
  });
});
