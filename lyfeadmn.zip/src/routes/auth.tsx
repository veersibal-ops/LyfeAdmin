import { createFileRoute, useNavigate } from "@tanstack/react-router";
import type { Errs } from "@/lib/form";
import { useEffect, useState, type FormEvent } from "react";
import { Loader2, MailCheck } from "lucide-react";
import { toast } from "sonner";
import { z } from "zod";
import { LovableMark } from "@lovable.dev/cloud-auth-js/react";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Logo } from "@/components/app/logo";
import { WEBSITE_URL, WEBSITE_LINKS } from "@/lib/website";

type Mode = "signin" | "signup" | "forgot";

export const Route = createFileRoute("/auth")({
  validateSearch: (
    s: Record<string, unknown>,
  ): { mode?: Mode | undefined; redirect?: string | undefined } => ({
    mode:
      s["mode"] === "signup" || s["mode"] === "forgot"
        ? s["mode"]
        : s["mode"] === "signin"
          ? "signin"
          : undefined,
    redirect: typeof s["redirect"] === "string" ? s["redirect"] : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Sign in — LYFEADMIN" },
      { name: "description", content: "Sign in or create your LYFEADMIN account." },
      { property: "og:title", content: "Sign in — LYFEADMIN" },
      { property: "og:description", content: "Sign in or create your LYFEADMIN account." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AuthPage,
});

const emailSchema = z.string().trim().email("Enter a valid email address").max(255);
const passwordSchema = z.string().min(8, "Password must be at least 8 characters").max(72);

function safePath(p?: string) {
  if (!p) return "/dashboard";
  try {
    const u = new URL(p, window.location.origin);
    return u.origin === window.location.origin ? u.pathname + u.search : "/dashboard";
  } catch {
    return "/dashboard";
  }
}

function GoogleG() {
  return (
    <svg aria-hidden="true" viewBox="0 0 24 24" className="size-[18px]">
      <path
        fill="#4285F4"
        d="M23.49 12.27c0-.79-.07-1.54-.19-2.27H12v4.51h6.47c-.29 1.48-1.14 2.73-2.4 3.58v3h3.86c2.26-2.09 3.56-5.17 3.56-8.82z"
      />
      <path
        fill="#34A853"
        d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.86-3c-1.08.72-2.45 1.16-4.07 1.16-3.13 0-5.78-2.11-6.73-4.96H1.29v3.09C3.26 21.3 7.31 24 12 24z"
      />
      <path
        fill="#FBBC05"
        d="M5.27 14.29c-.25-.72-.38-1.49-.38-2.29s.14-1.57.38-2.29V6.62H1.29C.47 8.24 0 10.06 0 12s.47 3.76 1.29 5.38l3.98-3.09z"
      />
      <path
        fill="#EA4335"
        d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.31 0 3.26 2.7 1.29 6.62l3.98 3.09c.95-2.85 3.6-4.96 6.73-4.96z"
      />
    </svg>
  );
}

function AuthPage() {
  const search = Route.useSearch();
  const navigate = useNavigate();
  const [mode, setMode] = useState<Mode>(search.mode ?? "signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState<null | "confirm" | "reset">(null);
  const [errors, setErrors] = useState<Errs>({});

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) navigate({ href: safePath(search.redirect), replace: true });
    });
  }, [navigate, search.redirect]);

  async function submit(e: FormEvent) {
    e.preventDefault();
    const errs: Errs = {};
    const em = emailSchema.safeParse(email);
    if (!em.success) errs.email = em.error.issues[0]?.message ?? "Invalid email";
    if (mode !== "forgot") {
      const pw = passwordSchema.safeParse(password);
      if (!pw.success) errs.password = pw.error.issues[0]?.message ?? "Invalid password";
    }
    if (mode === "signup" && !name.trim()) errs.name = "Tell us your name";
    setErrors(errs);
    if (Object.keys(errs).length) return;

    setBusy(true);
    try {
      if (mode === "signin") {
        const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
        if (error) throw error;
        navigate({ href: safePath(search.redirect), replace: true });
      } else if (mode === "signup") {
        const { data, error } = await supabase.auth.signUp({
          email: email.trim(),
          password,
          options: {
            emailRedirectTo: window.location.origin + "/onboarding",
            data: { full_name: name.trim() },
          },
        });
        if (error) throw error;
        if (data.session) navigate({ to: "/onboarding", replace: true });
        else setSent("confirm");
      } else {
        const { error } = await supabase.auth.resetPasswordForEmail(email.trim(), {
          redirectTo: `${window.location.origin}/reset-password`,
        });
        if (error) throw error;
        setSent("reset");
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setBusy(false);
    }
  }

  async function social(provider: "google" | "lovable") {
    const result = await lovable.auth.signInWithOAuth(provider, {
      redirect_uri: window.location.origin + "/auth",
    });
    if (result.error) {
      toast.error(result.error.message ?? "Sign-in failed");
      return;
    }
    if (result.redirected) return;
    navigate({ href: safePath(search.redirect), replace: true });
  }

  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <div className="relative hidden flex-col justify-between bg-hero p-12 text-navy-foreground lg:flex xl:p-20">
        <a href={WEBSITE_URL} target="_blank" rel="noreferrer" title="Visit the LYFEADMIN website">
          <Logo artwork="full" showText={false} />
        </a>
        <div>
          <h2 className="text-5xl font-bold leading-tight">
            Everything in life.
            <br />
            Organised.
          </h2>
          <p className="mt-4 max-w-sm text-navy-foreground/75">
            Your reminders, documents, subscriptions and checklists — private to you, and only you.
          </p>
        </div>
        <p className="text-xs text-navy-foreground/60">
          Your data is protected with per-account access controls.
        </p>
      </div>

      <div className="flex items-center justify-center bg-card px-6 py-10 sm:px-10">
        <div className="w-full max-w-md animate-rise">
          <a
            href={WEBSITE_URL}
            target="_blank"
            rel="noreferrer"
            title="Visit the LYFEADMIN website"
            className="mb-8 inline-block"
          >
            <Logo artwork="full" showText={false} />
          </a>
          {sent ? (
            <div className="card-surface p-6 text-center">
              <MailCheck className="mx-auto mb-3 size-10 text-brand-ink" />
              <h1 className="text-xl font-bold">Check your email</h1>
              <p className="mt-2 text-sm text-muted-foreground">
                {sent === "confirm"
                  ? `We sent a confirmation link to ${email}. Open it to activate your account.`
                  : `If an account exists for ${email}, you'll receive a link to reset your password.`}
              </p>
              <Button
                variant="outline"
                className="mt-5 w-full"
                onClick={() => {
                  setSent(null);
                  setMode("signin");
                }}
              >
                Back to sign in
              </Button>
            </div>
          ) : (
            <>
              <h1 className="text-3xl font-bold">
                {mode === "signin"
                  ? "Welcome back"
                  : mode === "signup"
                    ? "Create your account"
                    : "Reset your password"}
              </h1>
              <p className="mt-3 text-base text-muted-foreground">
                {mode === "signin"
                  ? "Sign in to continue to LYFEADMIN."
                  : mode === "signup"
                    ? "It takes less than a minute."
                    : "We'll email you a reset link."}
              </p>

              {mode !== "forgot" && (
                <div className="mt-6 grid gap-2">
                  <Button
                    type="button"
                    variant="outline"
                    size="lg"
                    onClick={() => social("google")}
                  >
                    <GoogleG /> Continue with Google
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    size="lg"
                    onClick={() => social("lovable")}
                  >
                    <LovableMark className="size-[18px]" /> Continue with Lovable
                  </Button>
                  <div className="my-2 flex items-center gap-3 text-xs text-muted-foreground">
                    <span className="h-px flex-1 bg-border" /> or with email{" "}
                    <span className="h-px flex-1 bg-border" />
                  </div>
                </div>
              )}

              <form onSubmit={submit} className="mt-4 space-y-4" noValidate>
                {mode === "signup" && (
                  <Field label="Your name" error={errors.name}>
                    <Input
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      autoComplete="name"
                      className="h-11"
                      maxLength={100}
                    />
                  </Field>
                )}
                <Field label="Email" error={errors.email}>
                  <Input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    autoComplete="email"
                    className="h-11"
                  />
                </Field>
                {mode !== "forgot" && (
                  <Field
                    label="Password"
                    error={errors.password}
                    extra={
                      mode === "signin" && (
                        <button
                          type="button"
                          onClick={() => setMode("forgot")}
                          className="text-xs font-semibold text-brand-ink hover:underline"
                        >
                          Forgot password?
                        </button>
                      )
                    }
                  >
                    <Input
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      autoComplete={mode === "signup" ? "new-password" : "current-password"}
                      className="h-11"
                    />
                  </Field>
                )}
                <Button type="submit" variant="brand" size="lg" className="w-full" disabled={busy}>
                  {busy && <Loader2 className="animate-spin" />}
                  {mode === "signin"
                    ? "Sign in"
                    : mode === "signup"
                      ? "Create account"
                      : "Send reset link"}
                </Button>
              </form>

              <p className="mt-6 text-center text-sm text-muted-foreground">
                {mode === "signup" ? (
                  <>
                    Already have an account?{" "}
                    <button
                      className="font-semibold text-brand-ink hover:underline"
                      onClick={() => setMode("signin")}
                    >
                      Sign in
                    </button>
                  </>
                ) : mode === "signin" ? (
                  <>
                    New to LYFEADMIN?{" "}
                    <button
                      className="font-semibold text-brand-ink hover:underline"
                      onClick={() => setMode("signup")}
                    >
                      Create an account
                    </button>
                  </>
                ) : (
                  <button
                    className="font-semibold text-brand-ink hover:underline"
                    onClick={() => setMode("signin")}
                  >
                    Back to sign in
                  </button>
                )}
              </p>
            </>
          )}
          <nav
            aria-label="LYFEADMIN website"
            className="mt-8 flex flex-wrap justify-center gap-x-4 gap-y-1 text-xs text-muted-foreground"
          >
            {WEBSITE_LINKS.map((l) => (
              <a
                key={l.href}
                href={l.href}
                target="_blank"
                rel="noreferrer"
                className="hover:text-brand-ink hover:underline"
              >
                {l.label}
              </a>
            ))}
          </nav>
        </div>
      </div>
    </div>
  );
}

function Field({
  label,
  error,
  children,
  extra,
}: {
  label: string;
  error?: string | undefined;
  children: React.ReactNode;
  extra?: React.ReactNode;
}) {
  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between">
        <Label>{label}</Label>
        {extra}
      </div>
      {children}
      {error && <p className="text-xs font-medium text-destructive">{error}</p>}
    </div>
  );
}
