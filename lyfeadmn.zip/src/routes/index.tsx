import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import {
  Bell,
  FolderLock,
  CreditCard,
  ListChecks,
  MessageCircle,
  ShieldCheck,
  ArrowRight,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Logo } from "@/components/app/logo";
import { WEBSITE_LINKS } from "@/lib/website";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Welcome to LYFEADMIN — Everything in life. Organised." },
      {
        name: "description",
        content:
          "Sign in to LYFEADMIN to manage reminders, documents, subscriptions, checklists and your AI assistant.",
      },
      { property: "og:title", content: "Welcome to LYFEADMIN" },
      {
        property: "og:description",
        content:
          "Everything in life. Organised. Reminders, documents, subscriptions and checklists in one private place.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Welcome,
});

const FEATURES = [
  {
    icon: Bell,
    title: "Reminders",
    text: "Appointments, bills and important dates — never missed.",
  },
  {
    icon: FolderLock,
    title: "Document vault",
    text: "Receipts, warranties and personal files, stored privately.",
  },
  {
    icon: CreditCard,
    title: "Subscriptions",
    text: "See what you pay each month and what renews next.",
  },
  {
    icon: ListChecks,
    title: "Smart checklists",
    text: "Templates for shopping, holidays, moving and more.",
  },
  {
    icon: MessageCircle,
    title: "AI assistant",
    text: "Break down big tasks and plan your week in seconds.",
  },
];

function Welcome() {
  const navigate = useNavigate();
  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) navigate({ to: "/dashboard", replace: true });
    });
  }, [navigate]);

  return (
    <div className="min-h-screen bg-hero text-navy-foreground">
      <div className="mx-auto flex min-h-screen max-w-6xl flex-col px-5 py-6 sm:px-8">
        <header className="flex items-center justify-between">
          <Logo />
          <Button asChild variant="hero-ghost" size="sm">
            <Link to="/auth" search={{ mode: "signin" }}>
              Log in
            </Link>
          </Button>
        </header>

        <main className="grid flex-1 items-center gap-10 py-12 lg:grid-cols-[1.1fr_1fr]">
          <div className="animate-rise">
            <p className="mb-4 inline-flex items-center gap-2 rounded-full bg-navy-foreground/10 px-3 py-1 text-xs font-semibold">
              <ShieldCheck className="size-3.5" /> Private by design
            </p>
            <h1 className="text-4xl font-bold leading-[1.05] sm:text-6xl">
              Everything in life.
              <br />
              Organised.
            </h1>
            <p className="mt-5 max-w-md text-base text-navy-foreground/75 sm:text-lg">
              LYFEADMIN brings your reminders, documents, subscriptions and checklists into one
              calm, private space — with an AI assistant to help you plan.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button asChild variant="hero" size="xl">
                <Link to="/auth" search={{ mode: "signup" }}>
                  Get started <ArrowRight />
                </Link>
              </Button>
              <Button asChild variant="hero-ghost" size="xl">
                <Link to="/auth" search={{ mode: "signin" }}>
                  I have an account
                </Link>
              </Button>
            </div>
          </div>

          <div className="grid gap-3 sm:grid-cols-2">
            {FEATURES.map((f, i) => (
              <div
                key={f.title}
                className="rounded-2xl border border-navy-foreground/10 bg-navy-foreground/[0.06] p-5 backdrop-blur animate-rise"
                style={{ animationDelay: `${120 + i * 70}ms` }}
              >
                <f.icon className="mb-3 size-6" />
                <h3 className="font-semibold">{f.title}</h3>
                <p className="mt-1 text-sm text-navy-foreground/70">{f.text}</p>
              </div>
            ))}
          </div>
        </main>

        <footer className="flex flex-wrap justify-center gap-x-5 gap-y-1 pb-2 text-xs text-navy-foreground/60">
          {WEBSITE_LINKS.map((l) => (
            <a
              key={l.href}
              href={l.href}
              target="_blank"
              rel="noreferrer"
              className="hover:text-navy-foreground hover:underline"
            >
              {l.label}
            </a>
          ))}
        </footer>
      </div>
    </div>
  );
}
