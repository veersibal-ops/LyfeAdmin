import { createFileRoute, Outlet, redirect } from "@tanstack/react-router";
import { AppShell } from "@/components/app/app-shell";
import { profileQuery } from "@/hooks/use-data";

export const Route = createFileRoute("/_authenticated/_shell")({
  // Cached profile lookup: re-querying on every navigation left the old page on
  // screen (with the new sidebar item highlighted) until the request finished.
  beforeLoad: async ({ context }) => {
    const profile = await context.queryClient.ensureQueryData(profileQuery);
    if (!profile?.onboarded) throw redirect({ to: "/onboarding" });
  },
  component: () => (
    <AppShell>
      <Outlet />
    </AppShell>
  ),
});
