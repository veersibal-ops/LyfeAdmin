import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import {
  Bell,
  FolderLock,
  CreditCard,
  ListChecks,
  MessageCircle,
  Check,
  ArrowRight,
  ArrowLeft,
  Loader2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Logo } from "@/components/app/logo";
import { useProfile, useUpdateProfile } from "@/hooks/use-data";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/onboarding")({
  head: () => ({
    meta: [
      { title: "Welcome — LYFEADMIN" },
      { name: "description", content: "Set up your LYFEADMIN account." },
      { property: "og:title", content: "Welcome \u2014 LYFEADMIN" },
      { property: "og:description", content: "Set up your LYFEADMIN account." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Onboarding,
});

const FOCUS = [
  { id: "reminders", label: "Staying on top of reminders", icon: Bell },
  { id: "documents", label: "Organising documents", icon: FolderLock },
  { id: "subscriptions", label: "Tracking subscriptions", icon: CreditCard },
  { id: "checklists", label: "Checklists & routines", icon: ListChecks },
  { id: "assistant", label: "Planning with AI", icon: MessageCircle },
];

function Onboarding() {
  const navigate = useNavigate();
  const { data: profile } = useProfile();
  const update = useUpdateProfile();
  const [step, setStep] = useState(0);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [focus, setFocus] = useState<string[]>([]);
  const [push, setPush] = useState(false);
  const [nameError, setNameError] = useState("");

  useEffect(() => {
    if (profile) {
      setName((n) => n || profile.full_name || "");
      setFocus((f) => (f.length ? f : profile.focus_areas));
    }
  }, [profile]);

  async function finish() {
    await update.mutateAsync({
      full_name: name.trim(),
      phone: phone.trim() || null,
      focus_areas: focus,
      notify_push: push,
      timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      onboarded: true,
    });
    navigate({ to: "/dashboard", replace: true });
  }

  const next = () => {
    if (step === 1 && !name.trim()) {
      setNameError("Please enter your name");
      return;
    }
    setNameError("");
    setStep((s) => s + 1);
  };

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <header className="mx-auto flex w-full max-w-xl items-center justify-between px-5 py-6">
        <Logo artwork="full" showText={false} />
        <div className="flex gap-1.5" aria-label={`Step ${step + 1} of 3`}>
          {[0, 1, 2].map((i) => (
            <span
              key={i}
              className={cn(
                "h-1.5 rounded-full transition-all duration-500",
                i <= step ? "w-8 bg-brand" : "w-4 bg-border",
              )}
            />
          ))}
        </div>
      </header>

      <main className="mx-auto w-full max-w-xl flex-1 px-5 pb-10">
        <div key={step} className="animate-rise">
          {step === 0 && (
            <>
              <h1 className="text-3xl font-bold">Welcome to LYFEADMIN</h1>
              <p className="mt-2 text-muted-foreground">
                Everything in life. Organised. Here's what you can do:
              </p>
              <div className="mt-6 space-y-3">
                {FOCUS.map((f) => (
                  <div key={f.id} className="card-surface flex items-center gap-3 p-4">
                    <div className="grid size-10 place-items-center rounded-xl bg-brand-soft text-brand-ink">
                      <f.icon className="size-5" />
                    </div>
                    <span className="font-medium">
                      {f.label
                        .replace("Staying on top of", "Never miss")
                        .replace("Organising", "Store & find")}
                    </span>
                  </div>
                ))}
              </div>
            </>
          )}
          {step === 1 && (
            <>
              <h1 className="text-3xl font-bold">Set up your profile</h1>
              <p className="mt-2 text-muted-foreground">This helps personalise your dashboard.</p>
              <div className="mt-6 space-y-4">
                <div className="space-y-1.5">
                  <Label htmlFor="ob-name">Your name</Label>
                  <Input
                    id="ob-name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    maxLength={100}
                    className="h-11"
                  />
                  {nameError && <p className="text-xs font-medium text-destructive">{nameError}</p>}
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="ob-phone">Mobile (optional)</Label>
                  <Input
                    id="ob-phone"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    maxLength={30}
                    inputMode="tel"
                    className="h-11"
                  />
                </div>
              </div>
            </>
          )}
          {step === 2 && (
            <>
              <h1 className="text-3xl font-bold">What matters most?</h1>
              <p className="mt-2 text-muted-foreground">
                Pick anything you'd like help organising.
              </p>
              <div className="mt-6 grid gap-2">
                {FOCUS.map((f) => {
                  const on = focus.includes(f.id);
                  return (
                    <button
                      key={f.id}
                      type="button"
                      onClick={() =>
                        setFocus((x) => (on ? x.filter((i) => i !== f.id) : [...x, f.id]))
                      }
                      className={cn(
                        "flex items-center gap-3 rounded-2xl border-2 p-4 text-left transition-all",
                        on
                          ? "border-brand-ink bg-brand-soft"
                          : "border-border bg-card hover:border-brand-ink/40",
                      )}
                    >
                      <f.icon className="size-5 text-brand-ink" />
                      <span className="flex-1 font-medium">{f.label}</span>
                      <span
                        className={cn(
                          "grid size-6 place-items-center rounded-full border-2 transition-colors",
                          on ? "border-brand-ink bg-brand text-brand-foreground" : "border-border",
                        )}
                      >
                        {on && <Check className="size-3.5" />}
                      </span>
                    </button>
                  );
                })}
              </div>
              <div className="card-surface mt-4 grid gap-4 p-5 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-center">
                <div>
                  <p className="font-medium">Reminder notifications</p>
                  <p className="text-sm text-muted-foreground">
                    Optional alerts on this device while LYFEADMIN is open. Background push is not
                    configured. You can enable alerts now or later in Settings.
                  </p>
                </div>
                <Button
                  variant="outline"
                  disabled={push}
                  onClick={async () => {
                    if (typeof Notification === "undefined") {
                      toast.error("This browser does not support notifications.");
                      return;
                    }
                    if (window.top !== window.self) {
                      toast.error("Open LYFEADMIN in its own tab to enable notifications.");
                      return;
                    }
                    if (Notification.permission === "denied") {
                      toast.error("Notifications are blocked in this browser’s site settings.");
                      return;
                    }
                    const permission =
                      Notification.permission === "granted"
                        ? "granted"
                        : await Notification.requestPermission();
                    setPush(permission === "granted");
                    if (permission !== "granted")
                      toast.error(
                        "Notifications were not enabled. You can manage them in Settings.",
                      );
                  }}
                >
                  {push ? "Notifications enabled" : "Enable Notifications"}
                </Button>
              </div>
            </>
          )}
        </div>

        <div className="mt-8 flex gap-3">
          {step > 0 && (
            <Button variant="outline" size="lg" onClick={() => setStep((s) => s - 1)}>
              <ArrowLeft /> Back
            </Button>
          )}
          {step < 2 ? (
            <Button variant="brand" size="lg" className="flex-1" onClick={next}>
              Continue <ArrowRight />
            </Button>
          ) : (
            <Button
              variant="brand"
              size="lg"
              className="flex-1"
              onClick={finish}
              disabled={update.isPending}
            >
              {update.isPending && <Loader2 className="animate-spin" />} Enter my dashboard
            </Button>
          )}
        </div>
      </main>
    </div>
  );
}
