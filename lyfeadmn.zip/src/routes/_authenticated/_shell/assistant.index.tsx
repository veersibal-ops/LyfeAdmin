import { createFileRoute } from "@tanstack/react-router";
import { Loader2, ArrowUpRight, MessageCircle, ShieldCheck } from "lucide-react";
import { Logo } from "@/components/app/logo";
import { Button } from "@/components/ui/button";
import { ThreadList, useNewThread } from "@/components/assistant/thread-list";
import { ASSISTANT_SUGGESTIONS } from "@/components/assistant/suggestions";
import { PageHeader } from "@/components/app/page";

export const Route = createFileRoute("/_authenticated/_shell/assistant/")({
  head: () => ({
    meta: [
      { title: "AI Assistant — LYFEADMIN" },
      { name: "description", content: "Plan, prioritise and organise with AI." },
      { property: "og:title", content: "AI Assistant \u2014 LYFEADMIN" },
      { property: "og:description", content: "Plan, prioritise and organise with AI." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AssistantHome,
});

function AssistantHome() {
  const create = useNewThread();
  return (
    <div>
      <PageHeader title="AI Assistant" description="A little support for a more organised life." />
      <div className="grid items-start gap-7 xl:grid-cols-[minmax(0,1fr)_300px]">
        <div className="min-w-0 space-y-7">
          <section className="welcome-band p-6 sm:p-9">
            <Logo showText={false} className="mb-5 [&_img]:size-12" />
            <h2 className="max-w-xl text-3xl font-bold leading-tight sm:text-4xl">
              Let's make life
              <br className="hidden sm:block" /> feel a little lighter.
            </h2>
            <p className="mt-4 max-w-lg text-base leading-relaxed text-navy-foreground/80">
              Plan your week, find a starting point, or turn that thing on your mind into a
              manageable list.
            </p>
            <Button
              variant="brand"
              size="lg"
              className="mt-6"
              onClick={() => create.mutate()}
              disabled={create.isPending}
            >
              {create.isPending ? <Loader2 className="animate-spin" /> : <MessageCircle />} Start a
              conversation <ArrowUpRight />
            </Button>
          </section>
          <section>
            <h2 className="mb-4 text-xl font-semibold">Where shall we start?</h2>
            <div className="grid gap-4 sm:grid-cols-2">
              {ASSISTANT_SUGGESTIONS.map((s) => (
                <Button
                  key={s.title}
                  variant="ghost"
                  disabled={create.isPending}
                  onClick={() => create.mutate(s.prompt)}
                  className="card-surface card-hover h-auto min-h-36 justify-start whitespace-normal p-5 text-left"
                >
                  <div className="flex w-full items-start gap-4">
                    <span
                      className={`grid size-11 shrink-0 place-items-center rounded-xl ${s.tone}`}
                    >
                      <s.icon className="size-5" />
                    </span>
                    <div className="min-w-0">
                      <p className="text-lg font-semibold">{s.title}</p>
                      <p className="mt-2 text-sm font-normal text-muted-foreground">
                        {s.description}
                      </p>
                    </div>
                    <ArrowUpRight className="ml-auto shrink-0 text-muted-foreground" />
                  </div>
                </Button>
              ))}
            </div>
          </section>
          <p className="flex items-start gap-2 text-sm text-muted-foreground">
            <ShieldCheck className="mt-0.5 size-4 shrink-0" />
            Your records stay private. Sharing saved information or document contents is always your
            choice.
          </p>
        </div>
        <aside className="min-w-0 rounded-xl border bg-card p-5 shadow-card">
          <ThreadList />
        </aside>
      </div>
    </div>
  );
}
