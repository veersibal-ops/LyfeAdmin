import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Search, Upload, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { PageHeader } from "@/components/app/page";
import { ConfirmDelete } from "@/components/app/confirm-dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { extractReceipt } from "@/lib/discovery.functions";
import type { Database } from "@/integrations/supabase/types";

type Suggestion = Database["public"]["Tables"]["subscription_suggestions"]["Row"];
export const Route = createFileRoute("/_authenticated/_shell/discovery")({
  head: () => ({ meta: [
    { title: "Subscription Discovery — LYFEADMIN" },
    { name: "description", content: "Review subscription details from receipts you choose to share." },
    { property: "og:title", content: "Subscription Discovery — LYFEADMIN" },
    { property: "og:description", content: "Discover and review potential subscriptions with your permission." },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" },
  ] }), component: DiscoveryPage,
});

function DiscoveryPage() {
  const qc = useQueryClient();
  const extract = useServerFn(extractReceipt);
  const [file, setFile] = useState<File | null>(null);
  const [consent, setConsent] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const { data, error: loadError } = useQuery({ queryKey: ["suggestions"], queryFn: async () => {
    const r = await supabase.from("subscription_suggestions").select("*").eq("status", "pending").order("created_at", { ascending: false });
    if (r.error) throw r.error; return r.data;
  } });
  async function read() {
    if (!file || !consent || busy) return;
    setBusy(true); setError("");
    try {
      if (file.size > 5_000_000) throw new Error("Choose a file smaller than 5 MB.");
      const dataUrl = await new Promise<string>((resolve, reject) => { const r = new FileReader(); r.onload = () => resolve(String(r.result)); r.onerror = () => reject(new Error("Couldn't read this file")); r.readAsDataURL(file); });
      await extract({ data: { name: file.name, type: file.type, data: dataUrl.split(",")[1], consent: true } });
      await qc.invalidateQueries({ queryKey: ["suggestions"] }); toast.success("Receipt ready for your review");
    } catch (e) { setError(e instanceof Error ? e.message : "Couldn't read this receipt"); }
    finally { setBusy(false); }
  }
  return <>
    <PageHeader title="Subscription Discovery" description="Review potential subscriptions before adding them." />
    <section className="mb-6 space-y-4 border-b pb-6">
      <h2 className="flex items-center gap-2 font-semibold"><Upload className="size-5 text-brand-ink" /> Receipt or invoice</h2>
      <p className="max-w-2xl text-sm text-muted-foreground">Only the file you select is read. PDF, PNG, JPEG or text, up to 5 MB. Receipt reading uses LYFEADMIN’s AI service; the original file is not stored. Extracted details stay private in your account until you remove them.</p>
      <Input type="file" accept="application/pdf,image/png,image/jpeg,text/plain" aria-label="Subscription receipt" onChange={e => { setFile(e.target.files?.[0] ?? null); setConsent(false); setError(""); }} />
      <Label className="flex items-start gap-3"><Checkbox checked={consent} onCheckedChange={v => setConsent(v === true)} /> I agree to send this selected file to LYFEADMIN’s AI service for receipt reading.</Label>
      <Button variant="brand" onClick={read} disabled={!file || !consent || busy}>{busy ? <Loader2 className="animate-spin" /> : <Search />} {busy ? "Reading receipt…" : "Read selected receipt"}</Button>
      {error && <p role="alert" className="text-sm text-destructive">{error}</p>}
    </section>
    <section className="mb-6 border-b pb-6"><h2 className="font-semibold">Email discovery</h2><p className="mt-2 text-sm text-muted-foreground">Not available: an email provider has not been configured. LYFEADMIN has no access to your email accounts.</p></section>
    <div className="mb-4 grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3"><h2 className="min-w-0 font-semibold">Review suggestions</h2><ConfirmDelete title="Delete discovery data?" description="This removes your extracted receipt suggestions, including review history. Subscriptions you approved are kept." onConfirm={async () => { const r = await supabase.from("subscription_suggestions").delete().not("id", "is", null); if (r.error) toast.error(r.error.message); else { qc.invalidateQueries({ queryKey: ["suggestions"] }); toast.success("Discovery data deleted. Approved subscriptions are unchanged."); } }} trigger={<Button variant="outline">Delete discovery data</Button>} /></div>
    {loadError && <p className="text-destructive">Couldn't load suggestions.</p>}
    {data?.length === 0 && <p className="text-sm text-muted-foreground">No suggestions waiting for review.</p>}
    <div className="space-y-4">{data?.map(s => <Review key={s.id} suggestion={s} />)}</div>
  </>;
}

function Review({ suggestion: s }: { suggestion: Suggestion }) {
  const qc = useQueryClient();
  const [name, setName] = useState(s.name ?? "");
  const [amount, setAmount] = useState(s.amount === null ? "" : String(s.amount));
  const [currency, setCurrency] = useState(s.currency ?? "");
  const [frequency, setFrequency] = useState(s.frequency ?? "");
  const [date, setDate] = useState(s.next_renewal ?? "");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  async function save(approve: boolean) {
    if (busy) return;
    setBusy(true); setError("");
    try {
      if (approve) {
        if (!name.trim() || amount === "" || !Number.isFinite(Number(amount)) || Number(amount) < 0 || Number(amount) > 1_000_000 || !frequency || !/^[A-Z]{3}$/.test(currency) || !z.string().date().safeParse(date).success) throw new Error("Confirm a name, valid amount, currency, billing frequency and renewal date.");
        new Intl.NumberFormat(undefined, { style: "currency", currency });
        const r = await supabase.rpc("approve_subscription_suggestion", { suggestion_id: s.id, approved_name: name.trim(), approved_amount: Number(amount), approved_currency: currency, approved_frequency: frequency, approved_renewal: date });
        if (r.error) throw r.error;
      } else { const r = await supabase.from("subscription_suggestions").update({ status: "rejected" }).eq("id", s.id); if (r.error) throw r.error; }
      await Promise.all([qc.invalidateQueries({ queryKey: ["suggestions"] }), qc.invalidateQueries({ queryKey: ["subscriptions"] }), qc.invalidateQueries({ queryKey: ["activity"] })]);
      toast.success(approve ? "Subscription approved and added" : "Suggestion rejected");
    } catch (e) { setError(e instanceof Error ? e.message : "Couldn't save your review"); } finally { setBusy(false); }
  }
  return <form className="card-surface space-y-4 p-5" onSubmit={e => { e.preventDefault(); save(true); }}>
    <p className="break-words text-xs text-muted-foreground">Source: {s.source_name} · Check every detail. Blank fields were not found.</p>
    <div className="grid gap-3 sm:grid-cols-2">
      <div><Label htmlFor={`${s.id}-name`}>Subscription name</Label><Input id={`${s.id}-name`} value={name} onChange={e => setName(e.target.value)} maxLength={120} /></div>
      <div><Label htmlFor={`${s.id}-amount`}>Amount</Label><Input id={`${s.id}-amount`} type="number" step="0.01" min="0" value={amount} onChange={e => setAmount(e.target.value)} /></div>
      <div><Label htmlFor={`${s.id}-currency`}>Currency</Label><Input id={`${s.id}-currency`} value={currency} onChange={e => setCurrency(e.target.value.toUpperCase())} placeholder="AUD" maxLength={3} /></div>
      <div><Label htmlFor={`${s.id}-frequency`}>Billing frequency</Label><Select value={frequency} onValueChange={setFrequency}><SelectTrigger id={`${s.id}-frequency`}><SelectValue placeholder="Confirm billing" /></SelectTrigger><SelectContent>{["weekly", "monthly", "quarterly", "yearly"].map(v => <SelectItem key={v} value={v}>{v}</SelectItem>)}</SelectContent></Select></div>
      <div><Label htmlFor={`${s.id}-date`}>Next renewal</Label><Input id={`${s.id}-date`} type="date" value={date} onChange={e => setDate(e.target.value)} /></div>
    </div>{error && <p role="alert" className="text-sm text-destructive">{error}</p>}
    <div className="flex flex-wrap gap-2"><Button type="submit" variant="brand" disabled={busy}>Approve & add</Button><Button type="button" variant="outline" disabled={busy} onClick={() => save(false)}>Reject</Button></div>
  </form>;
}