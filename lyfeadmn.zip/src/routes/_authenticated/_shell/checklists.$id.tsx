import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useRef, useState, type FormEvent } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  ArrowLeft,
  Check,
  Pencil,
  Plus,
  Trash2,
  Bookmark,
  RotateCcw,
  PartyPopper,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { ConfirmDelete } from "@/components/app/confirm-dialog";
import { IconTile, ListSkeleton } from "@/components/app/page";
import { CHECKLIST_CATEGORIES, findOpt } from "@/lib/constants";
import { supabase } from "@/integrations/supabase/client";
import { logActivity, unwrap, useAction, useChecklist, type ChecklistItem } from "@/hooks/use-data";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/_shell/checklists/$id")({
  head: () => ({
    meta: [{ title: "Checklist — LYFEADMIN" }, { name: "description", content: "Your checklist." },
      { property: "og:title", content: "Checklist \u2014 LYFEADMIN" },
      { property: "og:description", content: "Your checklist." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },],
  }),
  component: ChecklistDetail,
});

function ChecklistDetail() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const { data, isLoading, error } = useChecklist(id);
  const [newItem, setNewItem] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editText, setEditText] = useState("");
  const savingTpl = useRef(false);
  const [renaming, setRenaming] = useState<string | null>(null);
  const keys = [["checklist", id], ["checklists"]];

  const add = useAction(
    async (content: string) => {
      const pos = (data?.checklist_items.at(-1)?.position ?? -1) + 1;
      unwrap(
        await supabase
          .from("checklist_items")
          .insert({ checklist_id: id, content, position: pos })
          .select(),
      );
      await supabase
        .from("checklists")
        .update({ updated_at: new Date().toISOString() })
        .eq("id", id);
    },
    { keys },
  );
  const rename = useAction(
    async (title: string) => {
      unwrap(await supabase.from("checklists").update({ title }).eq("id", id).select());
      await logActivity("updated", "checklist", title, id);
    },
    { keys, success: "Checklist renamed" },
  );
  const update = useAction(
    async (v: {
      item: ChecklistItem;
      patch: Partial<Pick<ChecklistItem, "content" | "completed">>;
    }) => {
      unwrap(await supabase.from("checklist_items").update(v.patch).eq("id", v.item.id).select());
    },
    { keys },
  );
  const remove = useAction(
    async (item: ChecklistItem) => {
      unwrap(await supabase.from("checklist_items").delete().eq("id", item.id).select());
    },
    { keys, success: "Item removed" },
  );
  const delList = useAction(
    async () => {
      unwrap(await supabase.from("checklists").delete().eq("id", id).select());
      await logActivity("deleted", "checklist", data?.title ?? "Checklist");
    },
    { keys: [["checklists"]], success: "Checklist deleted" },
  );
  const saveTemplate = useAction(
    async () => {
      if (!data) return;
      const t = unwrap(
        await supabase
          .from("checklists")
          .insert({ title: data.title, category: data.category, is_template: true })
          .select()
          .single(),
      );
      if (data.checklist_items.length)
        unwrap(
          await supabase
            .from("checklist_items")
            .insert(
              data.checklist_items.map((i) => ({
                checklist_id: t.id,
                content: i.content,
                position: i.position,
              })),
            )
            .select(),
        );
      await logActivity("created", "template", data.title, t.id);
    },
    { keys: [["checklists"]], success: "Saved as a reusable template" },
  );
  const reset = useAction(
    async () => {
      unwrap(
        await supabase
          .from("checklist_items")
          .update({ completed: false })
          .eq("checklist_id", id)
          .select(),
      );
    },
    { keys, success: "All items reset" },
  );

  async function toggle(item: ChecklistItem) {
    // optimistic for a snappy feel
    qc.setQueryData(["checklist", id], (old: typeof data) =>
      old
        ? {
            ...old,
            checklist_items: old.checklist_items.map((i) =>
              i.id === item.id ? { ...i, completed: !i.completed } : i,
            ),
          }
        : old,
    );
    update.mutate(
      { item, patch: { completed: !item.completed } },
      {
        onSuccess: async () => {
          const items = data?.checklist_items ?? [];
          const willBeDone = items.every((i) => (i.id === item.id ? !item.completed : i.completed));
          if (willBeDone && items.length) {
            toast.success("Checklist complete! 🎉");
            await logActivity("completed", "checklist", data?.title ?? "Checklist", id);
            qc.invalidateQueries({ queryKey: ["activity"] });
          }
        },
      },
    );
  }

  function submitNew(e: FormEvent) {
    e.preventDefault();
    const v = newItem.trim();
    if (!v) return;
    if (v.length > 300) {
      toast.error("Keep items under 300 characters");
      return;
    }
    if (add.isPending) return;
    if (data?.checklist_items.some((i) => i.content.trim().toLowerCase() === v.toLowerCase())) {
      toast.error("That item is already on this list");
      return;
    }
    add.mutate(v, { onSuccess: () => setNewItem("") });
  }

  function saveEdit(item: ChecklistItem) {
    const v = editText.trim();
    if (!v) {
      toast.error("Item can't be empty");
      return;
    }
    update.mutate({ item, patch: { content: v } }, { onSuccess: () => setEditingId(null) });
  }

  if (isLoading) return <ListSkeleton />;
  if (error || !data)
    return (
      <div className="text-center">
        <p className="text-muted-foreground">{error?.message ?? "This checklist doesn't exist."}</p>
        <Button asChild variant="outline" className="mt-4">
          <Link to="/checklists">Back to checklists</Link>
        </Button>
      </div>
    );

  const c = findOpt(CHECKLIST_CATEGORIES, data.category);
  const total = data.checklist_items.length;
  const done = data.checklist_items.filter((i) => i.completed).length;
  const pct = total ? Math.round((done / total) * 100) : 0;

  return (
    <div className="mx-auto max-w-2xl">
      <Link
        to="/checklists"
        className="mb-4 inline-flex items-center gap-1 text-sm font-medium text-muted-foreground hover:text-foreground"
      >
        <ArrowLeft className="size-4" /> Checklists
      </Link>

      <div className="card-surface mb-4 p-5">
        <div className="flex items-start gap-3">
          <IconTile icon={c.icon} tone={c.tone} />
          <div className="min-w-0 flex-1">
            {renaming !== null ? (
              <form
                className="grid grid-cols-2 gap-2 sm:flex"
                onSubmit={(e) => {
                  e.preventDefault();
                  const v = renaming.trim();
                  if (!v) return void toast.error("Name can't be empty");
                  rename.mutate(v, { onSuccess: () => setRenaming(null) });
                }}
              >
                <Input
                  autoFocus
                  value={renaming}
                  maxLength={150}
                  onChange={(e) => setRenaming(e.target.value)}
                  aria-label="Checklist name"
                  className="col-span-2 min-w-0"
                />
                <Button type="submit" size="sm" variant="brand" disabled={rename.isPending}>
                  Save
                </Button>
                <Button type="button" size="sm" variant="ghost" onClick={() => setRenaming(null)}>
                  Cancel
                </Button>
              </form>
            ) : (
              <h1 className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-1 text-xl font-bold break-words sm:text-2xl">
                <span className="min-w-0 break-words">{data.title}</span>
                <Button
                  variant="ghost"
                  size="icon-xs"
                  aria-label="Rename checklist"
                  onClick={() => setRenaming(data.title)}
                >
                  <Pencil />
                </Button>
              </h1>
            )}
            <p className="text-sm text-muted-foreground">
              {c.label}
              {data.is_template && " · Template"}
            </p>
          </div>
          <div className="text-right">
            <p className="font-display text-2xl font-bold text-brand-ink">{pct}%</p>
            <p className="text-xs text-muted-foreground">
              {done}/{total}
            </p>
          </div>
        </div>
        <Progress value={pct} className="mt-4 h-2.5" />
        {pct === 100 && total > 0 && (
          <p className="mt-3 flex items-center gap-2 text-sm font-semibold text-success animate-rise">
            <PartyPopper className="size-4" /> All done — great work!
          </p>
        )}
        <div className="mt-4 flex flex-wrap gap-2">
          {!data.is_template && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                if (savingTpl.current) return;
                savingTpl.current = true;
                saveTemplate.mutate(undefined, { onSettled: () => (savingTpl.current = false) });
              }}
              disabled={saveTemplate.isPending}
            >
              <Bookmark /> Save as template
            </Button>
          )}
          <Button
            variant="outline"
            size="sm"
            onClick={() => reset.mutate(undefined)}
            disabled={!done}
          >
            <RotateCcw /> Reset
          </Button>
          <ConfirmDelete
            title="Delete this checklist?"
            description={`"${data.title}" and all its items will be deleted.`}
            onConfirm={() =>
              delList.mutate(undefined, { onSuccess: () => navigate({ to: "/checklists" }) })
            }
            trigger={
              <Button variant="ghost" size="sm" className="text-destructive">
                <Trash2 /> Delete
              </Button>
            }
          />
        </div>
      </div>

      <form onSubmit={submitNew} className="mb-3 flex gap-2">
        <Input
          value={newItem}
          onChange={(e) => setNewItem(e.target.value)}
          placeholder="Add an item…"
          className="h-11"
          aria-label="New item"
        />
        <Button
          type="submit"
          variant="brand"
          size="icon-lg"
          aria-label="Add item"
          disabled={add.isPending}
        >
          <Plus />
        </Button>
      </form>

      <ul className="space-y-2">
        {data.checklist_items.map((item) => (
          <li
            key={item.id}
            className={cn(
              "card-surface group flex items-center gap-3 p-3 transition-all",
              item.completed && "bg-muted",
            )}
          >
            <button
              onClick={() => toggle(item)}
              aria-label={item.completed ? "Mark incomplete" : "Mark complete"}
              className={cn(
                "grid size-7 shrink-0 place-items-center rounded-lg border-2 transition-all duration-200",
                item.completed
                  ? "scale-105 border-success bg-success text-success-foreground"
                  : "border-input hover:border-brand-ink",
              )}
            >
              {item.completed && <Check className="size-4 animate-rise" />}
            </button>
            {editingId === item.id ? (
              <form
                className="grid min-w-0 flex-1 grid-cols-2 gap-2 sm:flex"
                onSubmit={(e) => {
                  e.preventDefault();
                  saveEdit(item);
                }}
              >
                <Input
                  autoFocus
                  value={editText}
                  onChange={(e) => setEditText(e.target.value)}
                  className="col-span-2 h-9 min-w-0"
                  maxLength={300}
                />
                <Button type="submit" size="sm" variant="brand">
                  Save
                </Button>
                <Button type="button" size="sm" variant="ghost" onClick={() => setEditingId(null)}>
                  Cancel
                </Button>
              </form>
            ) : (
              <>
                <span
                  className={cn(
                    "min-w-0 flex-1 break-words transition-colors",
                    item.completed && "text-muted-foreground line-through",
                  )}
                >
                  {item.content}
                </span>
                <Button
                  variant="ghost"
                  size="icon-sm"
                  aria-label="Edit item"
                  onClick={() => {
                    setEditingId(item.id);
                    setEditText(item.content);
                  }}
                >
                  <Pencil />
                </Button>
                <Button
                  variant="ghost"
                  size="icon-sm"
                  aria-label="Remove item"
                  onClick={() => remove.mutate(item)}
                >
                  <Trash2 />
                </Button>
              </>
            )}
          </li>
        ))}
      </ul>
      {total === 0 && (
        <p className="mt-6 text-center text-sm text-muted-foreground">
          No items yet — add your first one above.
        </p>
      )}
    </div>
  );
}
