import { createFileRoute } from "@tanstack/react-router";
import type { Errs } from "@/lib/form";
import { useEffect, useMemo, useState, type FormEvent } from "react";
import { differenceInCalendarDays, format, parseISO } from "date-fns";
import {
  CreditCard,
  Loader2,
  Pencil,
  Plus,
  Trash2,
  CalendarClock,
  TrendingUp,
  Info,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  CategoryBadge,
  EmptyState,
  IconTile,
  ListSkeleton,
  PageHeader,
} from "@/components/app/page";
import { ConfirmDelete } from "@/components/app/confirm-dialog";
import {
  FREQUENCIES,
  SUBSCRIPTION_CATEGORIES,
  findOpt,
  type SubscriptionCategory,
} from "@/lib/constants";
import { formatMoney, monthlyCost, totals, type Frequency } from "@/lib/costs";
import { supabase } from "@/integrations/supabase/client";
import {
  logActivity,
  unwrap,
  useAction,
  useSubscriptions,
  type Subscription,
} from "@/hooks/use-data";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/_shell/subscriptions")({
  head: () => ({
    meta: [
      { title: "Subscriptions — LYFEADMIN" },
      { name: "description", content: "Track renewals and estimated monthly costs." },
      { property: "og:title", content: "Subscriptions \u2014 LYFEADMIN" },
      { property: "og:description", content: "Track renewals and estimated monthly costs." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: SubscriptionsPage,
});

function SubscriptionsPage() {
  const { data, isLoading, error } = useSubscriptions();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Subscription | null>(null);
  const subs = data ?? [];
  const t = totals(
    subs.map((s) => ({
      amount: Number(s.amount),
      frequency: s.frequency as Frequency,
      active: s.active,
    })),
  );
  const upcoming = subs.filter(
    (s) =>
      s.active &&
      differenceInCalendarDays(parseISO(s.next_renewal), new Date()) <= 30 &&
      differenceInCalendarDays(parseISO(s.next_renewal), new Date()) >= 0,
  );
  const byCat = useMemo(() => {
    const m = new Map<string, number>();
    for (const s of subs.filter((x) => x.active))
      m.set(
        s.category,
        (m.get(s.category) ?? 0) + monthlyCost(Number(s.amount), s.frequency as Frequency),
      );
    return [...m.entries()].sort((a, b) => b[1] - a[1]);
  }, [subs]);

  const del = useAction(
    async (s: Subscription) => {
      unwrap(await supabase.from("subscriptions").delete().eq("id", s.id).select());
      await logActivity("deleted", "subscription", s.name);
    },
    { keys: [["subscriptions"]], success: "Subscription removed" },
  );

  const openNew = () => {
    setEditing(null);
    setOpen(true);
  };

  return (
    <>
      <PageHeader
        title="Subscriptions"
        description="Everything you pay for regularly, entered by you."
        actions={
          <Button variant="brand" onClick={openNew}>
            <Plus /> Add subscription
          </Button>
        }
      />

      <div className="mb-6 grid gap-3 sm:grid-cols-3">
        <div className="rounded-2xl bg-hero p-5 text-navy-foreground shadow-lift">
          <p className="text-sm text-navy-foreground/70">Estimated per month</p>
          <p className="mt-1 font-display text-3xl font-bold">{formatMoney(t.monthly)}</p>
        </div>
        <div className="card-surface p-5">
          <p className="flex items-center gap-1.5 text-sm text-muted-foreground">
            <TrendingUp className="size-4" /> Per year
          </p>
          <p className="mt-1 font-display text-2xl font-bold">{formatMoney(t.yearly)}</p>
        </div>
        <div className="card-surface p-5">
          <p className="flex items-center gap-1.5 text-sm text-muted-foreground">
            <CalendarClock className="size-4" /> Renewing in 30 days
          </p>
          <p className="mt-1 font-display text-2xl font-bold">{upcoming.length}</p>
        </div>
      </div>

      {byCat.length > 0 && (
        <div className="card-surface mb-6 p-5">
          <h2 className="mb-3 text-sm font-semibold">Monthly spend by category</h2>
          <div className="flex h-3 overflow-hidden rounded-full bg-muted">
            {byCat.map(([c, v], i) => (
              <div
                key={c}
                style={{
                  width: `${(v / t.monthly) * 100}%`,
                  backgroundColor: `var(--chart-${(i % 5) + 1})`,
                }}
                className="transition-all duration-700"
              />
            ))}
          </div>
          <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1.5">
            {byCat.map(([c, v], i) => (
              <span key={c} className="flex items-center gap-1.5 text-xs">
                <span
                  className="size-2.5 rounded-full"
                  style={{ backgroundColor: `var(--chart-${(i % 5) + 1})` }}
                />
                {findOpt(SUBSCRIPTION_CATEGORIES, c).label}{" "}
                <span className="text-muted-foreground">{formatMoney(v)}</span>
              </span>
            ))}
          </div>
        </div>
      )}

      {isLoading ? (
        <ListSkeleton />
      ) : error ? (
        <p className="text-destructive">{error.message}</p>
      ) : subs.length === 0 ? (
        <EmptyState
          icon={CreditCard}
          title="No subscriptions yet"
          description="Add streaming, software, gym or utility payments to see what you spend each month."
          action={
            <Button variant="brand" onClick={openNew}>
              <Plus /> Add subscription
            </Button>
          }
        />
      ) : (
        <div className="space-y-2.5">
          {subs.map((s) => {
            const c = findOpt(SUBSCRIPTION_CATEGORIES, s.category);
            const days = differenceInCalendarDays(parseISO(s.next_renewal), new Date());
            return (
              <div
                key={s.id}
                className={cn(
                  "card-surface card-hover flex items-center gap-3 p-3.5",
                  !s.active && "opacity-60",
                )}
              >
                <IconTile icon={c.icon} tone={c.tone} />
                <div className="min-w-0 flex-1">
                  <p className="truncate font-semibold">{s.name}</p>
                  <div className="mt-0.5 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                    <CategoryBadge icon={c.icon} label={c.label} tone={c.tone} />
                    {s.active ? (
                      <span
                        className={cn(
                          days >= 0 && days <= 7 && "font-semibold text-warning",
                          days < 0 && "font-semibold text-destructive",
                        )}
                      >
                        {days < 0
                          ? "Renewal date passed"
                          : days === 0
                            ? "Renews today"
                            : `Renews ${format(parseISO(s.next_renewal), "d MMM")} · ${days}d`}
                      </span>
                    ) : (
                      <span>Paused</span>
                    )}
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-display font-bold">
                    {formatMoney(Number(s.amount), s.currency)}
                  </p>
                  <p className="text-xs capitalize text-muted-foreground">{s.frequency}</p>
                </div>
                <div className="flex flex-col sm:flex-row">
                  <Button
                    variant="ghost"
                    size="icon-sm"
                    aria-label="Edit"
                    onClick={() => {
                      setEditing(s);
                      setOpen(true);
                    }}
                  >
                    <Pencil />
                  </Button>
                  <ConfirmDelete
                    title="Remove this subscription?"
                    description={`"${s.name}" will be removed from your tracker.`}
                    onConfirm={() => del.mutate(s)}
                    trigger={
                      <Button variant="ghost" size="icon-sm" aria-label="Delete">
                        <Trash2 />
                      </Button>
                    }
                  />
                </div>
              </div>
            );
          })}
        </div>
      )}

      <p className="mt-6 flex items-center gap-1.5 text-xs text-muted-foreground">
        <Info className="size-3" /> LYFEADMIN never connects to your bank or charges you. Amounts
        are estimates from what you enter.
      </p>
      <SubscriptionDialog open={open} onOpenChange={setOpen} sub={editing} />
    </>
  );
}

function SubscriptionDialog({
  open,
  onOpenChange,
  sub,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  sub: Subscription | null;
}) {
  const [name, setName] = useState("");
  const [amount, setAmount] = useState("");
  const [frequency, setFrequency] = useState<Frequency>("monthly");
  const [date, setDate] = useState("");
  const [category, setCategory] = useState<SubscriptionCategory>("other");
  const [active, setActive] = useState(true);
  const [notes, setNotes] = useState("");
  const [errors, setErrors] = useState<Errs>({});

  useEffect(() => {
    if (!open) return;
    setName(sub?.name ?? "");
    setAmount(sub ? String(sub.amount) : "");
    setFrequency((sub?.frequency as Frequency) ?? "monthly");
    setDate(sub?.next_renewal ?? format(new Date(), "yyyy-MM-dd"));
    setCategory((sub?.category as SubscriptionCategory) ?? "other");
    setActive(sub?.active ?? true);
    setNotes(sub?.notes ?? "");
    setErrors({});
  }, [open, sub]);

  const save = useAction(
    async () => {
      const payload = {
        name: name.trim(),
        amount: Number(amount),
        frequency,
        next_renewal: date,
        category,
        active,
        notes: notes.trim() || null,
      };
      if (sub) {
        unwrap(
          await supabase.from("subscriptions").update(payload).eq("id", sub.id).select().single(),
        );
        await logActivity("updated", "subscription", payload.name, sub.id);
      } else {
        const r = unwrap(await supabase.from("subscriptions").insert(payload).select().single());
        await logActivity("created", "subscription", payload.name, r.id);
      }
    },
    { keys: [["subscriptions"]], success: sub ? "Subscription updated" : "Subscription added" },
  );

  function submit(e: FormEvent) {
    e.preventDefault();
    const errs: Errs = {};
    if (!name.trim()) errs.name = "Enter a name";
    const n = Number(amount);
    if (amount === "" || Number.isNaN(n) || n < 0) errs.amount = "Enter a valid amount";
    else if (n > 1_000_000) errs.amount = "That amount looks too large";
    if (!date) errs.date = "Pick the next renewal date";
    setErrors(errs);
    if (Object.keys(errs).length) return;
    save.mutate(undefined, { onSuccess: () => onOpenChange(false) });
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="rounded-2xl sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{sub ? "Edit subscription" : "Add subscription"}</DialogTitle>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-4" noValidate>
          <div className="space-y-1.5">
            <Label htmlFor="s-name">Name</Label>
            <Input
              id="s-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Netflix"
              maxLength={120}
            />
            {errors.name && <p className="text-xs text-destructive">{errors.name}</p>}
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="s-amount">Amount</Label>
              <Input
                id="s-amount"
                type="number"
                inputMode="decimal"
                step="0.01"
                min="0"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
              />
              {errors.amount && <p className="text-xs text-destructive">{errors.amount}</p>}
            </div>
            <div className="space-y-1.5">
              <Label>Billing</Label>
              <Select value={frequency} onValueChange={(v) => setFrequency(v as Frequency)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {FREQUENCIES.map((f) => (
                    <SelectItem key={f.value} value={f.value}>
                      {f.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="s-date">Next renewal</Label>
              <Input
                id="s-date"
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
              />
              {errors.date && <p className="text-xs text-destructive">{errors.date}</p>}
            </div>
            <div className="space-y-1.5">
              <Label>Category</Label>
              <Select
                value={category}
                onValueChange={(v) => setCategory(v as SubscriptionCategory)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {SUBSCRIPTION_CATEGORIES.map((c) => (
                    <SelectItem key={c.value} value={c.value}>
                      {c.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="s-notes">Notes (optional)</Label>
            <Textarea
              id="s-notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={2}
              maxLength={1000}
            />
          </div>
          <div className="flex items-center justify-between rounded-xl bg-muted p-3">
            <Label htmlFor="s-active">Active</Label>
            <Switch id="s-active" checked={active} onCheckedChange={setActive} />
          </div>
          <DialogFooter className="gap-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="brand" disabled={save.isPending}>
              {save.isPending && <Loader2 className="animate-spin" />}{" "}
              {sub ? "Save changes" : "Add"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
