import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState, type ReactNode } from "react";
import { differenceInCalendarDays, format, formatDistanceToNow, parseISO } from "date-fns";
import { reminderStats, upcomingRenewals } from "@/lib/dashboard-stats";
import {
  Bell,
  CalendarCheck,
  CreditCard,
  FolderLock,
  ListChecks,
  MessageCircle,
  Plus,
  Upload,
  AlertTriangle,
  CheckCircle2,
  PlusCircle,
  Pencil,
  Trash2,
  ArrowRight,
  FileText,
  CalendarDays,
  FolderOpen,
  History,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { IconTile } from "@/components/app/page";
import { ReminderDialog } from "@/components/reminders/reminder-dialog";
import { ReminderRow } from "@/components/reminders/reminder-row";
import { DocumentDialog } from "@/components/documents/document-dialog";
import { DOCUMENT_CATEGORIES, SUBSCRIPTION_CATEGORIES, findOpt } from "@/lib/constants";
import { formatMoney, totals, type Frequency } from "@/lib/costs";
import {
  useActivity,
  useChecklists,
  useDocuments,
  useProfile,
  useReminders,
  useSubscriptions,
} from "@/hooks/use-data";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/_shell/dashboard")({
  head: () => ({
    meta: [
      { title: "Dashboard — LYFEADMIN" },
      { name: "description", content: "Your day at a glance." },
      { property: "og:title", content: "Dashboard \u2014 LYFEADMIN" },
      { property: "og:description", content: "Your day at a glance." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Dashboard,
});

function greeting() {
  const h = new Date().getHours();
  return h < 12 ? "Good morning" : h < 18 ? "Good afternoon" : "Good evening";
}

function Dashboard() {
  const { data: profile } = useProfile();
  const { data: reminders = [], isLoading: rl } = useReminders();
  const { data: subs = [] } = useSubscriptions();
  const { data: docs = [] } = useDocuments();
  const { data: lists = [] } = useChecklists();
  const { data: activity = [] } = useActivity();
  const [remOpen, setRemOpen] = useState(false);
  const [docOpen, setDocOpen] = useState(false);

  const s = useMemo(() => {
    const { today, todayDone, overdue, upcoming, attention } = reminderStats(reminders);
    const renewals = upcomingRenewals(subs);
    const t = totals(
      subs.map((x) => ({
        amount: Number(x.amount),
        frequency: x.frequency as Frequency,
        active: x.active,
      })),
    );
    const items = lists.filter((l) => !l.is_template).flatMap((l) => l.checklist_items);
    const itemsDone = items.filter((i) => i.completed).length;
    const totalTasks = today.length + items.length;
    const doneTasks = todayDone + itemsDone;
    return {
      today,
      attention,
      overdue,
      upcoming,
      renewals,
      t,
      todayDone,
      items,
      itemsDone,
      pct: totalTasks ? Math.round((doneTasks / totalTasks) * 100) : 0,
    };
  }, [reminders, subs, lists]);

  const name = profile?.full_name?.split(" ")[0];

  return (
    <div className="dashboard space-y-7">
      {/* Hero */}
      <section className="welcome-band relative overflow-hidden px-6 py-8 text-navy-foreground sm:px-9 sm:py-10">
        <div className="relative z-10 grid gap-7 lg:grid-cols-[minmax(0,1fr)_auto] lg:items-center">
          <div className="min-w-0">
            <p className="flex items-center gap-2 text-sm font-medium text-navy-foreground/75">
              <CalendarDays className="size-4" />
              {format(new Date(), "EEEE, d MMMM yyyy")}
            </p>
            <h1 className="mt-3 text-3xl font-bold leading-tight sm:text-4xl xl:text-5xl">
              {greeting()}
              {name ? `, ${name}` : ""}
            </h1>
            <p className="mt-4 max-w-xl text-base leading-relaxed text-navy-foreground/80">
              {s.today.filter((r) => !r.completed && !s.overdue.includes(r)).length > 0
                ? `You have ${s.today.filter((r) => !r.completed && !s.overdue.includes(r)).length} more thing${s.today.filter((r) => !r.completed && !s.overdue.includes(r)).length === 1 ? "" : "s"} due today${s.overdue.length ? ` and ${s.overdue.length} overdue` : ""}.`
                : s.overdue.length
                  ? `Nothing due today, but ${s.overdue.length} item${s.overdue.length === 1 ? " is" : "s are"} overdue.`
                  : "You're all caught up for today. Enjoy it."}
            </p>
          </div>
          <ProgressRing pct={s.pct} />
        </div>
      </section>
      <div className="grid grid-cols-2 gap-2 sm:flex sm:flex-wrap">
        <Button variant="hero" onClick={() => setRemOpen(true)}>
          <Plus /> Add reminder
        </Button>
        <Button variant="hero-ghost" onClick={() => setDocOpen(true)}>
          <Upload /> Upload document
        </Button>
        <Button asChild variant="hero-ghost">
          <Link to="/subscriptions">
            <CreditCard /> Subscriptions
          </Link>
        </Button>
        <Button asChild variant="hero-ghost">
          <Link to="/checklists">
            <ListChecks /> Checklists
          </Link>
        </Button>
        <Button asChild variant="hero-ghost">
          <Link to="/assistant">
            <MessageCircle /> Ask assistant
          </Link>
        </Button>
      </div>

      {/* Stats */}
      <section className="grid grid-cols-2 gap-4 xl:grid-cols-4">
        <Stat
          i={0}
          icon={CalendarCheck}
          tone="bg-brand-soft text-brand-ink"
          tint="pink"
          label="Due today"
          to="/reminders"
          value={String(s.today.length)}
          detail={`${s.todayDone} completed`}
        />
        <Stat
          i={1}
          icon={AlertTriangle}
          tone="bg-danger-soft text-destructive"
          tint="rose"
          label="Overdue"
          to="/reminders"
          value={String(s.overdue.length)}
          detail="Need your attention"
        />
        <Stat
          i={2}
          icon={CreditCard}
          tone="bg-warning-soft text-warning"
          tint="peach"
          label="Subscriptions / mo"
          to="/subscriptions"
          value={formatMoney(s.t.monthly)}
          detail={`${subs.filter((x) => x.active).length} active subscriptions`}
        />
        <Stat
          i={3}
          icon={FolderLock}
          tone="bg-success-soft text-success"
          tint="cream"
          label="Documents stored"
          to="/documents"
          value={String(docs.length)}
          detail="Safely stored in your vault"
        />
      </section>

      <div className="grid gap-6 xl:grid-cols-[minmax(0,1.3fr)_minmax(0,1fr)]">
        <div className="space-y-6">
          <Panel
            icon={Bell}
            tint="pink"
            title="Today's reminders"
            description="Your priorities, including anything overdue."
            link={{ to: "/reminders", label: "View all" }}
          >
            {rl ? (
              <div className="h-16 animate-pulse rounded-xl bg-muted" />
            ) : s.attention.length === 0 ? (
              <Empty
                icon={CalendarCheck}
                text="You're all caught up"
                description="No reminders need your attention today."
                action={
                  <Button variant="outline" size="sm" onClick={() => setRemOpen(true)}>
                    <Plus /> Add reminder
                  </Button>
                }
              />
            ) : (
              <div className="space-y-2">
                {s.attention.map((r) => (
                  <ReminderRow key={r.id} r={r} compact />
                ))}
              </div>
            )}
          </Panel>
          <Panel
            icon={CalendarDays}
            tint="rose"
            title="Coming up this week"
            description="A little clarity for the days ahead."
            link={{ to: "/reminders", label: "View all" }}
          >
            {s.upcoming.length === 0 ? (
              <Empty
                icon={CalendarDays}
                text="A little room to breathe"
                description="No upcoming reminders this week."
                action={
                  <Button variant="outline" size="sm" onClick={() => setRemOpen(true)}>
                    <Plus /> Add reminder
                  </Button>
                }
              />
            ) : (
              <div className="space-y-2">
                {s.upcoming.map((r) => (
                  <ReminderRow key={r.id} r={r} compact />
                ))}
              </div>
            )}
          </Panel>
          <Panel
            icon={FolderOpen}
            tint="cream"
            title="Recently added documents"
            description="Your important files, all in one place."
            link={{ to: "/documents", label: "Open vault" }}
          >
            {docs.length === 0 ? (
              <Empty
                icon={FolderLock}
                text="Your private vault is ready"
                description="Keep receipts, warranties and important files together."
                action={
                  <Button variant="outline" size="sm" onClick={() => setDocOpen(true)}>
                    <Upload /> Upload
                  </Button>
                }
              />
            ) : (
              <div className="grid gap-2 sm:grid-cols-2">
                {docs.slice(0, 4).map((d) => {
                  const c = findOpt(DOCUMENT_CATEGORIES, d.category);
                  return (
                    <Link
                      key={d.id}
                      to="/documents"
                      className="flex items-center gap-3 rounded-xl border p-3 transition-colors hover:bg-muted"
                    >
                      <IconTile
                        icon={d.mime_type === "application/pdf" ? FileText : c.icon}
                        tone={c.tone}
                      />
                      <div className="min-w-0">
                        <p className="truncate text-sm font-semibold">{d.title}</p>
                        <p className="text-xs text-muted-foreground">
                          {formatDistanceToNow(new Date(d.created_at), { addSuffix: true })}
                        </p>
                      </div>
                    </Link>
                  );
                })}
              </div>
            )}
          </Panel>
        </div>

        <div className="space-y-6">
          <Panel
            icon={CreditCard}
            tint="peach"
            title="Upcoming renewals"
            description="Keep an eye on what's renewing next."
            link={{ to: "/subscriptions", label: "Manage" }}
          >
            {s.renewals.length === 0 ? (
              <Empty
                icon={CreditCard}
                text="No renewals on the horizon"
                description="Only active, saved subscriptions appear here."
                action={
                  <Button asChild variant="outline" size="sm">
                    <Link to="/subscriptions">
                      <Plus /> Add subscription
                    </Link>
                  </Button>
                }
              />
            ) : (
              <div className="space-y-2">
                {s.renewals.map((x) => {
                  const c = findOpt(SUBSCRIPTION_CATEGORIES, x.category);
                  const days = differenceInCalendarDays(parseISO(x.next_renewal), new Date());
                  return (
                    <div key={x.id} className="flex items-center gap-3 rounded-lg bg-muted/50 p-3">
                      <IconTile icon={c.icon} tone={c.tone} className="size-9" />
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-semibold">{x.name}</p>
                        <p
                          className={cn(
                            "text-xs",
                            days <= 3 ? "font-semibold text-warning" : "text-muted-foreground",
                          )}
                        >
                          {days === 0 ? "Today" : `in ${days} day${days === 1 ? "" : "s"}`}
                        </p>
                      </div>
                      <span className="text-sm font-bold">
                        {formatMoney(Number(x.amount), x.currency)}
                      </span>
                    </div>
                  );
                })}
                <div className="mt-2 flex justify-between border-t pt-3 text-sm">
                  <span className="text-muted-foreground">Yearly estimate</span>
                  <span className="font-bold">{formatMoney(s.t.yearly)}</span>
                </div>
              </div>
            )}
          </Panel>
          <Panel
            icon={ListChecks}
            tint="blend"
            title="Checklist progress"
            description="Small steps add up to a lighter day."
            link={{ to: "/checklists", label: "Open" }}
          >
            {lists.filter((l) => !l.is_template).length === 0 ? (
              <Empty
                icon={ListChecks}
                text="Start with one small list"
                description="Create your own or choose an everyday template."
                action={
                  <Button asChild variant="outline" size="sm">
                    <Link to="/checklists">
                      <Plus /> New checklist
                    </Link>
                  </Button>
                }
              />
            ) : (
              <div className="space-y-3">
                {lists
                  .filter((l) => !l.is_template)
                  .slice(0, 4)
                  .map((l) => {
                    const total = l.checklist_items.length;
                    const pct = total
                      ? Math.round(
                          (l.checklist_items.filter((i) => i.completed).length / total) * 100,
                        )
                      : 0;
                    return (
                      <Link
                        key={l.id}
                        to="/checklists/$id"
                        params={{ id: l.id }}
                        className="block rounded-lg bg-muted/40 p-4 transition-colors hover:bg-brand-soft"
                      >
                        <div className="mb-1 flex justify-between text-sm">
                          <span className="truncate font-medium">{l.title}</span>
                          <span className="text-muted-foreground">{pct}%</span>
                        </div>
                        <p className="mb-3 text-xs text-muted-foreground">
                          {l.checklist_items.filter((i) => i.completed).length} of {total} complete
                          · Created {format(new Date(l.created_at), "d MMM, HH:mm")}
                        </p>
                        <div className="h-2 overflow-hidden rounded-full bg-muted">
                          <div
                            className="h-full rounded-full progress-fill transition-all duration-700"
                            style={{ width: `${pct}%` }}
                          />
                        </div>
                      </Link>
                    );
                  })}
              </div>
            )}
          </Panel>
          <Panel
            icon={History}
            tint="cream"
            title="Recent activity"
            description="A history of your actions, including deleted items."
          >
            {activity.length === 0 ? (
              <Empty
                icon={History}
                text="A fresh start"
                description="Your real actions will appear here as you organise your life."
              />
            ) : (
              <ol className="space-y-3">
                {activity.slice(0, 6).map((a) => {
                  const Icon =
                    a.action === "completed"
                      ? CheckCircle2
                      : a.action === "deleted"
                        ? Trash2
                        : a.action === "updated"
                          ? Pencil
                          : a.action === "uploaded"
                            ? Upload
                            : PlusCircle;
                  return (
                    <li key={a.id} className="flex items-start gap-3 text-sm">
                      <Icon
                        className={cn(
                          "mt-0.5 size-4 shrink-0",
                          a.action === "completed"
                            ? "text-success"
                            : a.action === "deleted"
                              ? "text-destructive"
                              : "text-brand-ink",
                        )}
                      />
                      <div className="min-w-0 flex-1">
                        <p className="break-words">
                          <span className="capitalize">{a.action}</span> {a.entity_type}{" "}
                          <span className="font-semibold">{a.title}</span>
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {formatDistanceToNow(new Date(a.created_at), { addSuffix: true })}
                        </p>
                      </div>
                    </li>
                  );
                })}
              </ol>
            )}
          </Panel>
        </div>
      </div>

      <ReminderDialog open={remOpen} onOpenChange={setRemOpen} />
      <DocumentDialog open={docOpen} onOpenChange={setDocOpen} />
    </div>
  );
}

type Tint = "pink" | "rose" | "peach" | "cream" | "blend";

function ProgressRing({ pct }: { pct: number }) {
  const r = 34,
    c = 2 * Math.PI * r;
  return (
    <div className="flex items-center gap-4 rounded-xl border border-card/60 bg-card/55 p-5 shadow-card backdrop-blur-sm">
      <svg
        viewBox="0 0 80 80"
        className="size-20 -rotate-90"
        role="img"
        aria-label={`${pct}% complete today`}
      >
        <circle
          cx="40"
          cy="40"
          r={r}
          fill="none"
          strokeWidth="8"
          className="stroke-navy-foreground/15"
        />
        <circle
          cx="40"
          cy="40"
          r={r}
          fill="none"
          strokeWidth="8"
          strokeLinecap="round"
          className="ring-progress stroke-brand-ink"
          strokeDasharray={c}
          strokeDashoffset={c - (pct / 100) * c}
          style={{ ["--ring-c" as string]: c }}
        />
      </svg>
      <div>
        <p className="font-display text-3xl font-bold">{pct}%</p>
        <p className="text-sm text-navy-foreground/75">
          today's tasks &amp; checklist
          <br />
          items complete
        </p>
      </div>
    </div>
  );
}

function Stat({
  icon,
  tone,
  label,
  value,
  i,
  detail,
  to,
  tint,
}: {
  tint: Tint;
  icon: typeof Bell;
  tone: string;
  label: string;
  value: string;
  i: number;
  detail: string;
  to: "/reminders" | "/subscriptions" | "/documents";
}) {
  return (
    <Link
      to={to}
      className={cn(
        "card-surface card-hover block min-h-[170px] p-5 animate-rise sm:p-6",
        `tint-${tint}`,
      )}
      style={{ animationDelay: `${i * 60}ms` }}
    >
      <div className="mb-4 flex items-center gap-3">
        <IconTile icon={icon} tone={tone} />
        <p className="text-sm font-semibold">{label}</p>
      </div>
      <p className="break-words font-display text-2xl font-bold sm:text-3xl">{value}</p>
      <p className="mt-2 text-sm text-muted-foreground">{detail}</p>
    </Link>
  );
}

function Panel({
  title,
  link,
  children,
  icon: Icon,
  description,
  tint,
}: {
  tint: Tint;
  title: string;
  link?: { to: "/reminders" | "/documents" | "/subscriptions" | "/checklists"; label: string };
  children: ReactNode;
  icon: typeof Bell;
  description?: string;
}) {
  return (
    <section
      className={cn(
        "dashboard-panel panel-hover rounded-xl border p-5 shadow-card sm:p-6",
        `tint-${tint}`,
      )}
    >
      <div className="mb-4 grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3">
        <div className="min-w-0">
          <h2 className="flex items-center gap-2.5 text-lg font-semibold">
            <Icon className="size-5 shrink-0 text-brand-ink" />
            {title}
          </h2>
          {description && <p className="mt-2 text-sm text-muted-foreground">{description}</p>}
        </div>
        {link && (
          <Link
            to={link.to}
            className="flex shrink-0 items-center gap-1 text-sm font-semibold text-brand-ink hover:underline"
          >
            {link.label} <ArrowRight className="size-3" />
          </Link>
        )}
      </div>
      {children}
    </section>
  );
}

function Empty({
  text,
  action,
  description,
  icon: Icon,
}: {
  text: string;
  action?: ReactNode;
  description: string;
  icon: typeof Bell;
}) {
  return (
    <div className="flex min-h-40 flex-col items-center justify-center gap-3 py-5 text-center">
      <div className="grid size-12 place-items-center rounded-xl bg-brand-soft text-brand-ink">
        <Icon className="size-6" />
      </div>
      <div>
        <p className="text-base font-semibold">{text}</p>
        <p className="mt-1 max-w-sm text-sm text-muted-foreground">{description}</p>
      </div>
      {action && <div className="mt-1">{action}</div>}
    </div>
  );
}
