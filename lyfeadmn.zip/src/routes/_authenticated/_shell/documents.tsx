import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import {
  FolderLock,
  LayoutGrid,
  List,
  Plus,
  Search,
  Pencil,
  Trash2,
  ExternalLink,
  FileText,
  Lock,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  CategoryBadge,
  EmptyState,
  IconTile,
  ListSkeleton,
  PageHeader,
} from "@/components/app/page";
import { ConfirmDelete } from "@/components/app/confirm-dialog";
import { DocumentDialog } from "@/components/documents/document-dialog";
import { DOCUMENT_CATEGORIES, findOpt } from "@/lib/constants";
import { supabase } from "@/integrations/supabase/client";
import { logActivity, useAction, useDocuments, type Doc } from "@/hooks/use-data";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/_shell/documents")({
  head: () => ({
    meta: [
      { title: "Document vault — LYFEADMIN" },
      { name: "description", content: "Your private receipts, warranties and documents." },
      { property: "og:title", content: "Document vault \u2014 LYFEADMIN" },
      { property: "og:description", content: "Your private receipts, warranties and documents." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: DocumentsPage,
});

function fmtSize(b?: number | null) {
  if (!b) return "";
  return b > 1048576 ? `${(b / 1048576).toFixed(1)} MB` : `${Math.ceil(b / 1024)} KB`;
}

/** Short-lived signed URLs for image previews; never stored or shared. */
function usePreviews(docs: Doc[]) {
  const paths = docs.filter((d) => d.mime_type?.startsWith("image/")).map((d) => d.file_path);
  return useQuery({
    queryKey: ["doc-previews", paths],
    enabled: paths.length > 0,
    staleTime: 4 * 60_000,
    queryFn: async () => {
      const { data } = await supabase.storage.from("documents").createSignedUrls(paths, 300);
      return Object.fromEntries((data ?? []).map((d) => [d.path, d.signedUrl]));
    },
  });
}

async function openDoc(d: Doc) {
  const win = window.open("", "_blank");
  const { data, error } = await supabase.storage.from("documents").createSignedUrl(d.file_path, 60);
  if (error || !data) {
    win?.close();
    {
      toast.error("Couldn't open this document");
      return;
    }
  }
  if (win) win.location.href = data.signedUrl;
  else window.location.href = data.signedUrl;
}

function DocumentsPage() {
  const { data, isLoading, error } = useDocuments();
  const [view, setView] = useState<"grid" | "list">("grid");
  const [q, setQ] = useState("");
  const [cat, setCat] = useState("all");
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Doc | null>(null);

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    return (data ?? [])
      .filter((d) => cat === "all" || d.category === cat)
      .filter(
        (d) =>
          !s ||
          d.title.toLowerCase().includes(s) ||
          (d.description ?? "").toLowerCase().includes(s) ||
          d.file_name.toLowerCase().includes(s),
      );
  }, [data, q, cat]);
  const { data: previews } = usePreviews(filtered);

  const del = useAction(
    async (d: Doc) => {
      const s = await supabase.storage.from("documents").remove([d.file_path]);
      if (s.error) throw new Error(s.error.message);
      const r = await supabase.from("documents").delete().eq("id", d.id);
      if (r.error) throw new Error(r.error.message);
      await logActivity("deleted", "document", d.title);
    },
    { keys: [["documents"]], success: "Document deleted" },
  );

  const openNew = () => {
    setEditing(null);
    setOpen(true);
  };
  const edit = (d: Doc) => {
    setEditing(d);
    setOpen(true);
  };

  return (
    <>
      <PageHeader
        title="Document vault"
        description="Private to your account. Only you can open these files."
        actions={
          <Button variant="brand" onClick={openNew}>
            <Plus /> Upload
          </Button>
        }
      />

      <div className="mb-4 flex flex-col gap-2 sm:flex-row">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search documents"
            className="pl-9"
            aria-label="Search documents"
          />
        </div>
        <div className="flex gap-2">
          <Select value={cat} onValueChange={setCat}>
            <SelectTrigger className="flex-1 sm:w-[180px]" aria-label="Filter by category">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All categories</SelectItem>
              {DOCUMENT_CATEGORIES.map((c) => (
                <SelectItem key={c.value} value={c.value}>
                  {c.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <div className="flex rounded-xl border bg-card p-0.5">
            <Button
              variant={view === "grid" ? "secondary" : "ghost"}
              size="icon-sm"
              onClick={() => setView("grid")}
              aria-label="Grid view"
            >
              <LayoutGrid />
            </Button>
            <Button
              variant={view === "list" ? "secondary" : "ghost"}
              size="icon-sm"
              onClick={() => setView("list")}
              aria-label="List view"
            >
              <List />
            </Button>
          </div>
        </div>
      </div>

      {isLoading ? (
        <ListSkeleton />
      ) : error ? (
        <p className="text-destructive">Couldn't load documents: {error.message}</p>
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={FolderLock}
          title={data?.length ? "No matches" : "Your vault is empty"}
          description={
            data?.length
              ? "Try a different search or category."
              : "Upload receipts, warranties and important documents. They're stored privately."
          }
          action={
            !data?.length && (
              <Button variant="brand" onClick={openNew}>
                <Plus /> Upload a document
              </Button>
            )
          }
        />
      ) : view === "grid" ? (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
          {filtered.map((d) => {
            const c = findOpt(DOCUMENT_CATEGORIES, d.category);
            const img = previews?.[d.file_path];
            return (
              <div
                key={d.id}
                className="card-surface card-hover group flex flex-col overflow-hidden"
              >
                <button
                  onClick={() => openDoc(d)}
                  className="relative aspect-[4/3] bg-muted"
                  aria-label={`Open ${d.title}`}
                >
                  {img ? (
                    <img src={img} alt="" className="h-full w-full object-cover" loading="lazy" />
                  ) : (
                    <div className="grid h-full place-items-center">
                      <FileText className="size-10 text-muted-foreground" />
                    </div>
                  )}
                </button>
                <div className="flex flex-1 flex-col gap-1.5 p-3">
                  <p className="line-clamp-2 text-sm font-semibold break-words">{d.title}</p>
                  <CategoryBadge icon={c.icon} label={c.label} tone={c.tone} />
                  <div className="mt-auto grid gap-1 pt-1 sm:flex sm:items-center sm:justify-between">
                    <span className="text-[11px] text-muted-foreground">
                      {format(new Date(d.created_at), "d MMM yyyy")}
                    </span>
                    <div className="flex justify-end">
                      <Button
                        variant="ghost"
                        size="icon-xs"
                        aria-label="Edit"
                        onClick={() => edit(d)}
                      >
                        <Pencil />
                      </Button>
                      <ConfirmDelete
                        title="Delete this document?"
                        description={`"${d.title}" and its file will be permanently deleted.`}
                        onConfirm={() => del.mutate(d)}
                        trigger={
                          <Button variant="ghost" size="icon-xs" aria-label="Delete">
                            <Trash2 />
                          </Button>
                        }
                      />
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="space-y-2">
          {filtered.map((d) => {
            const c = findOpt(DOCUMENT_CATEGORIES, d.category);
            return (
              <div key={d.id} className="card-surface card-hover flex items-center gap-3 p-3">
                <IconTile icon={c.icon} tone={c.tone} />
                <div className="min-w-0 flex-1">
                  <p className="truncate font-semibold">{d.title}</p>
                  <p className="truncate text-xs text-muted-foreground">
                    {c.label} · {fmtSize(d.size_bytes)} ·{" "}
                    {format(new Date(d.created_at), "d MMM yyyy")}
                  </p>
                </div>
                <Button variant="ghost" size="icon-sm" aria-label="Open" onClick={() => openDoc(d)}>
                  <ExternalLink />
                </Button>
                <Button variant="ghost" size="icon-sm" aria-label="Edit" onClick={() => edit(d)}>
                  <Pencil />
                </Button>
                <ConfirmDelete
                  title="Delete this document?"
                  description={`"${d.title}" and its file will be permanently deleted.`}
                  onConfirm={() => del.mutate(d)}
                  trigger={
                    <Button variant="ghost" size="icon-sm" aria-label="Delete">
                      <Trash2 />
                    </Button>
                  }
                />
              </div>
            );
          })}
        </div>
      )}

      <p className={cn("mt-6 flex items-center gap-1.5 text-xs text-muted-foreground")}>
        <Lock className="size-3" /> Files open through temporary links that expire within minutes.
      </p>

      <DocumentDialog open={open} onOpenChange={setOpen} doc={editing} />
    </>
  );
}
