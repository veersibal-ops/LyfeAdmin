import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, Settings2, MessagesSquare, Copy } from "lucide-react";
import { toast } from "sonner";
import { assistantParts, chatEvent, encodeAssistant, decodeAssistant } from "@/lib/assistant";
import { ActionReview } from "@/components/assistant/action-review";
import { Checkbox } from "@/components/ui/checkbox";
import { ASSISTANT_SUGGESTIONS } from "@/components/assistant/suggestions";
import { Logo } from "@/components/app/logo";
import { playSound } from "@/lib/sounds";
import { BrandLoading } from "@/components/app/brand-loading";
import {
  Conversation,
  ConversationContent,
  ConversationScrollButton,
} from "@/components/ai-elements/conversation";
import {
  Message,
  MessageContent,
  MessageResponse,
  MessageActions,
  MessageAction,
} from "@/components/ai-elements/message";
import {
  PromptInput,
  PromptInputFooter,
  PromptInputSubmit,
  PromptInputTextarea,
} from "@/components/ai-elements/prompt-input";
import { Shimmer } from "@/components/ai-elements/shimmer";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { ThreadList } from "@/components/assistant/thread-list";
import { supabase } from "@/integrations/supabase/client";
import { unwrap, unwrapMaybe, useDocuments } from "@/hooks/use-data";

export const Route = createFileRoute("/_authenticated/_shell/assistant/$threadId")({
  head: () => ({
    meta: [
      { title: "Conversation \u2014 LYFEADMIN" },
      { name: "description", content: "Chat with your LYFEADMIN assistant." },
      { property: "og:title", content: "Conversation \u2014 LYFEADMIN" },
      { property: "og:description", content: "Chat with your LYFEADMIN assistant." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ThreadPage,
});

type Msg = { id: string; role: "user" | "assistant"; content: string; saved?: boolean };
type Status = "ready" | "submitted" | "streaming" | "error";

function ThreadPage() {
  const { threadId } = Route.useParams();
  return <ChatWindow key={threadId} threadId={threadId} />;
}

function ChatWindow({ threadId }: { threadId: string }) {
  const qc = useQueryClient();
  const {
    data: initial,
    isLoading,
    error: loadError,
  } = useQuery({
    queryKey: ["chat", threadId],
    queryFn: async () => {
      const t = unwrapMaybe(
        await supabase.from("chat_threads").select("id").eq("id", threadId).maybeSingle(),
      );
      if (!t) throw new Error("This conversation doesn't exist.");
      return unwrap(
        await supabase
          .from("chat_messages")
          .select("id,role,content")
          .eq("thread_id", threadId)
          .order("created_at"),
      ) as Msg[];
    },
  });
  const [messages, setMessages] = useState<Msg[]>([]);
  const [status, setStatus] = useState<Status>("ready");
  const [text, setText] = useState("");
  const [share, setShare] = useState(false);
  const [setupNeeded, setSetupNeeded] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [listOpen, setListOpen] = useState(false);
  const [documentIds, setDocumentIds] = useState<string[]>([]);
  const [documentsOpen, setDocumentsOpen] = useState(false);
  const { data: documents = [] } = useDocuments();
  const abortRef = useRef<AbortController | null>(null);
  const sendLock = useRef(false);

  useEffect(() => () => abortRef.current?.abort(), []);

  useEffect(() => {
    if (initial && !sendLock.current) setMessages(initial.map((m) => ({ ...m, saved: true })));
  }, [initial]);
  useEffect(() => {
    const draft = sessionStorage.getItem("la-assistant-draft");
    if (draft) {
      setText(draft);
    }
  }, []);
  useEffect(() => {
    if (status === "ready" && !isLoading && !listOpen && !documentsOpen)
      document.querySelector<HTMLTextAreaElement>("textarea[name='message']")?.focus();
  }, [status, isLoading, listOpen, documentsOpen]);

  async function send(raw: string) {
    const content = raw.trim();
    if (!content || sendLock.current) return;
    sendLock.current = true;
    playSound("send");
    sessionStorage.removeItem("la-assistant-draft");
    setError(null);
    setSetupNeeded(false);
    setText("");
    const userMsg: Msg = { id: crypto.randomUUID(), role: "user", content };
    const asstId = crypto.randomUUID();
    setMessages((m) => [...m, userMsg]);
    setStatus("submitted");
    document.querySelector<HTMLTextAreaElement>("textarea[name='message']")?.focus();
    const ctrl = new AbortController();
    abortRef.current = ctrl;
    try {
      const { data: s } = await supabase.auth.getSession();
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "content-type": "application/json",
          authorization: `Bearer ${s.session?.access_token ?? ""}`,
        },
        body: JSON.stringify({
          threadId,
          message: content,
          shareContext: share,
          documentIds,
          timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
        }),
        signal: ctrl.signal,
      });
      if (!res.ok || !res.body) {
        const j = (await res.json().catch(() => ({}))) as { error?: string };
        if (res.status === 503 && j.error === "not_configured") setSetupNeeded(true);
        throw new Error(
          j.error === "not_configured"
            ? "The AI assistant isn't set up yet."
            : (j.error ?? "Something went wrong"),
        );
      }
      setMessages((m) => [...m, { id: asstId, role: "assistant", content: "", saved: false }]);
      setStatus("streaming");
      const reader = res.body.getReader();
      const dec = new TextDecoder();
      let buffer = "";
      let answer = "";
      let action: import("@/lib/assistant").AssistantAction | undefined;
      let savedId: string = asstId;
      const consume = (line: string) => {
        if (!line.trim()) return;
        const event = chatEvent.parse(JSON.parse(line));
        if (event.type === "error") throw new Error(event.message);
        if (event.type === "text") answer += event.delta;
        if (event.type === "action") action = event.action;
        const oldId = savedId;
        if (event.type === "saved") savedId = event.id;
        setMessages((m) =>
          m.map((x) =>
            x.id === oldId
              ? {
                  ...x,
                  id: savedId,
                  content: encodeAssistant(answer, action),
                  saved: event.type === "saved" || Boolean(x.saved),
                }
              : x,
          ),
        );
      };
      for (;;) {
        const { done, value } = await reader.read();
        if (done) {
          buffer += dec.decode();
          if (buffer.trim()) consume(buffer);
          break;
        }
        buffer += dec.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() ?? "";
        for (const line of lines) consume(line);
      }
      setStatus("ready");
    } catch (e) {
      if ((e as Error).name === "AbortError") {
        setStatus("ready");
      } else {
        setError((e as Error).message);
        setStatus("error");
        setText(content);
        setStatus("ready");
      }
    } finally {
      sendLock.current = false;
      abortRef.current = null;
      qc.invalidateQueries({ queryKey: ["threads"] });
      qc.invalidateQueries({ queryKey: ["chat", threadId] });
    }
  }

  if (loadError)
    return (
      <div className="text-center">
        <p className="text-muted-foreground">{loadError.message}</p>
        <Button asChild variant="outline" className="mt-4">
          <Link to="/assistant">Back to assistant</Link>
        </Button>
      </div>
    );

  return (
    <div className="grid gap-6 xl:grid-cols-[280px_minmax(0,1fr)]">
      <aside className="hidden rounded-xl border bg-card p-5 shadow-card xl:block">
        <ThreadList activeId={threadId} />
      </aside>

      <div className="card-surface flex min-w-0 h-[calc(100dvh-13rem)] min-h-[540px] flex-col overflow-hidden md:h-[calc(100dvh-8rem)] md:max-h-[1100px]">
        <div className="flex items-center gap-3 border-b bg-muted/40 px-5 py-4">
          <Link to="/assistant" className="md:hidden" aria-label="Back">
            <ArrowLeft className="size-5" />
          </Link>
          <Logo showText={false} />
          <div className="min-w-0 flex-1">
            <p className="text-base font-semibold">LYFEADMIN assistant</p>
            <p className="text-xs text-muted-foreground">
              Nothing is changed without your confirmation
            </p>
          </div>
          <Button
            variant="ghost"
            size="icon-sm"
            className="xl:hidden"
            onClick={() => setListOpen(true)}
            aria-label="Conversations"
          >
            <MessagesSquare />
          </Button>
        </div>

        <Conversation className="min-h-0 flex-1">
          <ConversationContent className="mx-auto w-full max-w-4xl gap-7 px-5 py-8 sm:px-8">
            {isLoading ? (
              <BrandLoading />
            ) : messages.length === 0 ? (
              <div className="mx-auto w-full max-w-lg py-4 text-center animate-rise">
                <Logo showText={false} className="mb-4 justify-center [&_img]:size-14" />
                <h2 className="text-xl font-bold">How can I help you get organised?</h2>
                <p className="mt-3 text-base text-muted-foreground">
                  A plan, a checklist, or just a place to begin.
                </p>
                <div className="mt-6 grid gap-3 text-left sm:grid-cols-2">
                  {ASSISTANT_SUGGESTIONS.map((s) => (
                    <Button
                      variant="ghost"
                      key={s.title}
                      onClick={() => setText(s.prompt)}
                      className="flex h-auto items-center justify-start gap-3 whitespace-normal rounded-xl border bg-card p-4 text-sm transition-colors hover:border-brand-ink hover:bg-brand-soft"
                    >
                      <s.icon className="size-5 shrink-0 text-brand-ink" /> {s.title}
                    </Button>
                  ))}
                </div>
              </div>
            ) : (
              messages.map((m) => (
                <Message key={m.id} from={m.role} className="animate-rise">
                  <MessageContent className="text-base leading-relaxed group-[.is-user]:bg-primary group-[.is-user]:text-primary-foreground group-[.is-user]:rounded-2xl">
                    {assistantParts(m.content).map((part, i) =>
                      part.type === "text" ? (
                        m.role === "assistant" ? (
                          <MessageResponse key={i} isAnimating={status === "streaming" && !m.saved}>
                            {part.text}
                          </MessageResponse>
                        ) : (
                          <p key={i} className="whitespace-pre-wrap break-words">
                            {part.text}
                          </p>
                        )
                      ) : part.type === "dynamic-tool" ? (
                        <ActionReview
                          key={i}
                          action={
                            decodeAssistant(m.content).action ??
                            (part.input as import("@/lib/assistant").AssistantAction)
                          }
                          messageId={m.id}
                          saved={Boolean(m.saved)}
                        />
                      ) : null,
                    )}
                  </MessageContent>
                  {m.role === "assistant" && decodeAssistant(m.content).text && (
                    <MessageActions>
                      <MessageAction
                        tooltip="Copy response"
                        onClick={async () => {
                          try {
                            await navigator.clipboard.writeText(decodeAssistant(m.content).text);
                            toast.success("Response copied");
                          } catch {
                            toast.error("Copy is unavailable in this browser.");
                          }
                        }}
                      >
                        <Copy className="size-4" />
                      </MessageAction>
                    </MessageActions>
                  )}
                </Message>
              ))
            )}
            {status === "submitted" && (
              <div
                role="status"
                aria-label="Assistant is thinking"
                className="flex items-center gap-3"
              >
                <span className="typing-pulse" aria-hidden="true">
                  <i />
                  <i />
                  <i />
                </span>
                <Shimmer className="text-sm">Thinking…</Shimmer>
              </div>
            )}
            {setupNeeded && (
              <div className="flex gap-3 rounded-xl border border-warning/40 bg-warning-soft p-4 text-sm">
                <Settings2 className="size-5 shrink-0 text-warning" />
                <div>
                  <p className="font-semibold">AI isn't configured yet</p>
                  <p className="text-muted-foreground">
                    The assistant needs its AI connection enabled on the server before it can reply.
                    No fake responses will be shown.
                  </p>
                </div>
              </div>
            )}
            {error && !setupNeeded && (
              <p role="alert" className="text-sm font-medium text-destructive">
                {error}
              </p>
            )}
          </ConversationContent>
          <ConversationScrollButton />
        </Conversation>

        <div className="border-t bg-muted/30 p-4 sm:p-6">
          <label className="mb-3 flex items-center gap-3 text-sm text-muted-foreground">
            <Switch
              checked={share}
              onCheckedChange={setShare}
              aria-label="Share my saved app information"
            />
            Share my reminders, checklists, subscriptions and document names for this message
          </label>
          <div className="mb-3 flex flex-wrap items-center gap-3">
            <Button variant="ghost" size="sm" onClick={() => setDocumentsOpen(true)}>
              Authorise documents{documentIds.length ? ` (${documentIds.length})` : ""}
            </Button>
            {documentIds.length > 0 && (
              <Button variant="ghost" size="sm" onClick={() => setDocumentIds([])}>
                Clear selection
              </Button>
            )}
          </div>
          <PromptInput onSubmit={(m) => send(m.text)}>
            <PromptInputTextarea
              name="message"
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Ask anything about planning or organising…"
              className="min-h-24 text-base"
              maxLength={4000}
            />
            <PromptInputFooter className="justify-end">
              <PromptInputSubmit
                status={status}
                disabled={!text.trim() && status === "ready"}
                onStop={() => abortRef.current?.abort()}
              />
            </PromptInputFooter>
          </PromptInput>
        </div>
      </div>

      <Sheet open={listOpen} onOpenChange={setListOpen}>
        <SheetContent side="left" className="w-[85vw] max-w-xs p-4">
          <SheetHeader>
            <SheetTitle>Conversations</SheetTitle>
          </SheetHeader>
          <div className="mt-4 h-[calc(100%-4rem)]">
            <ThreadList activeId={threadId} onNavigate={() => setListOpen(false)} />
          </div>
        </SheetContent>
      </Sheet>
      <Sheet open={documentsOpen} onOpenChange={setDocumentsOpen}>
        <SheetContent className="overflow-y-auto">
          <SheetHeader>
            <SheetTitle>Authorise document reading</SheetTitle>
          </SheetHeader>
          <p className="my-4 text-sm text-muted-foreground">
            Selected file contents will be sent to the AI service with each message while selected.
            Choose up to three PDF, text or image files under 5 MB. Clear the selection to stop
            sharing.
          </p>
          <div className="space-y-4">
            {documents
              .filter(
                (d) =>
                  [
                    "text/plain",
                    "application/pdf",
                    "image/png",
                    "image/jpeg",
                    "image/webp",
                  ].includes(d.mime_type ?? "") && (d.size_bytes ?? 0) <= 5 * 1024 * 1024,
              )
              .map((d) => (
                <label key={d.id} className="flex items-start gap-3">
                  <Checkbox
                    checked={documentIds.includes(d.id)}
                    disabled={!documentIds.includes(d.id) && documentIds.length >= 3}
                    onCheckedChange={(value) =>
                      setDocumentIds((ids) =>
                        value ? [...ids, d.id] : ids.filter((id) => id !== d.id),
                      )
                    }
                  />
                  <span className="min-w-0 break-words text-sm">
                    {d.title}
                    <span className="block text-muted-foreground">{d.file_name}</span>
                  </span>
                </label>
              ))}
            {documents.length === 0 && (
              <p className="text-sm text-muted-foreground">No saved documents yet.</p>
            )}
          </div>
          <Button className="mt-6" onClick={() => setDocumentsOpen(false)}>
            Done
          </Button>
        </SheetContent>
      </Sheet>
    </div>
  );
}
