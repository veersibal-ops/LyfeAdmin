import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { isPast } from "date-fns";
import { Bell, Plus, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { EmptyState, ListSkeleton, PageHeader } from "@/components/app/page";
import { ReminderDialog } from "@/components/reminders/reminder-dialog";
import { ReminderRow } from "@/components/reminders/reminder-row";
import { REMINDER_CATEGORIES } from "@/lib/constants";
import { useReminders, type Reminder } from "@/hooks/use-data";

export const Route = createFileRoute("/_authenticated/_shell/reminders")({
  head: () => ({
    meta: [
      { title: "Reminders — LYFEADMIN" },
      { name: "description", content: "Your upcoming and overdue reminders." },
      { property: "og:title", content: "Reminders \u2014 LYFEADMIN" },
      { property: "og:description", content: "Your upcoming and overdue reminders." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: RemindersPage,
});

type View = "upcoming" | "overdue" | "completed" | "all";

function RemindersPage() {
  const { data, isLoading, error } = useReminders();
  const [view, setView] = useState<View>("upcoming");
  const [q, setQ] = useState("");
  const [cat, setCat] = useState("all");
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Reminder | null>(null);

  const counts = useMemo(() => {
    const list = data ?? [];
    return {
      upcoming: list.filter((r) => !r.completed && !isPast(new Date(r.due_at))).length,
      overdue: list.filter((r) => !r.completed && isPast(new Date(r.due_at))).length,
      completed: list.filter((r) => r.completed).length,
      all: list.length,
    };
  }, [data]);

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    return (data ?? [])
      .filter((r) => {
        const past = isPast(new Date(r.due_at));
        if (view === "upcoming") return !r.completed && !past;
        if (view === "overdue") return !r.completed && past;
        if (view === "completed") return r.completed;
        return true;
      })
      .filter((r) => cat === "all" || r.category === cat)
      .filter(
        (r) =>
          !s ||
          r.title.toLowerCase().includes(s) ||
          (r.description ?? "").toLowerCase().includes(s),
      );
  }, [data, view, q, cat]);

  const openNew = () => {
    setEditing(null);
    setOpen(true);
  };

  return (
    <>
      <PageHeader
        title="Reminders"
        description="Appointments, bills and everything in between."
        actions={
          <Button variant="brand" onClick={openNew}>
            <Plus /> New reminder
          </Button>
        }
      />

      <div className="mb-4 flex flex-col gap-3 lg:flex-row lg:items-center">
        <Tabs value={view} onValueChange={(v) => setView(v as View)} className="min-w-0">
          <TabsList className="h-auto w-full flex-wrap justify-start rounded-xl lg:w-auto">
            {(["upcoming", "overdue", "completed", "all"] as View[]).map((v) => (
              <TabsTrigger key={v} value={v} className="rounded-lg capitalize">
                {v} <span className="ml-1 text-xs opacity-60">{counts[v]}</span>
              </TabsTrigger>
            ))}
          </TabsList>
        </Tabs>
        <div className="flex flex-1 gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search reminders"
              className="pl-9"
              aria-label="Search reminders"
            />
          </div>
          <Select value={cat} onValueChange={setCat}>
            <SelectTrigger className="w-[150px]" aria-label="Filter by category">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All categories</SelectItem>
              {REMINDER_CATEGORIES.map((c) => (
                <SelectItem key={c.value} value={c.value}>
                  {c.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {isLoading ? (
        <ListSkeleton />
      ) : error ? (
        <p className="text-destructive">Couldn't load reminders: {error.message}</p>
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={Bell}
          title={data?.length ? "Nothing here" : "No reminders yet"}
          description={
            data?.length
              ? "Try a different filter or search."
              : "Add your first reminder — a bill, appointment or anything you don't want to forget."
          }
          action={
            !data?.length && (
              <Button variant="brand" onClick={openNew}>
                <Plus /> Add a reminder
              </Button>
            )
          }
        />
      ) : (
        <div className="space-y-2.5">
          {filtered.map((r) => (
            <ReminderRow
              key={r.id}
              r={r}
              onEdit={(x) => {
                setEditing(x);
                setOpen(true);
              }}
            />
          ))}
        </div>
      )}

      <ReminderDialog open={open} onOpenChange={setOpen} reminder={editing} />
    </>
  );
}
