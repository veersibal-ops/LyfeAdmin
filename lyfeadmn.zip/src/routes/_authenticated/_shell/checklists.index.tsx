import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useRef, useState, type FormEvent } from "react";
import { ListChecks, Plus, Loader2, Copy, Bookmark } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { EmptyState, IconTile, ListSkeleton, PageHeader } from "@/components/app/page";
import {
  BUILTIN_TEMPLATES,
  CHECKLIST_CATEGORIES,
  findOpt,
  type ChecklistCategory,
} from "@/lib/constants";
import { supabase } from "@/integrations/supabase/client";
import { logActivity, unwrap, useAction, useChecklists } from "@/hooks/use-data";

export const Route = createFileRoute("/_authenticated/_shell/checklists/")({
  head: () => ({
    meta: [
      { title: "Checklists — LYFEADMIN" },
      { name: "description", content: "Reusable checklists for everyday life." },
      { property: "og:title", content: "Checklists \u2014 LYFEADMIN" },
      { property: "og:description", content: "Reusable checklists for everyday life." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ChecklistsPage,
});

export async function createChecklist(title: string, category: ChecklistCategory, items: string[]) {
  const c = unwrap(await supabase.from("checklists").insert({ title, category }).select().single());
  if (items.length) {
    unwrap(
      await supabase
        .from("checklist_items")
        .insert(items.map((content, position) => ({ checklist_id: c.id, content, position })))
        .select(),
    );
  }
  await logActivity("created", "checklist", title, c.id);
  return c;
}

function ChecklistsPage() {
  const { data, isLoading, error } = useChecklists();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState<ChecklistCategory>("general");
  const [err, setErr] = useState("");

  // Synchronous lock: a fast double tap fired two inserts before isPending re-rendered.
  const busy = useRef(false);
  const create = useAction(
    (v: { title: string; category: ChecklistCategory; items: string[] }) =>
      createChecklist(v.title, v.category, v.items),
    { keys: [["checklists"]], success: "Checklist created" },
  );
  /** Creates once per tap, then opens it; extra taps while saving are ignored. */
  function start(
    v: { title: string; category: ChecklistCategory; items: string[] },
    after?: () => void,
  ) {
    if (busy.current) return;
    busy.current = true;
    create.mutate(v, {
      onSuccess: (c) => {
        after?.();
        go(c.id);
      },
      onSettled: () => {
        busy.current = false;
      },
    });
  }
  const go = (id: string) => navigate({ to: "/checklists/$id", params: { id } });

  const lists = (data ?? []).filter((c) => !c.is_template);
  const myTemplates = (data ?? []).filter((c) => c.is_template);

  function submit(e: FormEvent) {
    e.preventDefault();
    if (!title.trim()) {
      setErr("Give your checklist a name");
      return;
    }
    start({ title: title.trim(), category, items: [] }, () => {
      setOpen(false);
      setTitle("");
    });
  }

  async function copyTemplate(id: string) {
    if (busy.current) return;
    const t = unwrap(
      await supabase
        .from("checklists")
        .select("title, category, checklist_items(content, position)")
        .eq("id", id)
        .single(),
    );
    const items = [...t.checklist_items]
      .sort((a, b) => a.position - b.position)
      .map((i) => i.content);
    start({ title: t.title, category: t.category as ChecklistCategory, items });
  }

  return (
    <>
      <PageHeader
        title="Checklists"
        description="Tick things off and feel good about it."
        actions={
          <Button
            variant="brand"
            onClick={() => {
              setErr("");
              setOpen(true);
            }}
          >
            <Plus /> New checklist
          </Button>
        }
      />

      <section className="mb-8">
        <h2 className="mb-3 text-sm font-semibold uppercase tracking-wider text-muted-foreground">
          Start from a template
        </h2>
        <div className="-mx-4 flex gap-3 overflow-x-auto px-4 pb-2 sm:mx-0 sm:grid sm:grid-cols-3 sm:overflow-visible sm:px-0 lg:grid-cols-6">
          {BUILTIN_TEMPLATES.map((t) => {
            const c = findOpt(CHECKLIST_CATEGORIES, t.category);
            return (
              <Button
                variant="ghost"
                key={t.title}
                disabled={create.isPending}
                onClick={() => start(t)}
                className="card-surface card-hover flex h-auto min-h-36 w-44 shrink-0 flex-col items-start justify-start gap-3 whitespace-normal p-5 text-left sm:w-auto"
              >
                <IconTile icon={c.icon} tone={c.tone} />
                <span className="text-sm font-semibold">{t.title}</span>
                <span className="text-xs text-muted-foreground">{t.items.length} items</span>
              </Button>
            );
          })}
        </div>
        {myTemplates.length > 0 && (
          <div className="mt-4 flex flex-wrap gap-2">
            {myTemplates.map((t) => (
              <Button
                key={t.id}
                variant="outline"
                size="sm"
                onClick={() => copyTemplate(t.id)}
                disabled={create.isPending}
              >
                <Bookmark /> {t.title} <Copy className="opacity-50" />
              </Button>
            ))}
          </div>
        )}
      </section>

      <h2 className="mb-3 text-sm font-semibold uppercase tracking-wider text-muted-foreground">
        Your checklists
      </h2>
      {isLoading ? (
        <ListSkeleton />
      ) : error ? (
        <p className="text-destructive">{error.message}</p>
      ) : lists.length === 0 ? (
        <EmptyState
          icon={ListChecks}
          title="No checklists yet"
          description="Pick a template above or create your own."
        />
      ) : (
        <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
          {lists.map((l) => {
            const c = findOpt(CHECKLIST_CATEGORIES, l.category);
            const total = l.checklist_items.length;
            const done = l.checklist_items.filter((i) => i.completed).length;
            const pct = total ? Math.round((done / total) * 100) : 0;
            return (
              <Link
                key={l.id}
                to="/checklists/$id"
                params={{ id: l.id }}
                className="card-surface card-hover block p-6"
              >
                <div className="flex items-center gap-3">
                  <IconTile icon={c.icon} tone={c.tone} />
                  <div className="min-w-0">
                    <p className="truncate font-semibold">{l.title}</p>
                    <p className="text-xs text-muted-foreground">
                      {done} of {total} done · Created {new Date(l.created_at).toLocaleDateString()}
                    </p>
                  </div>
                  <span className="ml-auto font-display text-lg font-bold text-brand-ink">
                    {pct}%
                  </span>
                </div>
                <Progress value={pct} className="mt-3 h-2" />
              </Link>
            );
          })}
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="rounded-2xl sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>New checklist</DialogTitle>
          </DialogHeader>
          <form onSubmit={submit} className="space-y-4" noValidate>
            <div className="space-y-1.5">
              <Label htmlFor="c-title">Name</Label>
              <Input
                id="c-title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                maxLength={150}
                placeholder="e.g. Birthday party"
              />
              {err && <p className="text-xs text-destructive">{err}</p>}
            </div>
            <div className="space-y-1.5">
              <Label>Category</Label>
              <Select value={category} onValueChange={(v) => setCategory(v as ChecklistCategory)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {CHECKLIST_CATEGORIES.map((c) => (
                    <SelectItem key={c.value} value={c.value}>
                      {c.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <DialogFooter>
              <Button type="submit" variant="brand" disabled={create.isPending}>
                {create.isPending && <Loader2 className="animate-spin" />} Create
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
}
