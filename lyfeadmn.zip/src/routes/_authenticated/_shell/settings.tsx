import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent, type ReactNode } from "react";
import {
  Loader2,
  LogOut,
  Moon,
  Sun,
  Monitor,
  ShieldCheck,
  User,
  Bell,
  Palette,
  Lock,
  Trash2,
  Volume2,
} from "lucide-react";
import { Slider } from "@/components/ui/slider";
import { playSound } from "@/lib/sounds";
import { useSoundPrefs } from "@/components/app/sound-effects";
import { useServerFn } from "@tanstack/react-start";
import { useMutation } from "@tanstack/react-query";
import { ConfirmDelete } from "@/components/app/confirm-dialog";
import { deleteMyAccount } from "@/lib/account.functions";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { PageHeader } from "@/components/app/page";
import { useSignOut } from "@/components/app/app-shell";
import { supabase } from "@/integrations/supabase/client";
import { useProfile, useUpdateProfile } from "@/hooks/use-data";
import { useUser } from "@/hooks/use-session";
import { cn } from "@/lib/utils";
import { InstallControl } from "@/components/app/install-control";
import { NotificationInbox } from "@/components/app/notification-inbox";
import { mayRequestNotificationPermission } from "@/lib/discovery";
import { useDecorativeEffects } from "@/components/app/cursor-effects";

export const Route = createFileRoute("/_authenticated/_shell/settings")({
  head: () => ({
    meta: [
      { title: "Settings — LYFEADMIN" },
      { name: "description", content: "Profile, notifications and account settings." },
      { property: "og:title", content: "Settings \u2014 LYFEADMIN" },
      { property: "og:description", content: "Profile, notifications and account settings." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: SettingsPage,
});

function Section({
  icon: Icon,
  id,
  title,
  description,
  children,
}: {
  icon: typeof User;
  title: string;
  id?: string;
  description?: string;
  children: ReactNode;
}) {
  return (
    <section id={id} className="scroll-mt-24 border-t border-border py-5 sm:py-6">
      <div className="mb-5 flex items-start gap-3">
        <div className="grid size-9 place-items-center rounded-xl bg-brand-soft text-brand-ink">
          <Icon className="size-4" />
        </div>
        <div className="min-w-0">
          <h2 className="text-xl font-semibold">{title}</h2>
          {description && <p className="text-sm text-muted-foreground">{description}</p>}
        </div>
      </div>
      {children}
    </section>
  );
}

function SettingsPage() {
  const { data: profile } = useProfile();
  const { user } = useUser();
  const update = useUpdateProfile();
  const signOut = useSignOut();
  const effects = useDecorativeEffects();
  const sounds = useSoundPrefs();
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [pw, setPw] = useState({ current: "", next: "" });
  const [pwBusy, setPwBusy] = useState(false);
  const [permission, setPermission] = useState("unknown");
  const [pushBusy, setPushBusy] = useState(false);
  useEffect(() => {
    setPermission(typeof Notification === "undefined" ? "unsupported" : Notification.permission);
  }, []);
  const delAccountFn = useServerFn(deleteMyAccount);
  const delAccount = useMutation({
    mutationFn: () => delAccountFn(),
    onSuccess: async () => {
      toast.success("Your account and data have been deleted");
      await signOut();
    },
    onError: (e: Error) => toast.error(e.message || "Couldn't delete your account"),
  });
  const isEmailUser = user?.app_metadata?.provider === "email";

  useEffect(() => {
    if (profile) {
      setName(profile.full_name ?? "");
      setPhone(profile.phone ?? "");
    }
  }, [profile]);

  function saveProfile(e: FormEvent) {
    e.preventDefault();
    if (!name.trim()) {
      toast.error("Name can't be empty");
      return;
    }
    update.mutate(
      { full_name: name.trim(), phone: phone.trim() || null },
      { onSuccess: () => toast.success("Profile saved") },
    );
  }

  async function togglePush(on: boolean) {
    if (pushBusy) return;
    setPushBusy(true);
    try {
      if (on) {
        if (typeof Notification === "undefined") {
          toast.error("This browser doesn't support notifications");
          return;
        }
        if (window.top !== window.self) {
          toast.error("Open LYFEADMIN in its own tab to enable notifications.");
          return;
        }
        if (Notification.permission === "denied") {
          toast.error(
            "Notifications are blocked. You can change this in your browser’s site settings.",
          );
          return;
        }
        const p = mayRequestNotificationPermission(Notification.permission, true, false)
          ? await Notification.requestPermission()
          : Notification.permission;
        setPermission(p);
        if (p !== "granted") {
          toast.error("Notifications were blocked. Allow them in your browser settings.");
          return;
        }
      }
      await update.mutateAsync({ notify_push: on });
      toast.success(on ? "Browser notifications on" : "Browser notifications off");
    } catch {
      toast.error(
        "Couldn't enable notifications. Check this browser’s site settings and try again.",
      );
    } finally {
      setPushBusy(false);
    }
  }

  async function changePassword(e: FormEvent) {
    e.preventDefault();
    if (pw.next.length < 8) {
      toast.error("New password must be at least 8 characters");
      return;
    }
    setPwBusy(true);
    const { error } = await supabase.auth.updateUser({
      password: pw.next,
      current_password: pw.current,
    } as { password: string });
    setPwBusy(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    setPw({ current: "", next: "" });
    toast.success("Password changed");
  }

  async function resetByEmail() {
    if (!user?.email) return;
    const { error } = await supabase.auth.resetPasswordForEmail(user.email, {
      redirectTo: `${window.location.origin}/reset-password`,
    });
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Check your email for a reset link");
  }

  const theme = profile?.theme ?? "light";

  return (
    <div className="max-w-5xl">
      <PageHeader title="Profile & settings" description="Manage your account and preferences." />
      <div className="space-y-4">
        <Section id="account" icon={User} title="Personal information">
          <form onSubmit={saveProfile} className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor="p-name">Full name</Label>
              <Input
                id="p-name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                maxLength={100}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="p-phone">Mobile</Label>
              <Input
                id="p-phone"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                maxLength={30}
                inputMode="tel"
              />
            </div>
            <div className="space-y-1.5 sm:col-span-2">
              <Label>Email</Label>
              <Input value={user?.email ?? ""} disabled />
            </div>
            <div className="sm:col-span-2">
              <Button type="submit" variant="brand" disabled={update.isPending}>
                {update.isPending && <Loader2 className="animate-spin" />} Save profile
              </Button>
            </div>
          </form>
        </Section>

        <Section icon={Bell} title="Notifications" description="Choose how LYFEADMIN reminds you.">
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Enabling notifications asks this browser to show reminder and renewal alerts on this
              device while LYFEADMIN is open. Your browser may block alerts; saved alerts remain
              available below. Background device push is not configured.
            </p>
            <Row
              label="Browser notifications"
              hint="Alerts on this device while LYFEADMIN is open in a tab."
            >
              <Button
                variant="outline"
                disabled={
                  pushBusy ||
                  permission === "unsupported" ||
                  (permission === "denied" && !profile?.notify_push)
                }
                onClick={() => togglePush(!profile?.notify_push)}
              >
                {profile?.notify_push ? "Disable Notifications" : "Enable Notifications"}
              </Button>
            </Row>
            {permission === "denied" && (
              <p className="text-sm text-warning">
                Permission denied. To enable later, change this browser’s site notification
                settings.
              </p>
            )}
            {permission === "unsupported" && (
              <p className="text-sm text-muted-foreground">
                This browser does not support device alerts. Use the saved alerts below.
              </p>
            )}
            <Row label="Reminder notifications" hint="Save alerts for upcoming reminders.">
              <Switch
                aria-label="Reminder notifications"
                checked={profile?.notify_reminders ?? true}
                onCheckedChange={(v) => update.mutate({ notify_reminders: v })}
              />
            </Row>
            <Row
              label="Subscription renewal notifications"
              hint="Save alerts before active subscriptions renew."
            >
              <Switch
                aria-label="Subscription renewal notifications"
                checked={profile?.notify_renewals ?? true}
                onCheckedChange={(v) => update.mutate({ notify_renewals: v })}
              />
            </Row>
            <Row label="Renewal notice" hint="How early to save a renewal alert.">
              <Select
                value={String(profile?.renewal_lead_days ?? 3)}
                onValueChange={(v) => update.mutate({ renewal_lead_days: Number(v) })}
              >
                <SelectTrigger className="w-36">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {[1, 3, 7].map((v) => (
                    <SelectItem key={v} value={String(v)}>
                      {v} {v === 1 ? "day" : "days"}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Row>
            <Row label="Time zone" hint={profile?.timezone ?? "UTC"}>
              <Button
                variant="outline"
                onClick={() =>
                  update.mutate({ timezone: Intl.DateTimeFormat().resolvedOptions().timeZone })
                }
              >
                Use device time zone
              </Button>
            </Row>
            <p className="text-xs text-muted-foreground">
              Saved alerts are checked every 30 minutes when the app is closed, and every minute
              while open. Device delivery is not guaranteed. For 15-minute reminder notice, keep
              LYFEADMIN open.
            </p>
            <Row label="Remind me" hint="How long before a reminder is due.">
              <Select
                value={String(profile?.notify_lead_minutes ?? 60)}
                onValueChange={(v) => update.mutate({ notify_lead_minutes: Number(v) })}
              >
                <SelectTrigger className="w-36">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {[
                    [15, "15 minutes"],
                    [60, "1 hour"],
                    [180, "3 hours"],
                    [1440, "1 day"],
                  ].map(([v, l]) => (
                    <SelectItem key={v} value={String(v)}>
                      {l}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Row>
            <Row
              label="Email summaries"
              hint="Saved as your preference — email delivery is coming soon."
            >
              <Switch
                checked={!!profile?.notify_email}
                onCheckedChange={(v) => update.mutate({ notify_email: v })}
                aria-label="Email summaries"
              />
            </Row>
          </div>
        </Section>

        <Section icon={Bell} title="Saved alerts">
          <NotificationInbox />
        </Section>
        <Section icon={Monitor} title="Install LYFEADMIN">
          <InstallControl />
        </Section>
        <Section icon={ShieldCheck} title="Connected Services">
          <p className="text-sm text-muted-foreground">
            No external services are connected. Email discovery and background device push are
            unavailable until configured. Receipt reading only accesses the file you explicitly
            select and approve sharing.
          </p>
        </Section>

        <Section id="preferences" icon={Palette} title="Appearance">
          <div className="grid grid-cols-3 gap-2">
            {(
              [
                ["light", "Light", Sun],
                ["dark", "Dark", Moon],
                ["system", "System", Monitor],
              ] as const
            ).map(([v, l, I]) => (
              <Button
                variant="ghost"
                aria-pressed={theme === v}
                key={v}
                onClick={() => update.mutate({ theme: v })}
                className={cn(
                  "flex h-auto flex-col items-center gap-2 rounded-lg border-2 p-4 text-sm font-semibold transition-colors",
                  theme === v
                    ? "border-brand-ink bg-brand-soft"
                    : "border-border hover:border-brand-ink/40",
                )}
              >
                <I className="size-5" /> {l}
              </Button>
            ))}
          </div>
        </Section>

        <Section icon={Palette} title="Decorative effects">
          <Row
            label="Decorative mouse effects"
            hint="Subtle glow and button movement on this browser. Off on touchscreens and with reduced motion."
          >
            <Switch
              aria-label="Decorative mouse effects"
              checked={effects.enabled}
              onCheckedChange={effects.toggle}
            />
          </Row>
        </Section>

        <Section icon={Volume2} title="Sounds" description="Short, soft sounds after you click, navigate, save or send.">
          <div className="space-y-4">
            <Row label="Interface sounds" hint="Never plays when the app first opens. Turn off for complete silence.">
              <Switch aria-label="Interface sounds" checked={sounds.prefs.enabled} onCheckedChange={(v) => sounds.update({ enabled: v })} />
            </Row>
            <Row label="Volume" hint={`${Math.round(sounds.prefs.volume * 100)}%`}>
              <Slider
                aria-label="Sound volume"
                className="w-40"
                disabled={!sounds.prefs.enabled}
                min={0}
                max={100}
                step={5}
                value={[Math.round(sounds.prefs.volume * 100)]}
                onValueChange={([v = 0]) => sounds.update({ volume: v / 100 })}
                onValueCommit={([v = 0]) => playSound("success", { enabled: true, volume: v / 100 })}
              />
            </Row>
          </div>
        </Section>

        <Section icon={Lock} title="Account security">
          {isEmailUser ? (
            <form onSubmit={changePassword} className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label htmlFor="pw-c">Current password</Label>
                <Input
                  id="pw-c"
                  type="password"
                  autoComplete="current-password"
                  value={pw.current}
                  onChange={(e) => setPw({ ...pw, current: e.target.value })}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="pw-n">New password</Label>
                <Input
                  id="pw-n"
                  type="password"
                  autoComplete="new-password"
                  value={pw.next}
                  onChange={(e) => setPw({ ...pw, next: e.target.value })}
                />
              </div>
              <div className="flex flex-wrap gap-2 sm:col-span-2">
                <Button type="submit" variant="brand" disabled={pwBusy}>
                  {pwBusy && <Loader2 className="animate-spin" />} Change password
                </Button>
                <Button type="button" variant="ghost" onClick={resetByEmail}>
                  Email me a reset link
                </Button>
              </div>
            </form>
          ) : (
            <p className="text-sm text-muted-foreground">
              You sign in with{" "}
              {user?.app_metadata?.provider === "google" ? "Google" : "an external account"}, so
              your password is managed there.
            </p>
          )}
        </Section>

        <Section icon={ShieldCheck} title="Privacy">
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li>
              • Your reminders, documents, subscriptions and checklists are visible only to your
              account.
            </li>
            <li>
              • Documents are stored in private storage and open via links that expire within
              minutes.
            </li>
            <li>
              • The AI assistant only sees your messages — and your reminders and checklists only
              when you switch on sharing for that chat.
            </li>
            <li>• LYFEADMIN never connects to your bank or takes payments.</li>
          </ul>
        </Section>

        <Button variant="outline" size="lg" className="w-full text-destructive" onClick={signOut}>
          <LogOut /> Log out
        </Button>

        <Section
          icon={Trash2}
          title="Delete account"
          description="Permanently remove your account, documents and all saved information."
        >
          <ConfirmDelete
            title="Delete your account?"
            description="This permanently deletes your reminders, documents, subscriptions, checklists and conversations. It can't be undone."
            onConfirm={() => delAccount.mutate()}
            trigger={
              <Button variant="destructive" disabled={delAccount.isPending}>
                {delAccount.isPending ? <Loader2 className="animate-spin" /> : <Trash2 />} Delete my
                account
              </Button>
            }
          />
        </Section>
      </div>
    </div>
  );
}

function Row({ label, hint, children }: { label: string; hint: string; children: ReactNode }) {
  return (
    <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 max-sm:[&>button]:col-span-2 max-sm:[&>button]:justify-self-start">
      <div className="min-w-0">
        <p className="text-base font-medium">{label}</p>
        <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{hint}</p>
      </div>
      {children}
    </div>
  );
}
