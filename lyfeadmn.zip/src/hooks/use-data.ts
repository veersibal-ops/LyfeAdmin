import { queryOptions, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

type Tables = Database["public"]["Tables"];
export type Reminder = Tables["reminders"]["Row"];
export type Doc = Tables["documents"]["Row"];
export type Subscription = Tables["subscriptions"]["Row"];
export type Checklist = Tables["checklists"]["Row"];
export type ChecklistItem = Tables["checklist_items"]["Row"];
export type Activity = Tables["activity_logs"]["Row"];
export type Profile = Tables["profiles"]["Row"];

type Res = { data: unknown; error: { message: string } | null };
function unwrap<R extends Res>(res: R): NonNullable<R["data"]> {
  if (res.error) throw new Error(res.error.message);
  return res.data as NonNullable<R["data"]>;
}
/** For maybeSingle() lookups where "no row" is a valid answer. */
function unwrapMaybe<R extends Res>(res: R): R["data"] {
  if (res.error) throw new Error(res.error.message);
  return res.data;
}

export async function logActivity(
  action: Tables["activity_logs"]["Insert"]["action"],
  entity_type: string,
  title: string,
  entity_id?: string,
) {
  const { error } = await supabase
    .from("activity_logs")
    .insert({ action, entity_type, title, entity_id: entity_id ?? null });
  if (error) console.error("activity log failed", error.message);
}

// ---------- Profile ----------
export const profileQuery = queryOptions({
  queryKey: ["profile"],
  staleTime: 60_000,
  queryFn: async () => {
    const { data: s } = await supabase.auth.getSession();
    const uid = s.session?.user.id;
    if (!uid) throw new Error("Not signed in");
    return unwrapMaybe(await supabase.from("profiles").select("*").eq("id", uid).maybeSingle());
  },
});
export const useProfile = () => useQuery(profileQuery);

export function useUpdateProfile() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (patch: Tables["profiles"]["Update"]) => {
      const { data: u } = await supabase.auth.getUser();
      if (!u.user) throw new Error("Not signed in");
      return unwrap(
        await supabase
          .from("profiles")
          .upsert({ id: u.user.id, ...patch })
          .select()
          .single(),
      );
    },
    onSuccess: (p) => qc.setQueryData(profileQuery.queryKey, p),
    onError: (e: Error) => toast.error(e.message),
  });
}

// ---------- Generic list ----------
export const useReminders = () =>
  useQuery({
    queryKey: ["reminders"],
    queryFn: async () => unwrap(await supabase.from("reminders").select("*").order("due_at")),
  });
export const useDocuments = () =>
  useQuery({
    queryKey: ["documents"],
    queryFn: async () =>
      unwrap(
        await supabase.from("documents").select("*").order("created_at", { ascending: false }),
      ),
  });
export const useSubscriptions = () =>
  useQuery({
    queryKey: ["subscriptions"],
    queryFn: async () =>
      unwrap(await supabase.from("subscriptions").select("*").order("next_renewal")),
  });
export const useChecklists = () =>
  useQuery({
    queryKey: ["checklists"],
    queryFn: async () =>
      unwrap(
        await supabase
          .from("checklists")
          .select("*, checklist_items(id, completed)")
          .order("updated_at", { ascending: false }),
      ),
  });
export const useChecklist = (id: string) =>
  useQuery({
    queryKey: ["checklist", id],
    queryFn: async () =>
      unwrapMaybe(
        await supabase
          .from("checklists")
          .select("*, checklist_items(*)")
          .eq("id", id)
          .order("position", { referencedTable: "checklist_items" })
          .maybeSingle(),
      ),
  });
export const useActivity = () =>
  useQuery({
    queryKey: ["activity"],
    queryFn: async () =>
      unwrap(
        await supabase
          .from("activity_logs")
          .select("*")
          .order("created_at", { ascending: false })
          .limit(12),
      ),
  });

/** Wraps a mutation with toast + invalidation of the given keys + activity refresh. */
export function useAction<V, R = unknown>(
  fn: (v: V) => Promise<R>,
  opts: { keys: string[][]; success?: string | ((v: V) => string) },
) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: fn,
    onSuccess: (_r, v) => {
      for (const k of [...opts.keys, ["activity"]]) qc.invalidateQueries({ queryKey: k });
      const msg = typeof opts.success === "function" ? opts.success(v) : opts.success;
      if (msg) toast.success(msg);
    },
    onError: (e: Error) => toast.error(e.message || "Something went wrong"),
  });
}

export { unwrap, unwrapMaybe };
