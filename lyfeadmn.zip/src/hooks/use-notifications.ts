import { playSound } from "@/lib/sounds";
import { useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { Profile } from "./use-data";

/**
 * Browser notifications for upcoming reminders while LifeAdmin is open.
 * Checks every minute and notifies once per reminder when it enters the user's
 * chosen lead time. Background mobile push will plug in here via a service worker later.
 */
export function useReminderNotifications(profile: Profile | null) {
  useEffect(() => {
    if (!profile?.notify_push || typeof Notification === "undefined") return;
    if (Notification.permission !== "granted") return;
    const uid = profile.id;
    const key = `la-notified:${uid}`;
    const check = async () => {
      const refreshed = await supabase.rpc("refresh_my_notifications");
      if (refreshed.error) throw refreshed.error;
      const { data, error } = await supabase.from("notifications").select("id,kind,title,body").is("read_at", null).gte("created_at", new Date(Date.now() - 60 * 60_000).toISOString()).limit(30);
      if (error) throw error;
      let seen: string[] = [];
      try { const stored: unknown = JSON.parse(localStorage.getItem(key) ?? "[]"); if (Array.isArray(stored)) seen = stored.filter((x): x is string => typeof x === "string"); } catch { /* discard invalid device cache */ }
      for (const n of data ?? []) {
        if (seen.includes(n.id) || (n.kind === "reminder" && !profile.notify_reminders) || (n.kind === "renewal" && !profile.notify_renewals)) continue;
        const display = async () => {
          if (seen.includes(n.id)) return;
          const options = { body: n.body, icon: "/lifeadmin-192.png", tag: n.id, data: { kind: n.kind } };
          const registration = 'serviceWorker' in navigator ? await navigator.serviceWorker.getRegistration() : undefined;
          if (registration) await registration.showNotification(n.title, options);
          else {
            const notification = new Notification(n.title, options);
            notification.onclick = () => { window.focus(); window.location.assign(n.kind === "reminder" ? "/reminders" : "/subscriptions"); };
          }
          playSound("notify");
          seen.push(n.id);
          localStorage.setItem(key, JSON.stringify(seen.slice(-200)));
        };
        if (navigator.locks) await navigator.locks.request(`lifeadmin-alert:${uid}`, async () => {
          seen = JSON.parse(localStorage.getItem(key) ?? "[]");
          await display();
        });
        else await display();
      }
    };
    check().catch(console.error);
    const t = setInterval(() => check().catch(console.error), 60_000);
    return () => clearInterval(t);
  }, [profile?.id, profile?.notify_push, profile?.notify_lead_minutes, profile?.notify_reminders, profile?.notify_renewals]);
}
