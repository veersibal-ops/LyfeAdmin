import { addDays, differenceInCalendarDays, isSameDay, parseISO, startOfDay } from "date-fns";

type R = { id: string; due_at: string; completed: boolean };
type S = { active: boolean; next_renewal: string };

/** Dashboard reminder figures, all derived from saved reminders. */
export function reminderStats<T extends R>(reminders: T[], now = new Date()) {
  const due = (r: T) => new Date(r.due_at);
  const today = reminders.filter((r) => isSameDay(due(r), now));
  const overdue = reminders.filter((r) => !r.completed && due(r) < now);
  const weekEnd = addDays(startOfDay(now), 8);
  const upcoming = reminders
    .filter((r) => !r.completed && due(r) >= now && !isSameDay(due(r), now) && due(r) < weekEnd)
    .sort((a, b) => due(a).getTime() - due(b).getTime())
    .slice(0, 5);
  // Overdue first, then the rest of today — each reminder appears once.
  const seen = new Set<string>();
  const attention = [...overdue, ...today].filter((r) =>
    seen.has(r.id) ? false : (seen.add(r.id), true),
  );
  return { today, todayDone: today.filter((r) => r.completed).length, overdue, upcoming, attention };
}

/** Active subscriptions renewing today or later, soonest first. */
export function upcomingRenewals<T extends S>(subs: T[], now = new Date(), limit = 4) {
  return subs
    .filter((x) => x.active && differenceInCalendarDays(parseISO(x.next_renewal), now) >= 0)
    .sort((a, b) => a.next_renewal.localeCompare(b.next_renewal))
    .slice(0, limit);
}
