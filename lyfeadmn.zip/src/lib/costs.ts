export type Frequency = "weekly" | "monthly" | "quarterly" | "yearly";

const PER_YEAR: Record<Frequency, number> = { weekly: 52, monthly: 12, quarterly: 4, yearly: 1 };

/** Estimated yearly cost of one subscription. */
export function yearlyCost(amount: number, frequency: Frequency): number {
  return round2(amount * PER_YEAR[frequency]);
}

/** Estimated monthly cost of one subscription (yearly spread over 12 months). */
export function monthlyCost(amount: number, frequency: Frequency): number {
  return round2((amount * PER_YEAR[frequency]) / 12);
}

export function totals(subs: { amount: number; frequency: Frequency; active: boolean }[]) {
  const active = subs.filter((s) => s.active);
  const yearly = round2(active.reduce((t, s) => t + Number(s.amount) * PER_YEAR[s.frequency], 0));
  return { monthly: round2(yearly / 12), yearly };
}

function round2(n: number) {
  return Math.round(n * 100) / 100;
}

export function formatMoney(n: number, currency = "AUD") {
  return new Intl.NumberFormat(undefined, { style: "currency", currency }).format(n);
}
