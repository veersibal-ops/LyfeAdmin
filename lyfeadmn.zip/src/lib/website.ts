// Links to the published LYFEADMIN marketing website.
// Kept separate from the app's internal navigation (NAV in app-shell.tsx).
export const WEBSITE_URL = "https://lyfeadmin.lovable.app";

export const WEBSITE_LINKS = [
  { href: `${WEBSITE_URL}/about`, label: "About LYFEADMIN" },
  { href: `${WEBSITE_URL}/contact`, label: "Help & Contact" },
  { href: `${WEBSITE_URL}/privacy`, label: "Privacy Policy" },
  { href: `${WEBSITE_URL}/terms`, label: "Terms of Service" },
] as const;
