import { z } from "zod";
import type { UIMessage } from "ai";

export const assistantAction = z.discriminatedUnion("kind", [
  z.object({
    kind: z.literal("reminder"),
    title: z.string().trim().min(1).max(200),
    due_at: z.string().datetime({ offset: true }),
    description: z.string().max(2000),
  }),
  z.object({
    kind: z.literal("checklist"),
    title: z.string().trim().min(1).max(200),
    items: z.array(z.string().trim().min(1).max(500)).min(1).max(40),
  }),
]);
export type AssistantAction = z.infer<typeof assistantAction>;
const saved = z.object({ text: z.string(), action: assistantAction.optional() });
const PREFIX = "LYFEADMIN_ASSISTANT_V1:";
export function encodeAssistant(text: string, action?: AssistantAction) {
  return PREFIX + JSON.stringify({ text, action });
}
export function decodeAssistant(content: string): {
  text: string;
  action?: AssistantAction | undefined;
} {
  if (!content.startsWith(PREFIX)) return { text: content };
  try {
    return saved.parse(JSON.parse(content.slice(PREFIX.length)));
  } catch {
    return { text: content };
  }
}
export function assistantParts(content: string): UIMessage["parts"] {
  const { text, action } = decodeAssistant(content);
  return [
    { type: "text", text },
    ...(action
      ? [
          {
            type: "dynamic-tool" as const,
            toolName: action.kind === "reminder" ? "Create reminder" : "Create checklist",
            toolCallId: "proposal",
            state: "approval-requested" as const,
            input: action,
            approval: { id: "proposal" },
          },
        ]
      : []),
  ];
}
export const chatEvent = z.discriminatedUnion("type", [
  z.object({ type: z.literal("text"), delta: z.string() }),
  z.object({ type: z.literal("action"), action: assistantAction }),
  z.object({ type: z.literal("saved"), id: z.string().uuid() }),
  z.object({ type: z.literal("error"), message: z.string() }),
]);
