export type Errs = {
  [
    K in
      "file" | "title" | "date" | "time" | "description" | "name" | "amount" | "email" | "password"
  ]?: string;
};
export const hasErrs = (e: Errs) => Object.values(e).some(Boolean);
