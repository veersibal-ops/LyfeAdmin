import { z } from "zod";

export const extractedReceipt = z.object({
  name: z.string().trim().max(120).nullable(),
  amount: z.number().min(0).max(1_000_000).nullable(),
  currency: z.string().regex(/^[A-Z]{3}$/).nullable(),
  frequency: z.enum(["weekly", "monthly", "quarterly", "yearly"]).nullable(),
  next_renewal: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).nullable(),
});
export const receiptInput = z.object({
  name: z.string().min(1).max(200),
  type: z.enum(["application/pdf", "image/png", "image/jpeg", "text/plain"]),
  data: z.string().min(1).max(7_000_000).regex(/^[A-Za-z0-9+/]+={0,2}$/),
  consent: z.literal(true),
});

export function mayRequestNotificationPermission(permission: string, supported: boolean, framed: boolean) {
  return supported && !framed && permission === "default";
}