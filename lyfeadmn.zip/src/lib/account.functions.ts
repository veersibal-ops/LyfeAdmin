import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/** Permanently deletes the signed-in user's files, records and login. */
export const deleteMyAccount = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { userId } = context;
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    // Stored files under the user's private folder.
    const { data: files, error: listErr } = await supabaseAdmin.storage
      .from("documents")
      .list(userId, { limit: 1000 });
    if (listErr) throw new Error("Couldn't remove your documents: " + listErr.message);
    if (files?.length) {
      const { error } = await supabaseAdmin.storage
        .from("documents")
        .remove(files.map((f) => `${userId}/${f.name}`));
      if (error) throw new Error("Couldn't remove your documents: " + error.message);
    }

    // Child tables first; checklist items and chat messages cascade from their parents.
    for (const t of [
      "chat_threads",
      "notifications",
      "subscription_suggestions",
      "checklists",
      "reminders",
      "documents",
      "subscriptions",
      "activity_logs",
    ] as const) {
      const { error } = await supabaseAdmin.from(t).delete().eq("user_id", userId);
      if (error) throw new Error(`Couldn't delete your ${t.replace("_", " ")}: ${error.message}`);
    }

    const { error } = await supabaseAdmin.auth.admin.deleteUser(userId);
    if (error) throw new Error("Couldn't delete your login: " + error.message);
    return { ok: true };
  });
