import {
  CalendarHeart,
  CalendarClock,
  Receipt,
  User,
  ListTodo,
  ShieldCheck,
  FileText,
  Home,
  Folder,
  Tv,
  Zap,
  Laptop,
  HeartPulse,
  UtensilsCrossed,
  Umbrella,
  Package,
  ShoppingCart,
  Plane,
  Truck,
  Sparkle,
  PartyPopper,
  ClipboardList,
  type LucideIcon,
} from "lucide-react";

type Opt<T extends string> = { value: T; label: string; icon: LucideIcon; tone: string };

export const REMINDER_CATEGORIES = [
  {
    value: "appointment",
    label: "Appointment",
    icon: CalendarClock,
    tone: "bg-brand-soft text-accent-foreground",
  },
  { value: "personal", label: "Personal task", icon: User, tone: "bg-success-soft text-success" },
  { value: "bill", label: "Bill", icon: Receipt, tone: "bg-warning-soft text-warning" },
  {
    value: "important_date",
    label: "Important date",
    icon: CalendarHeart,
    tone: "bg-danger-soft text-destructive",
  },
  { value: "general", label: "General", icon: ListTodo, tone: "bg-muted text-muted-foreground" },
] as const satisfies readonly Opt<string>[];
export type ReminderCategory = (typeof REMINDER_CATEGORIES)[number]["value"];

export const DOCUMENT_CATEGORIES = [
  { value: "receipt", label: "Receipts", icon: Receipt, tone: "bg-warning-soft text-warning" },
  {
    value: "warranty",
    label: "Warranties",
    icon: ShieldCheck,
    tone: "bg-success-soft text-success",
  },
  {
    value: "personal",
    label: "Personal documents",
    icon: FileText,
    tone: "bg-brand-soft text-accent-foreground",
  },
  {
    value: "household",
    label: "Household documents",
    icon: Home,
    tone: "bg-danger-soft text-destructive",
  },
  { value: "other", label: "Other", icon: Folder, tone: "bg-muted text-muted-foreground" },
] as const satisfies readonly Opt<string>[];
export type DocumentCategory = (typeof DOCUMENT_CATEGORIES)[number]["value"];

export const SUBSCRIPTION_CATEGORIES = [
  {
    value: "entertainment",
    label: "Entertainment",
    icon: Tv,
    tone: "bg-danger-soft text-destructive",
  },
  { value: "utilities", label: "Utilities", icon: Zap, tone: "bg-warning-soft text-warning" },
  {
    value: "software",
    label: "Software",
    icon: Laptop,
    tone: "bg-brand-soft text-accent-foreground",
  },
  {
    value: "health",
    label: "Health & fitness",
    icon: HeartPulse,
    tone: "bg-success-soft text-success",
  },
  { value: "food", label: "Food", icon: UtensilsCrossed, tone: "bg-warning-soft text-warning" },
  {
    value: "insurance",
    label: "Insurance",
    icon: Umbrella,
    tone: "bg-brand-soft text-accent-foreground",
  },
  { value: "other", label: "Other", icon: Package, tone: "bg-muted text-muted-foreground" },
] as const satisfies readonly Opt<string>[];
export type SubscriptionCategory = (typeof SUBSCRIPTION_CATEGORIES)[number]["value"];

export const FREQUENCIES = [
  { value: "weekly", label: "Weekly" },
  { value: "monthly", label: "Monthly" },
  { value: "quarterly", label: "Quarterly" },
  { value: "yearly", label: "Yearly" },
] as const;

export const CHECKLIST_CATEGORIES = [
  {
    value: "shopping",
    label: "Shopping",
    icon: ShoppingCart,
    tone: "bg-success-soft text-success",
  },
  { value: "holiday", label: "Holiday", icon: Plane, tone: "bg-brand-soft text-accent-foreground" },
  { value: "moving", label: "Moving house", icon: Truck, tone: "bg-warning-soft text-warning" },
  {
    value: "cleaning",
    label: "Cleaning",
    icon: Sparkle,
    tone: "bg-brand-soft text-accent-foreground",
  },
  {
    value: "general",
    label: "General",
    icon: ClipboardList,
    tone: "bg-muted text-muted-foreground",
  },
  { value: "event", label: "Event", icon: PartyPopper, tone: "bg-danger-soft text-destructive" },
] as const satisfies readonly Opt<string>[];
export type ChecklistCategory = (typeof CHECKLIST_CATEGORIES)[number]["value"];

export function findOpt<T extends { value: string }>(list: readonly T[], v: string): T {
  return list.find((o) => o.value === v) ?? (list[list.length - 1] as T);
}

/** Built-in starter templates. Users can also save their own checklists as templates. */
export const BUILTIN_TEMPLATES: { title: string; category: ChecklistCategory; items: string[] }[] =
  [
    {
      title: "Weekly shop",
      category: "shopping",
      items: [
        "Fruit & vegetables",
        "Milk & eggs",
        "Bread",
        "Cleaning supplies",
        "Toiletries",
        "Snacks",
      ],
    },
    {
      title: "Holiday packing",
      category: "holiday",
      items: [
        "Passport & ID",
        "Travel insurance",
        "Chargers & adaptors",
        "Medications",
        "Clothes for each day",
        "Toiletries bag",
        "Book flights & accommodation",
        "Arrange pet/house sitter",
      ],
    },
    {
      title: "Moving house",
      category: "moving",
      items: [
        "Book removalists",
        "Update address with bank",
        "Redirect mail",
        "Transfer electricity & internet",
        "Pack room by room",
        "Clean old place",
        "Return keys",
        "Update driver licence",
      ],
    },
    {
      title: "Deep clean",
      category: "cleaning",
      items: [
        "Dust surfaces",
        "Vacuum & mop floors",
        "Clean bathroom",
        "Clean kitchen & oven",
        "Wash bedding",
        "Wipe windows",
        "Take out bins",
      ],
    },
    {
      title: "Getting things done",
      category: "general",
      items: [
        "Write down everything on your mind",
        "Pick top 3 priorities",
        "Block time in calendar",
        "Clear inbox",
      ],
    },
    {
      title: "Event planning",
      category: "event",
      items: [
        "Set date & budget",
        "Create guest list",
        "Book venue",
        "Send invitations",
        "Order food & drinks",
        "Plan decorations",
        "Confirm RSVPs",
      ],
    },
  ];
