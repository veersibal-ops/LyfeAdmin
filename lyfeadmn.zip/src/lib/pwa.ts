export function isPwaBlocked(hostname: string, production: boolean, framed: boolean, disabled: boolean) {
  const host = hostname.toLowerCase();
  const lovableHost = /\.(lovable\.app|gpt-eng\.com|gptengineer\.run)$/.test(host);
  return !production || framed || disabled ||
    (lovableHost && /^(?:id-preview|preview)(?:-[a-z0-9]+)?--.+$/.test(host.split('.')[0] ?? '')) ||
    (lovableHost && host.startsWith('project--a91294a2-984e-44ec-b2f4-85752961d6b1-dev.')) ||
    /(^|\.)(lovableproject\.com|lovableproject-dev\.com|beta\.lovable\.dev)$/.test(host);
}

export async function registerLifeAdminWorker() {
  if (!('serviceWorker' in navigator)) return;
  if (isPwaBlocked(window.location.hostname, import.meta.env.PROD, window.top !== window.self, new URLSearchParams(window.location.search).get('sw') === 'off')) {
    const registrations = await navigator.serviceWorker.getRegistrations();
    await Promise.all(registrations.filter(r => [r.active, r.waiting, r.installing].some(w => w && new URL(w.scriptURL).pathname === '/sw.js')).map(r => r.unregister()));
    return;
  }
  const { registerSW } = await import('virtual:pwa-register');
  registerSW({ immediate: true });
}