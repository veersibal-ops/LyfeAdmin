/** Original, synthesized interface sounds (Web Audio). Silent when unavailable or disabled. */
export type SoundName = "click" | "nav" | "open" | "close" | "success" | "notify" | "send";

const KEY = "la-sounds";
export type SoundPrefs = { enabled: boolean; volume: number };
export const DEFAULT_SOUND_PREFS: SoundPrefs = { enabled: true, volume: 0.6 };

export function readSoundPrefs(): SoundPrefs {
  try {
    const v = JSON.parse(localStorage.getItem(KEY) ?? "null");
    if (v && typeof v.enabled === "boolean" && typeof v.volume === "number")
      return { enabled: v.enabled, volume: Math.min(1, Math.max(0, v.volume)) };
  } catch {
    /* ignore */
  }
  return DEFAULT_SOUND_PREFS;
}
export function writeSoundPrefs(p: SoundPrefs) {
  localStorage.setItem(KEY, JSON.stringify(p));
  window.dispatchEvent(new Event("la-sounds-change"));
}

// [frequency Hz, start offset s, duration s]
const NOTES: Record<SoundName, [number, number, number][]> = {
  click: [[880, 0, 0.05]],
  nav: [[660, 0, 0.07]],
  open: [[520, 0, 0.06], [780, 0.04, 0.07]],
  close: [[780, 0, 0.06], [520, 0.04, 0.07]],
  success: [[660, 0, 0.1], [880, 0.08, 0.1], [1175, 0.16, 0.18]],
  notify: [[988, 0, 0.12], [740, 0.12, 0.2]],
  send: [[600, 0, 0.06], [1040, 0.05, 0.1]],
};
const PRIORITY: Record<SoundName, number> = { click: 0, nav: 1, open: 1, close: 1, send: 2, success: 3, notify: 3 };

let ctx: AudioContext | null = null;
let busyUntil = 0;
let busyPriority = -1;
let interacted = false;
if (typeof window !== "undefined") {
  const mark = () => (interacted = true);
  window.addEventListener("pointerdown", mark, { capture: true, passive: true });
  window.addEventListener("keydown", mark, { capture: true });
}

/** Plays only after a user gesture; drops overlapping lower-priority sounds. */
export function playSound(name: SoundName, prefs: SoundPrefs = readSoundPrefs()) {
  try {
    if (!interacted || !prefs.enabled || prefs.volume <= 0) return;
    const Ctor = window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!Ctor) return;
    ctx ??= new Ctor();
    if (ctx.state === "suspended") void ctx.resume();
    const now = ctx.currentTime;
    if (now < busyUntil && PRIORITY[name] <= busyPriority) return;
    const master = ctx.createGain();
    master.gain.value = 0.22 * prefs.volume;
    master.connect(ctx.destination);
    let end = now;
    for (const [f, off, dur] of NOTES[name]) {
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.type = "sine";
      o.frequency.value = f;
      const t = now + off;
      g.gain.setValueAtTime(0, t);
      g.gain.linearRampToValueAtTime(1, t + 0.008);
      g.gain.exponentialRampToValueAtTime(0.001, t + dur);
      o.connect(g).connect(master);
      o.start(t);
      o.stop(t + dur + 0.02);
      end = Math.max(end, t + dur);
    }
    busyUntil = end;
    busyPriority = PRIORITY[name];
  } catch {
    /* silent fallback */
  }
}
