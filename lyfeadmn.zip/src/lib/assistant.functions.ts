import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";
import { decodeAssistant } from "@/lib/assistant";

export const confirmAssistantAction = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ messageId: z.string().uuid(), confirmed: z.literal(true) }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const db = context.supabase;
    const { data: message, error } = await db
      .from("chat_messages")
      .select("content,role")
      .eq("id", data.messageId)
      .eq("user_id", context.userId)
      .single();
    if (error || message?.role !== "assistant")
      throw new Error("This saved proposal is unavailable.");
    const { action } = decodeAssistant(message.content);
    if (!action) throw new Error("There is no action to confirm.");
    // The saved message UUID is also the created entity UUID: retries cannot create duplicates.
    const entity = action.kind === "reminder" ? "reminders" : "checklists";
    const { data: existing, error: readError } = await db
      .from(entity)
      .select("id")
      .eq("id", data.messageId)
      .eq("user_id", context.userId)
      .maybeSingle();
    if (readError) throw new Error(readError.message);
    if (action.kind === "reminder") {
      const result = await db.from("reminders").upsert(
        {
          id: data.messageId,
          user_id: context.userId,
          title: action.title,
          description: action.description,
          due_at: action.due_at,
          category: "general",
        },
        { onConflict: "id", ignoreDuplicates: true },
      );
      if (result.error)
        throw new Error("Couldn't save your reminder. Your proposal is still available.");
    } else {
      const list = await db
        .from("checklists")
        .upsert(
          { id: data.messageId, user_id: context.userId, title: action.title, category: "general" },
          { onConflict: "id", ignoreDuplicates: true },
        );
      if (list.error) throw new Error("Couldn't save your checklist.");
      const items = await db.from("checklist_items").upsert(
        action.items.map((content, position) => ({
          id: `${data.messageId.slice(0, 28)}${position.toString(16).padStart(8, "0")}`,
          user_id: context.userId,
          checklist_id: data.messageId,
          content,
          position,
        })),
        { onConflict: "id", ignoreDuplicates: true },
      );
      if (items.error)
        throw new Error(
          "Your checklist was saved, but some items couldn't be saved. Confirm again to finish it safely.",
        );
    }
    if (!existing) {
      const log = await db.from("activity_logs").insert({
        id: data.messageId,
        user_id: context.userId,
        action: "created",
        entity_type: action.kind,
        entity_id: data.messageId,
        title: action.title,
      });
      if (log.error) console.error("Assistant activity log failed", log.error.message);
    }
    return { id: data.messageId, kind: action.kind };
  });
