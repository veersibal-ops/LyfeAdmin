import { useEffect, useState, type FormEvent } from "react";
import type { Errs } from "@/lib/form";
import { format } from "date-fns";
import { Loader2 } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { REMINDER_CATEGORIES, type ReminderCategory } from "@/lib/constants";
import { supabase } from "@/integrations/supabase/client";
import { logActivity, unwrap, useAction, type Reminder } from "@/hooks/use-data";

export function ReminderDialog({
  open,
  onOpenChange,
  reminder,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  reminder?: Reminder | null;
}) {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState<ReminderCategory>("general");
  const [date, setDate] = useState("");
  const [time, setTime] = useState("09:00");
  const [errors, setErrors] = useState<Errs>({});

  useEffect(() => {
    if (!open) return;
    const d = reminder ? new Date(reminder.due_at) : new Date(Date.now() + 86400000);
    setTitle(reminder?.title ?? "");
    setDescription(reminder?.description ?? "");
    setCategory((reminder?.category as ReminderCategory) ?? "general");
    setDate(format(d, "yyyy-MM-dd"));
    setTime(reminder ? format(d, "HH:mm") : "09:00");
    setErrors({});
  }, [open, reminder]);

  const save = useAction(
    async () => {
      const payload = {
        title: title.trim(),
        description: description.trim() || null,
        category,
        due_at: new Date(`${date}T${time}`).toISOString(),
      };
      if (reminder) {
        unwrap(
          await supabase.from("reminders").update(payload).eq("id", reminder.id).select().single(),
        );
        await logActivity("updated", "reminder", payload.title, reminder.id);
      } else {
        const r = unwrap(await supabase.from("reminders").insert(payload).select().single());
        await logActivity("created", "reminder", payload.title, r.id);
      }
    },
    { keys: [["reminders"]], success: reminder ? "Reminder updated" : "Reminder created" },
  );

  function submit(e: FormEvent) {
    e.preventDefault();
    const errs: Errs = {};
    if (!title.trim()) errs.title = "Give your reminder a title";
    if (title.length > 200) errs.title = "Keep the title under 200 characters";
    if (!date) errs.date = "Pick a date";
    if (!time) errs.time = "Pick a time";
    if (description.length > 2000) errs.description = "Description is too long";
    setErrors(errs);
    if (Object.keys(errs).length) return;
    save.mutate(undefined, { onSuccess: () => onOpenChange(false) });
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="rounded-2xl sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{reminder ? "Edit reminder" : "New reminder"}</DialogTitle>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-4" noValidate>
          <div className="space-y-1.5">
            <Label htmlFor="r-title">Title</Label>
            <Input
              id="r-title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Dentist appointment"
            />
            {errors.title && <p className="text-xs text-destructive">{errors.title}</p>}
          </div>
          <div className="space-y-1.5">
            <Label>Category</Label>
            <Select value={category} onValueChange={(v) => setCategory(v as ReminderCategory)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {REMINDER_CATEGORIES.map((c) => (
                  <SelectItem key={c.value} value={c.value}>
                    {c.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="r-date">Date</Label>
              <Input
                id="r-date"
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
              />
              {errors.date && <p className="text-xs text-destructive">{errors.date}</p>}
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="r-time">Time</Label>
              <Input
                id="r-time"
                type="time"
                value={time}
                onChange={(e) => setTime(e.target.value)}
              />
              {errors.time && <p className="text-xs text-destructive">{errors.time}</p>}
            </div>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="r-desc">Description (optional)</Label>
            <Textarea
              id="r-desc"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
            />
            {errors.description && <p className="text-xs text-destructive">{errors.description}</p>}
          </div>
          <DialogFooter className="gap-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="brand" disabled={save.isPending}>
              {save.isPending && <Loader2 className="animate-spin" />}{" "}
              {reminder ? "Save changes" : "Create reminder"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export function useToggleReminder() {
  return useAction(
    async (r: Reminder) => {
      const completed = !r.completed;
      unwrap(
        await supabase
          .from("reminders")
          .update({ completed, completed_at: completed ? new Date().toISOString() : null })
          .eq("id", r.id)
          .select()
          .single(),
      );
      if (completed) await logActivity("completed", "reminder", r.title, r.id);
    },
    {
      keys: [["reminders"]],
      success: (r) => (r.completed ? "Marked as not done" : "Nice work — reminder completed"),
    },
  );
}

export function useDeleteReminder() {
  return useAction(
    async (r: Reminder) => {
      unwrap(await supabase.from("reminders").delete().eq("id", r.id).select());
      await logActivity("deleted", "reminder", r.title);
    },
    { keys: [["reminders"]], success: "Reminder deleted" },
  );
}
