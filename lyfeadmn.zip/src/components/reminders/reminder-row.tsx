import { format, isPast, isToday, isTomorrow } from "date-fns";
import { Check, Pencil, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { CategoryBadge } from "@/components/app/page";
import { ConfirmDelete } from "@/components/app/confirm-dialog";
import { REMINDER_CATEGORIES, findOpt } from "@/lib/constants";
import { cn } from "@/lib/utils";
import type { Reminder } from "@/hooks/use-data";
import { useDeleteReminder, useToggleReminder } from "./reminder-dialog";

export function dueLabel(d: Date) {
  if (isToday(d)) return `Today, ${format(d, "h:mm a")}`;
  if (isTomorrow(d)) return `Tomorrow, ${format(d, "h:mm a")}`;
  return format(d, "EEE d MMM, h:mm a");
}

export function ReminderRow({
  r,
  onEdit,
  compact,
}: {
  r: Reminder;
  onEdit?: (r: Reminder) => void;
  compact?: boolean;
}) {
  const toggle = useToggleReminder();
  const del = useDeleteReminder();
  const due = new Date(r.due_at);
  const overdue = !r.completed && isPast(due);
  const cat = findOpt(REMINDER_CATEGORIES, r.category);
  return (
    <div
      className={cn(
        "card-surface card-hover flex items-start gap-3 p-3.5 sm:p-4",
        r.completed && "opacity-60",
      )}
    >
      <Button
        variant="ghost"
        onClick={() => toggle.mutate(r)}
        aria-label={r.completed ? "Mark as not done" : "Mark as done"}
        className={cn(
          "mt-0.5 grid size-8 shrink-0 place-items-center rounded-lg border-2 p-0 transition-all sm:size-6",
          r.completed
            ? "border-success bg-success text-success-foreground"
            : "border-input hover:border-brand-ink",
        )}
      >
        {r.completed && <Check className="size-3.5" />}
      </Button>
      <div className="min-w-0 flex-1">
        <p className={cn("font-semibold break-words", r.completed && "line-through")}>{r.title}</p>
        {!compact && r.description && (
          <p className="mt-0.5 text-sm text-muted-foreground break-words">{r.description}</p>
        )}
        <div className="mt-1.5 flex flex-wrap items-center gap-2">
          <span
            className={cn(
              "text-xs font-semibold",
              overdue ? "text-destructive" : "text-muted-foreground",
            )}
          >
            {overdue && "Overdue · "}
            {dueLabel(due)}
          </span>
          <CategoryBadge icon={cat.icon} label={cat.label} tone={cat.tone} />
        </div>
      </div>
      {onEdit && (
        <div className="flex shrink-0 gap-1">
          <Button
            variant="ghost"
            size="icon-sm"
            aria-label="Edit reminder"
            onClick={() => onEdit(r)}
          >
            <Pencil />
          </Button>
          <ConfirmDelete
            title="Delete this reminder?"
            description={`"${r.title}" will be permanently removed.`}
            onConfirm={() => del.mutate(r)}
            trigger={
              <Button variant="ghost" size="icon-sm" aria-label="Delete reminder">
                <Trash2 />
              </Button>
            }
          />
        </div>
      )}
    </div>
  );
}
