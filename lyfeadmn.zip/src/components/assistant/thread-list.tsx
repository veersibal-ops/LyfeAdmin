import { Link, useNavigate } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Plus, Trash2, MessageSquare, Pencil } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { ConfirmDelete } from "@/components/app/confirm-dialog";
import { supabase } from "@/integrations/supabase/client";
import { unwrap, logActivity } from "@/hooks/use-data";
import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { cn } from "@/lib/utils";
import { formatDistanceToNow } from "date-fns";

export const useThreads = () =>
  useQuery({
    queryKey: ["threads"],
    queryFn: async () =>
      unwrap(
        await supabase.from("chat_threads").select("*").order("updated_at", { ascending: false }),
      ),
  });

export function useNewThread() {
  const qc = useQueryClient();
  const navigate = useNavigate();
  const m = useMutation({
    mutationFn: async () => {
      const t = unwrap(await supabase.from("chat_threads").insert({}).select().single());
      await logActivity("created", "conversation", t.title, t.id);
      return t;
    },
    onSuccess: (t) => {
      qc.invalidateQueries({ queryKey: ["threads"] });
      navigate({ to: "/assistant/$threadId", params: { threadId: t.id } });
    },
    onError: (e: Error) => toast.error(e.message),
  });
  // Ignore repeat taps while the first conversation is being created.
  return { ...m, mutate: (prompt?: string) => void (!m.isPending && !lock.busy && run(prompt)) };
  function run(prompt?: string) {
    lock.busy = true;
    if (prompt) sessionStorage.setItem("la-assistant-draft", prompt);
    m.mutate(undefined, { onSettled: () => (lock.busy = false) });
  }
}
const lock = { busy: false };

export function ThreadList({
  activeId,
  onNavigate,
}: {
  activeId?: string;
  onNavigate?: () => void;
}) {
  const { data = [] } = useThreads();
  const create = useNewThread();
  const qc = useQueryClient();
  const navigate = useNavigate();
  const [renaming, setRenaming] = useState<{ id: string; title: string } | null>(null);
  const rename = useMutation({
    mutationFn: async ({ id, title }: { id: string; title: string }) => {
      if (!title.trim()) throw new Error("Enter a conversation name.");
      const t = unwrap(
        await supabase
          .from("chat_threads")
          .update({ title: title.trim(), updated_at: new Date().toISOString() })
          .eq("id", id)
          .select()
          .single(),
      );
      await logActivity("updated", "conversation", t.title, t.id);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["threads"] });
      setRenaming(null);
      toast.success("Conversation renamed");
    },
    onError: (e: Error) => toast.error(e.message),
  });
  const del = useMutation({
    mutationFn: async (id: string) => {
      const result = unwrap(await supabase.from("chat_threads").delete().eq("id", id).select());
      await logActivity("deleted", "conversation", result[0]?.title ?? "Conversation", id);
      return result;
    },
    onSuccess: (_r, id) => {
      qc.invalidateQueries({ queryKey: ["threads"] });
      toast.success("Conversation deleted");
      if (id === activeId) navigate({ to: "/assistant" });
    },
    onError: (e: Error) => toast.error(e.message),
  });
  return (
    <div className="flex h-full flex-col">
      <Button
        variant="brand"
        className="mb-3 w-full"
        onClick={() => create.mutate()}
        disabled={create.isPending}
      >
        <Plus /> New conversation
      </Button>
      <h2 className="mb-4 mt-3 text-base font-semibold">Recent conversations</h2>
      <div className="min-h-0 flex-1 space-y-2 overflow-y-auto">
        {data.length === 0 && (
          <p className="px-2 text-sm text-muted-foreground">No conversations yet.</p>
        )}
        {data.map((t) => (
          <div
            key={t.id}
            className={cn(
              "group flex items-center gap-1 rounded-xl pr-1 transition-colors",
              t.id === activeId ? "bg-brand-soft" : "hover:bg-muted",
            )}
          >
            <Link
              to="/assistant/$threadId"
              params={{ threadId: t.id }}
              onClick={onNavigate}
              className="flex min-w-0 flex-1 items-center gap-2 px-3 py-2.5 text-sm"
            >
              <MessageSquare className="size-4 shrink-0 text-muted-foreground" />
              <div className="min-w-0">
                <p className={cn("truncate", t.id === activeId && "font-semibold")}>{t.title}</p>
                <p className="mt-1 text-xs text-muted-foreground">
                  {formatDistanceToNow(new Date(t.updated_at), { addSuffix: true })}
                </p>
              </div>
            </Link>
            <Button
              variant="ghost"
              size="icon-xs"
              aria-label={`Rename ${t.title}`}
              onClick={() => setRenaming({ id: t.id, title: t.title })}
            >
              <Pencil />
            </Button>
            <ConfirmDelete
              title="Delete this conversation?"
              onConfirm={() => del.mutate(t.id)}
              trigger={
                <Button
                  variant="ghost"
                  size="icon-xs"
                  aria-label="Delete conversation"
                  className="opacity-60 group-hover:opacity-100"
                >
                  <Trash2 />
                </Button>
              }
            />
          </div>
        ))}
      </div>
      <Dialog
        open={Boolean(renaming)}
        onOpenChange={(open) => {
          if (!open && !rename.isPending) setRenaming(null);
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Rename conversation</DialogTitle>
            <DialogDescription>
              Choose a name that makes this conversation easy to find.
            </DialogDescription>
          </DialogHeader>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (renaming && !rename.isPending) rename.mutate(renaming);
            }}
            className="space-y-5"
          >
            <Label htmlFor="conversation-name">Conversation name</Label>
            <Input
              id="conversation-name"
              maxLength={100}
              value={renaming?.title ?? ""}
              onChange={(e) =>
                setRenaming((current) => (current ? { ...current, title: e.target.value } : null))
              }
              autoFocus
            />
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                disabled={rename.isPending}
                onClick={() => setRenaming(null)}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={rename.isPending || !renaming?.title.trim()}>
                Save name
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
