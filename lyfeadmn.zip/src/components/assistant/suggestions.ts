import { Bell, CalendarRange, ListChecks, CreditCard } from "lucide-react";

export const ASSISTANT_SUGGESTIONS = [
  {
    icon: Bell,
    title: "A calmer day",
    description: "Prioritise reminders and what's due.",
    prompt: "Help me organise my reminders and prioritise what needs attention today.",
    tone: "bg-brand-soft text-brand-ink",
  },
  {
    icon: CalendarRange,
    title: "Plan my week",
    description: "Make time for what matters.",
    prompt: "Help me plan a realistic week with time for work, life admin and rest.",
    tone: "bg-warning-soft text-warning",
  },
  {
    icon: ListChecks,
    title: "Make a checklist",
    description: "Turn a big task into small steps.",
    prompt: "Help me create a practical checklist for my weekly household tasks.",
    tone: "bg-brand-soft text-brand-ink",
  },
  {
    icon: CreditCard,
    title: "Review subscriptions",
    description: "Bring clarity to recurring costs.",
    prompt: "Help me review my subscriptions and make a checklist for deciding which ones to keep.",
    tone: "bg-warning-soft text-warning",
  },
] as const;
