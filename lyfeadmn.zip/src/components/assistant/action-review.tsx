import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Tool,
  ToolHeader,
  ToolContent,
  ToolInput,
  ToolOutput,
} from "@/components/ai-elements/tool";
import { confirmAssistantAction } from "@/lib/assistant.functions";
import type { AssistantAction } from "@/lib/assistant";
import { supabase } from "@/integrations/supabase/client";
import { unwrapMaybe } from "@/hooks/use-data";

export function ActionReview({
  action,
  messageId,
  saved,
}: {
  action: AssistantAction;
  messageId: string;
  saved: boolean;
}) {
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [failure, setFailure] = useState<string>();
  const qc = useQueryClient();
  const confirm = useServerFn(confirmAssistantAction);
  const { data: created } = useQuery({
    queryKey: ["assistant-action", messageId],
    enabled: saved,
    queryFn: async () => {
      const entity = unwrapMaybe(
        await supabase
          .from(action.kind === "reminder" ? "reminders" : "checklists")
          .select("id")
          .eq("id", messageId)
          .maybeSingle(),
      );
      if (!entity || action.kind === "reminder") return entity;
      const { count, error } = await supabase
        .from("checklist_items")
        .select("id", { count: "exact", head: true })
        .eq("checklist_id", messageId);
      if (error) throw new Error(error.message);
      return count === action.items.length ? entity : null;
    },
  });
  async function save() {
    if (busy) return;
    setBusy(true);
    setFailure(undefined);
    try {
      await confirm({ data: { messageId, confirmed: true } });
      await Promise.all(
        ["assistant-action", "reminders", "checklists", "activity"].map((key) =>
          qc.invalidateQueries({ queryKey: [key] }),
        ),
      );
      toast.success(action.kind === "reminder" ? "Reminder saved" : "Checklist saved");
      setOpen(false);
    } catch (e) {
      const message =
        e instanceof Error ? e.message : "Couldn't save. Your proposal is still here.";
      setFailure(message);
      toast.error(message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <Tool defaultOpen={false}>
        <ToolHeader
          type="dynamic-tool"
          toolName={action.kind}
          title={action.kind === "reminder" ? "Create reminder" : "Create checklist"}
          state={created ? "output-available" : failure ? "output-error" : "approval-requested"}
        />
        <ToolContent>
          <ToolInput input={action} />
          <ToolOutput
            output={
              created
                ? "Saved in your app"
                : "Awaiting your confirmation. Nothing will change until you confirm."
            }
            errorText={failure}
          />
        </ToolContent>
      </Tool>
      {created ? (
        <Button asChild variant="outline" size="sm">
          {action.kind === "reminder" ? (
            <Link to="/reminders">View reminder</Link>
          ) : (
            <Link to="/checklists/$id" params={{ id: messageId }}>
              View checklist
            </Link>
          )}
        </Button>
      ) : (
        <Button variant="outline" size="sm" disabled={!saved} onClick={() => setOpen(true)}>
          Review and confirm
        </Button>
      )}
      <Dialog
        open={open}
        onOpenChange={(value) => {
          if (!busy) setOpen(value);
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Save this {action.kind}?</DialogTitle>
            <DialogDescription>Review the details before adding it to your app.</DialogDescription>
          </DialogHeader>
          <h3 className="break-words font-semibold">{action.title}</h3>
          {action.kind === "reminder" ? (
            <div className="space-y-2">
              <p>
                {new Date(action.due_at).toLocaleString(undefined, {
                  dateStyle: "full",
                  timeStyle: "short",
                })}
              </p>
              <p className="whitespace-pre-wrap break-words text-muted-foreground">
                {action.description}
              </p>
            </div>
          ) : (
            <ul className="list-disc space-y-2 pl-5">
              {action.items.map((item, i) => (
                <li className="break-words" key={i}>
                  {item}
                </li>
              ))}
            </ul>
          )}
          {failure && (
            <p role="alert" className="text-destructive">
              {failure}
            </p>
          )}
          <DialogFooter>
            <Button variant="outline" disabled={busy} onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button disabled={busy} onClick={save}>
              {busy ? "Saving…" : "Confirm and save"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
