import { useEffect, useState, type FormEvent } from "react";
import type { Errs } from "@/lib/form";
import { Loader2, Upload, FileText } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { DOCUMENT_CATEGORIES, type DocumentCategory } from "@/lib/constants";
import { supabase } from "@/integrations/supabase/client";
import { logActivity, unwrap, useAction, type Doc } from "@/hooks/use-data";
import { cn } from "@/lib/utils";

const MAX = 20 * 1024 * 1024;
const ACCEPT = "image/*,application/pdf";

export function DocumentDialog({
  open,
  onOpenChange,
  doc,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  doc?: Doc | null;
}) {
  const [file, setFile] = useState<File | null>(null);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState<DocumentCategory>("other");
  const [errors, setErrors] = useState<Errs>({});
  const [progress, setProgress] = useState<number | null>(null);

  useEffect(() => {
    if (!open) return;
    setFile(null);
    setTitle(doc?.title ?? "");
    setDescription(doc?.description ?? "");
    setCategory((doc?.category as DocumentCategory) ?? "other");
    setErrors({});
    setProgress(null);
  }, [open, doc]);

  const save = useAction(
    async () => {
      const meta = { title: title.trim(), description: description.trim() || null, category };
      if (doc) {
        unwrap(await supabase.from("documents").update(meta).eq("id", doc.id).select().single());
        await logActivity("updated", "document", meta.title, doc.id);
        return;
      }
      const { data: u } = await supabase.auth.getUser();
      if (!u.user || !file) throw new Error("Choose a file to upload");
      const safe = file.name.replace(/[^a-zA-Z0-9._-]/g, "_").slice(-80);
      const path = `${u.user.id}/${crypto.randomUUID()}-${safe}`;
      await uploadWithProgress(path, file, setProgress);
      const ins = await supabase
        .from("documents")
        .insert({
          ...meta,
          file_path: path,
          file_name: file.name,
          mime_type: file.type,
          size_bytes: file.size,
        })
        .select()
        .single();
      if (ins.error) {
        await supabase.storage.from("documents").remove([path]);
        throw new Error(ins.error.message);
      }
      await logActivity("uploaded", "document", meta.title, ins.data.id);
    },
    { keys: [["documents"]], success: doc ? "Document updated" : "Document uploaded securely" },
  );

  function pick(f: File | null) {
    setFile(f);
    if (f && !title) setTitle(f.name.replace(/\.[^.]+$/, "").slice(0, 200));
  }

  function submit(e: FormEvent) {
    e.preventDefault();
    const errs: Errs = {};
    if (!doc) {
      if (!file) errs.file = "Choose an image or PDF";
      else if (!(file.type.startsWith("image/") || file.type === "application/pdf"))
        errs.file = "Only images and PDFs are supported";
      else if (file.size > MAX) errs.file = "Files must be 20 MB or smaller";
    }
    if (!title.trim()) errs.title = "Add a title";
    setErrors(errs);
    if (Object.keys(errs).length) return;
    if (save.isPending) return;
    save.mutate(undefined, {
      onSuccess: () => onOpenChange(false),
      onSettled: () => setProgress(null),
    });
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="rounded-2xl sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{doc ? "Edit document" : "Upload document"}</DialogTitle>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-4" noValidate>
          {!doc && (
            <div>
              <label
                className={cn(
                  "flex cursor-pointer flex-col items-center justify-center gap-2 rounded-2xl border-2 border-dashed p-6 text-center transition-colors hover:border-brand-ink hover:bg-brand-soft/50",
                  file ? "border-brand-ink bg-brand-soft/50" : "border-input",
                )}
                onDragOver={(e) => e.preventDefault()}
                onDrop={(e) => {
                  e.preventDefault();
                  pick(e.dataTransfer.files?.[0] ?? null);
                }}
              >
                {file ? (
                  <FileText className="size-7 text-brand-ink" />
                ) : (
                  <Upload className="size-7 text-muted-foreground" />
                )}
                <span className="text-sm font-semibold break-all">
                  {file ? file.name : "Tap to choose or drop a file"}
                </span>
                <span className="text-xs text-muted-foreground">Images or PDF, up to 20 MB</span>
                <input
                  type="file"
                  accept={ACCEPT}
                  className="sr-only"
                  onChange={(e) => pick(e.target.files?.[0] ?? null)}
                />
              </label>
              {errors.file && <p className="mt-1 text-xs text-destructive">{errors.file}</p>}
            </div>
          )}
          <div className="space-y-1.5">
            <Label htmlFor="d-title">Title</Label>
            <Input
              id="d-title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              maxLength={200}
            />
            {errors.title && <p className="text-xs text-destructive">{errors.title}</p>}
          </div>
          <div className="space-y-1.5">
            <Label>Category</Label>
            <Select value={category} onValueChange={(v) => setCategory(v as DocumentCategory)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {DOCUMENT_CATEGORIES.map((c) => (
                  <SelectItem key={c.value} value={c.value}>
                    {c.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="d-desc">Description (optional)</Label>
            <Textarea
              id="d-desc"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
              maxLength={2000}
            />
          </div>
          {progress !== null && (
            <div aria-live="polite">
              <div className="mb-1 flex justify-between text-xs text-muted-foreground">
                <span>Uploading securely…</span>
                <span>{progress}%</span>
              </div>
              <div className="h-2 overflow-hidden rounded-full bg-muted">
                <div
                  className="h-full rounded-full bg-brand transition-[width]"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>
          )}
          <DialogFooter className="gap-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="brand" disabled={save.isPending}>
              {save.isPending && <Loader2 className="animate-spin" />}{" "}
              {doc ? "Save changes" : "Upload"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

/** Uploads to the private bucket as the signed-in user, reporting progress. */
async function uploadWithProgress(path: string, file: File, onProgress: (p: number) => void) {
  const { data } = await supabase.auth.getSession();
  const token = data.session?.access_token;
  if (!token) throw new Error("Your session expired. Please sign in again.");
  const base = import.meta.env["VITE_SUPABASE_URL"] as string;
  const key = import.meta.env["VITE_SUPABASE_PUBLISHABLE_KEY"] as string;
  const url = `${base}/storage/v1/object/documents/${path.split("/").map(encodeURIComponent).join("/")}`;
  onProgress(0);
  await new Promise<void>((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", url);
    xhr.setRequestHeader("Authorization", `Bearer ${token}`);
    xhr.setRequestHeader("apikey", key);
    xhr.setRequestHeader("x-upsert", "false");
    xhr.setRequestHeader("content-type", file.type || "application/octet-stream");
    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable) onProgress(Math.round((e.loaded / e.total) * 100));
    };
    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) return resolve();
      let msg = `Upload failed (${xhr.status})`;
      try {
        const j = JSON.parse(xhr.responseText) as { message?: string; error?: string };
        msg = j.message || j.error || msg;
      } catch {
        /* keep default */
      }
      if (xhr.status === 413) msg = "That file is too large (20 MB max).";
      reject(new Error(msg));
    };
    xhr.onerror = () => reject(new Error("Network error — check your connection and try again."));
    xhr.send(file);
  });
}
