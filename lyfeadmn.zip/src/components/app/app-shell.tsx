import { useEffect, useState, type ReactNode } from "react";
import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import {
  LayoutDashboard,
  Bell,
  FolderLock,
  CreditCard,
  ListChecks,
  MessageCircle,
  Settings,
  PanelLeftClose,
  PanelLeftOpen,
  LogOut,
  Menu,
  Search,
  ExternalLink,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Logo } from "./logo";
import { ProfileMenu } from "./profile-menu";
import { WEBSITE_URL, WEBSITE_LINKS } from "@/lib/website";
import { cn } from "@/lib/utils";
import { useProfile } from "@/hooks/use-data";
import { useReminderNotifications } from "@/hooks/use-notifications";

export const NAV = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { to: "/reminders", label: "Reminders", icon: Bell },
  { to: "/documents", label: "Documents", icon: FolderLock },
  { to: "/subscriptions", label: "Subscriptions", icon: CreditCard },
  { to: "/discovery", label: "Subscription Discovery", icon: Search },
  { to: "/checklists", label: "Checklists", icon: ListChecks },
  { to: "/assistant", label: "AI Assistant", icon: MessageCircle },
  { to: "/settings", label: "Settings", icon: Settings },
] as const;
const MOBILE_PRIMARY = ["/dashboard", "/reminders", "/checklists", "/assistant"];

export function useSignOut() {
  const qc = useQueryClient();
  const navigate = useNavigate();
  return async () => {
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  };
}

export function AppShell({ children }: { children: ReactNode }) {
  const [collapsed, setCollapsed] = useState(false);
  const [moreOpen, setMoreOpen] = useState(false);
  // Use the page actually on screen, not the one still loading, so the highlighted
  // nav item always matches the visible content.
  const pathname = useRouterState({
    select: (s) => s.resolvedLocation?.pathname ?? s.location.pathname,
  });
  const loading = useRouterState({ select: (s) => s.status === "pending" });
  const signOut = useSignOut();
  const { data: profile } = useProfile();
  useReminderNotifications(profile ?? null);

  useEffect(() => {
    setCollapsed(localStorage.getItem("la-sidebar") === "1");
  }, []);
  useEffect(() => {
    const root = document.documentElement;
    const t = profile?.theme ?? "light";
    const dark =
      t === "dark" || (t === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches);
    root.classList.toggle("dark", dark);
  }, [profile?.theme]);

  const toggle = () => {
    setCollapsed((c) => {
      localStorage.setItem("la-sidebar", c ? "0" : "1");
      return !c;
    });
  };
  const isActive = (to: string) => pathname === to || pathname.startsWith(to + "/");

  return (
    <div className="flex min-h-screen">
      {/* Desktop sidebar */}
      <aside
        className={cn(
          "sticky top-0 hidden h-screen shrink-0 flex-col border-r border-sidebar-border bg-sidebar text-sidebar-foreground transition-[width] duration-300 md:flex",
          collapsed ? "w-[88px]" : "w-[280px]",
        )}
      >
        <div
          className={cn(
            "flex min-h-28 items-center px-5 py-5",
            collapsed ? "justify-center" : "justify-between",
          )}
        >
          <a
            href={WEBSITE_URL}
            target="_blank"
            rel="noreferrer"
            title="Visit the LYFEADMIN website"
            className="rounded-lg"
          >
            <Logo showText={!collapsed} textClass="text-base" className="[&_img]:size-10" />
          </a>
          {!collapsed && (
            <Button
              variant="ghost"
              size="icon-sm"
              onClick={toggle}
              aria-label="Collapse sidebar"
              className="rounded-lg p-1.5 hover:bg-sidebar-accent"
            >
              <PanelLeftClose className="size-4" />
            </Button>
          )}
        </div>
        {collapsed && (
          <Button
            variant="ghost"
            size="icon-sm"
            onClick={toggle}
            aria-label="Expand sidebar"
            className="mx-auto mb-2 rounded-lg p-1.5 hover:bg-sidebar-accent"
          >
            <PanelLeftOpen className="size-4" />
          </Button>
        )}
        <nav
          aria-label="Main navigation"
          className="min-h-0 flex-1 space-y-2 overflow-y-auto px-4 py-4"
        >
          {NAV.map((n) => (
            <Link
              key={n.to}
              to={n.to}
              title={collapsed ? n.label : undefined}
              className={cn(
                "group flex min-h-12 items-center gap-3 rounded-xl px-3 py-3 text-[15px] font-medium transition-all duration-200",
                collapsed && "justify-center px-0",
                isActive(n.to)
                  ? "bg-sidebar-primary text-sidebar-primary-foreground shadow-card"
                  : "hover:bg-sidebar-accent hover:text-sidebar-foreground",
              )}
            >
              <n.icon className="size-5 shrink-0" />
              {!collapsed && <span className="truncate">{n.label}</span>}
            </Link>
          ))}
        </nav>
        <div className="border-t border-sidebar-border p-3">
          <ProfileMenu
            collapsed={collapsed}
            name={profile?.full_name || "Your account"}
            onSignOut={signOut}
          />
          {/* Marketing website links — kept separate from the app navigation above */}
          <div className={cn("mb-1", collapsed ? "space-y-1" : "space-y-0.5")}>
            {collapsed ? (
              <a
                href={WEBSITE_URL}
                target="_blank"
                rel="noreferrer"
                title="LYFEADMIN website"
                aria-label="LYFEADMIN website"
                className="flex items-center justify-center rounded-xl px-0 py-2.5 text-sm font-medium hover:bg-sidebar-accent hover:text-sidebar-foreground"
              >
                <ExternalLink className="size-[18px]" />
              </a>
            ) : (
              WEBSITE_LINKS.map((l) => (
                <a
                  key={l.href}
                  href={l.href}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-foreground"
                >
                  <ExternalLink className="size-3.5 shrink-0" /> {l.label}
                </a>
              ))
            )}
          </div>
        </div>
      </aside>

      <div className="relative flex min-w-0 flex-1 flex-col">
        {loading && (
          <div
            className="fixed inset-x-0 top-0 z-50 h-0.5 animate-pulse bg-brand"
            role="progressbar"
            aria-label="Loading page"
          />
        )}
        {/* Mobile top bar */}
        <header className="pt-safe sticky top-0 z-30 grid min-h-16 grid-cols-[minmax(0,1fr)_auto] items-center gap-3 border-b bg-background/95 px-4 backdrop-blur md:hidden">
          <a
            href={WEBSITE_URL}
            target="_blank"
            rel="noreferrer"
            title="Visit the LYFEADMIN website"
            className="rounded-lg"
          >
            <Logo />
          </a>
          <div className="flex items-center gap-1">
          <ProfileMenu compact name={profile?.full_name || "Your account"} onSignOut={signOut} />
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setMoreOpen(true)}
            aria-label="Open menu"
            className="rounded-lg p-2 hover:bg-muted"
          >
            <Menu className="size-5" />
          </Button>
          </div>
        </header>

        <main
          key={pathname}
          className="app-content mx-auto w-full max-w-[1760px] flex-1 px-4 pb-28 pt-6 animate-rise sm:px-7 md:pb-12 lg:px-10 lg:pt-10 xl:px-12"
        >
          {children}
        </main>
      </div>

      {/* Mobile bottom nav */}
      <nav
        className="pb-safe fixed inset-x-0 bottom-0 z-40 border-t bg-card/95 backdrop-blur md:hidden"
        aria-label="Primary"
      >
        <div className="mx-auto grid max-w-lg grid-cols-5 px-2 pt-1.5">
          {NAV.filter((n) => MOBILE_PRIMARY.includes(n.to)).map((n) => (
            <Link
              key={n.to}
              to={n.to}
              className={cn(
                "flex min-h-12 flex-col items-center justify-center gap-0.5 rounded-xl text-[11px] font-semibold transition-colors",
                isActive(n.to) ? "text-foreground" : "text-muted-foreground",
              )}
            >
              <span
                className={cn(
                  "rounded-full px-3 py-1 transition-colors",
                  isActive(n.to) && "bg-primary text-primary-foreground",
                )}
              >
                <n.icon className="size-5" />
              </span>
              {n.label === "AI Assistant" ? "Assistant" : n.label}
            </Link>
          ))}
          <Button
            variant="ghost"
            onClick={() => setMoreOpen(true)}
            className="flex h-auto min-h-12 flex-col items-center justify-center gap-0.5 text-[11px] font-semibold text-muted-foreground"
          >
            <span className="px-3 py-1">
              <Menu className="size-5" />
            </span>
            More
          </Button>
        </div>
      </nav>

      <Sheet open={moreOpen} onOpenChange={setMoreOpen}>
        <SheetContent side="right" className="w-[85vw] max-w-xs">
          <SheetHeader>
            <SheetTitle>
              <Logo />
            </SheetTitle>
          </SheetHeader>
          <nav className="mt-4 space-y-1 px-2">
            {NAV.map((n) => (
              <Link
                key={n.to}
                to={n.to}
                onClick={() => setMoreOpen(false)}
                className={cn(
                  "flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-medium",
                  isActive(n.to)
                    ? "bg-primary text-primary-foreground"
                    : "hover:bg-secondary hover:text-secondary-foreground",
                )}
              >
                <n.icon className="size-5" /> {n.label}
              </Link>
            ))}
            <div className="mt-3 border-t pt-3">
              <p className="px-3 pb-1 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                LYFEADMIN website
              </p>
              {WEBSITE_LINKS.map((l) => (
                <a
                  key={l.href}
                  href={l.href}
                  target="_blank"
                  rel="noreferrer"
                  onClick={() => setMoreOpen(false)}
                  className="flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-medium hover:bg-secondary hover:text-secondary-foreground"
                >
                  <ExternalLink className="size-4" /> {l.label}
                </a>
              ))}
            </div>
            <Button
              variant="ghost"
              onClick={signOut}
              className="flex h-auto w-full justify-start items-center gap-3 rounded-lg px-3 py-3 text-sm font-medium text-destructive hover:bg-danger-soft"
            >
              <LogOut className="size-5" /> Log out
            </Button>
          </nav>
        </SheetContent>
      </Sheet>
    </div>
  );
}
