import { Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export function NotificationInbox() {
  const qc = useQueryClient();
  const { data, error } = useQuery({ queryKey: ["notifications"], queryFn: async () => {
    const refreshed = await supabase.rpc("refresh_my_notifications");
    if (refreshed.error) throw refreshed.error;
    const res = await supabase.from("notifications").select("*").order("created_at", { ascending: false }).limit(30);
    if (res.error) throw res.error;
    return res.data;
  }, refetchInterval: 60_000 });
  return <div className="space-y-3">{error && <p className="text-sm text-destructive">Couldn’t load alerts.</p>}{data?.length === 0 && <p className="text-sm text-muted-foreground">No upcoming alerts.</p>}{data?.map(n => <div key={n.id} className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 border-b pb-3 animate-rise"><div className="min-w-0"><Link to={n.kind === "reminder" ? "/reminders" : "/subscriptions"} className="text-sm font-semibold text-brand-ink">{n.title}</Link><p className="break-words text-sm">{n.body}</p><p className="text-xs text-muted-foreground">{new Date(n.created_at).toLocaleString()}</p></div><Button variant="ghost" size="sm" disabled={!!n.read_at} onClick={async () => { const { error } = await supabase.from("notifications").update({ read_at: new Date().toISOString() }).eq("id", n.id); if (error) toast.error(error.message); else qc.invalidateQueries({ queryKey: ["notifications"] }); }}>{n.read_at ? "Read" : "Mark read"}</Button></div>)}</div>;
}