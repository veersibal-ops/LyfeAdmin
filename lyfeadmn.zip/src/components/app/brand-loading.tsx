import { Logo } from "./logo";

export function BrandLoading() {
  return (
    <div role="status" aria-label="Loading LYFEADMIN" className="flex min-h-40 flex-col items-center justify-center gap-4 py-8">
      <Logo artwork="full" showText={false} />
      <span className="h-1 w-20 animate-pulse rounded-full bg-primary motion-reduce:animate-none" />
      <span className="sr-only">Loading LYFEADMIN…</span>
    </div>
  );
}