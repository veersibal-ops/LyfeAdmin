import icon from "@/assets/lyfeadmin-l-icon.png.asset.json";
import { cn } from "@/lib/utils";

/** Official pastel L icon, with the LYFEADMIN wordmark set separately as text. */
export function Logo({
  className,
  showText = true,
  textClass,
  artwork = "calendar",
}: {
  className?: string;
  showText?: boolean;
  textClass?: string;
  artwork?: "calendar" | "full";
}) {
  const full = artwork === "full";
  return (
    <span className={cn("flex min-w-0 items-center", full ? "flex-col gap-3" : "gap-2.5", className)}>
      <img
        src={icon.url}
        alt={showText && !full ? "" : "LYFEADMIN"}
        width={full ? 72 : 36}
        height={full ? 72 : 36}
        className={cn("shrink-0 object-contain drop-shadow-sm", full ? "size-[72px]" : "size-9")}
      />
      {(showText || full) && (
        <span
          className={cn(
            "truncate font-display font-bold tracking-[0.14em] text-foreground",
            full ? "text-xl" : "text-sm",
            textClass,
          )}
        >
          LYFEADMIN
        </span>
      )}
    </span>
  );
}
