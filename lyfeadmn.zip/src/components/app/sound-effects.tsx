import { useEffect, useState } from "react";
import { toast } from "sonner";
import { playSound, readSoundPrefs, writeSoundPrefs, DEFAULT_SOUND_PREFS, type SoundPrefs } from "@/lib/sounds";

export function useSoundPrefs() {
  const [prefs, setPrefs] = useState<SoundPrefs>(DEFAULT_SOUND_PREFS);
  useEffect(() => {
    const read = () => setPrefs(readSoundPrefs());
    read();
    window.addEventListener("la-sounds-change", read);
    return () => window.removeEventListener("la-sounds-change", read);
  }, []);
  return { prefs, update: (p: Partial<SoundPrefs>) => writeSoundPrefs({ ...prefs, ...p }) };
}

let patched = false;
/** One global listener for clicks/navigation/menus, plus success toasts. */
export function SoundEffects() {
  useEffect(() => {
    if (!patched) {
      patched = true;
      const original = toast.success;
      toast.success = ((...args: Parameters<typeof original>) => {
        playSound("success");
        return original(...args);
      }) as typeof original;
    }
    const onClick = (e: MouseEvent) => {
      const t = e.target instanceof Element ? e.target : null;
      const el = t?.closest<HTMLElement>("a[href], button:not(:disabled), [role='menuitem'], [role='switch']");
      if (!el || el.closest("[data-sound='none']")) return;
      if (el.matches("button[type='submit']")) return; // forms play send/success themselves
      if (el.getAttribute("aria-haspopup") || el.hasAttribute("aria-expanded"))
        return playSound(el.getAttribute("aria-expanded") === "true" ? "open" : "close");
      if (el.closest("nav")) return playSound("nav");
      playSound("click");
    };
    document.addEventListener("click", onClick, { capture: false });
    return () => document.removeEventListener("click", onClick);
  }, []);
  return null;
}
