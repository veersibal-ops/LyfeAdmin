import { useEffect, useState } from "react";
import { Download } from "lucide-react";
import { Button } from "@/components/ui/button";

interface InstallEvent extends Event { prompt: () => Promise<void>; userChoice: Promise<{ outcome: string }> }
export function InstallControl() {
  const [event, setEvent] = useState<InstallEvent | null>(null);
  const [installed, setInstalled] = useState(false);
  useEffect(() => {
    setInstalled(window.matchMedia("(display-mode: standalone)").matches);
    const before = (e: Event) => { e.preventDefault(); setEvent(e as InstallEvent); };
    const done = () => { setInstalled(true); setEvent(null); };
    window.addEventListener("beforeinstallprompt", before);
    window.addEventListener("appinstalled", done);
    return () => { window.removeEventListener("beforeinstallprompt", before); window.removeEventListener("appinstalled", done); };
  }, []);
  return <div className="space-y-2"><p className="text-sm">{installed ? "LYFEADMIN is installed on this device." : "On iPhone, open LYFEADMIN in Safari, tap Share, then Add to Home Screen. Other supported browsers offer Install app."}</p>{event && <Button variant="brand" onClick={async () => { await event.prompt(); await event.userChoice; setEvent(null); }}><Download /> Install LYFEADMIN</Button>}<p className="text-xs text-muted-foreground">An internet connection is required for your account, files and saved information. Offline mode shows a connection page only.</p></div>;
}