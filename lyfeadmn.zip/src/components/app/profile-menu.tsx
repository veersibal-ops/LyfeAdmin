import { Link } from "@tanstack/react-router";
import { ChevronsUpDown, LogOut, Settings, SlidersHorizontal, User } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";

function initials(name: string) {
  return (
    name
      .split(/\s+/)
      .filter(Boolean)
      .slice(0, 2)
      .map((p) => p[0]?.toUpperCase())
      .join("") || "Y"
  );
}

/** The single profile menu, used in the desktop sidebar and the mobile header. */
export function ProfileMenu({
  name,
  onSignOut,
  collapsed = false,
  compact = false,
}: {
  name: string;
  onSignOut: () => void;
  collapsed?: boolean;
  compact?: boolean;
}) {
  const avatar = (
    <span className="grid size-9 shrink-0 place-items-center rounded-full bg-primary text-sm font-semibold text-primary-foreground">
      {initials(name)}
    </span>
  );
  return (
    <DropdownMenu>
      <DropdownMenuTrigger
        aria-label={`Account menu for ${name}`}
        className={cn(
          "flex min-w-0 items-center gap-3 rounded-xl text-left outline-none transition-colors hover:bg-sidebar-accent focus-visible:ring-2 focus-visible:ring-ring",
          compact ? "p-1" : collapsed ? "mx-auto mb-3 justify-center p-1.5" : "mb-3 w-full border border-sidebar-border bg-card p-2.5",
        )}
      >
        {avatar}
        {!compact && !collapsed && (
          <>
            <span className="min-w-0 flex-1 truncate text-sm font-semibold">{name}</span>
            <ChevronsUpDown className="size-4 shrink-0 text-muted-foreground" />
          </>
        )}
      </DropdownMenuTrigger>
      <DropdownMenuContent
        side={compact ? "bottom" : collapsed ? "right" : "top"}
        align={compact ? "end" : "start"}
        className="w-56 rounded-xl p-1.5"
      >
        <DropdownMenuItem asChild className="gap-3 rounded-lg py-2.5">
          <Link to="/settings" hash="account">
            <User className="size-4" /> Account
          </Link>
        </DropdownMenuItem>
        <DropdownMenuItem asChild className="gap-3 rounded-lg py-2.5">
          <Link to="/settings" hash="preferences">
            <SlidersHorizontal className="size-4" /> Preferences
          </Link>
        </DropdownMenuItem>
        <DropdownMenuItem asChild className="gap-3 rounded-lg py-2.5">
          <Link to="/settings">
            <Settings className="size-4" /> Settings
          </Link>
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem onSelect={onSignOut} className="gap-3 rounded-lg py-2.5 text-destructive focus:text-destructive">
          <LogOut className="size-4" /> Log out
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
