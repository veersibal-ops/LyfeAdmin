import { useEffect, useState } from "react";

export function useDecorativeEffects() {
  const [enabled, setEnabled] = useState(true);
  useEffect(() => {
    const read = () => setEnabled(localStorage.getItem("la-decorative-effects") !== "off");
    read();
    window.addEventListener("la-effects-change", read);
    return () => window.removeEventListener("la-effects-change", read);
  }, []);
  return {
    enabled,
    toggle: (value: boolean) => {
      localStorage.setItem("la-decorative-effects", value ? "on" : "off");
      window.dispatchEvent(new Event("la-effects-change"));
    },
  };
}

/** A bounded, mouse-only animation; no canvas, timers or pointer interception. */
export function CursorEffects() {
  const { enabled } = useDecorativeEffects();
  useEffect(() => {
    const media = matchMedia(
      "(hover: hover) and (pointer: fine) and (prefers-reduced-motion: no-preference)",
    );
    if (!enabled) return;
    let cleanup = () => {};
    const activate = () => {
      cleanup();
      if (!media.matches) return;
      const trail = document.createElement("div");
      trail.className = "cursor-trail";
      trail.setAttribute("aria-hidden", "true");
      const particles = Array.from({ length: 6 }, () => {
        const dot = document.createElement("i");
        trail.append(dot);
        return { el: dot, x: 0, y: 0 };
      });
      // Thin gradient outline that sits exactly on the pointer (no easing = no lag).
      const ring = document.createElement("div");
      ring.className = "cursor-ring";
      ring.setAttribute("aria-hidden", "true");
      document.body.append(trail, ring);
      let x = 0,
        y = 0,
        tx = 0,
        ty = 0,
        frame = 0,
        idle = 0;
      let magnetic: HTMLElement | null = null;
      const reset = () => {
        magnetic?.style.removeProperty("translate");
        magnetic = null;
      };
      const tick = () => {
        x += (tx - x) * 0.15;
        y += (ty - y) * 0.15;
        particles.forEach((p, i) => {
          const target = particles[i - 1] ?? { x, y };
          p.x += (target.x - p.x) * 0.22;
          p.y += (target.y - p.y) * 0.22;
          p.el.style.opacity = `${Math.max(0, (1 - idle / 70) * (0.5 - i * 0.07))}`;
          p.el.style.transform = `translate3d(${p.x}px,${p.y}px,0)`;
        });
        trail.style.transform = `translate3d(${x}px,${y}px,0)`;
        // Particles are positioned relative to the moving glow.
        particles.forEach(
          (p) => (p.el.style.transform = `translate3d(${p.x - x}px,${p.y - y}px,0)`),
        );
        if (idle < 90) {
          idle++;
          frame = requestAnimationFrame(tick);
        } else {
          frame = 0;
        }
      };
      const move = (e: PointerEvent) => {
        if (e.pointerType !== "mouse") return;
        tx = e.clientX;
        ty = e.clientY;
        idle = 0;
        ring.style.transform = `translate3d(${tx}px,${ty}px,0)`;
        ring.classList.add("visible");
        if (!trail.classList.contains("visible")) {
          x = tx;
          y = ty;
          particles.forEach((p) => {
            p.x = x;
            p.y = y;
          });
        }
        trail.classList.add("visible");
        const target = e.target instanceof Element ? e.target : null;
        const interactive = Boolean(
          target?.closest(
            "button:not(:disabled), a, [role='button'], [role='menuitem'], [data-magnetic], .card-hover, .card-surface",
          ),
        );
        trail.classList.toggle("interactive", interactive);
        ring.classList.toggle("interactive", interactive);
        const button =
          target?.closest<HTMLElement>("[data-magnetic='true']:not(:disabled)") ?? null;
        if (magnetic !== button) reset();
        magnetic = button;
        if (button) {
          const r = button.getBoundingClientRect();
          button.style.translate = `${Math.max(-3, Math.min(3, (tx - r.x - r.width / 2) * 0.05))}px ${Math.max(-3, Math.min(3, (ty - r.y - r.height / 2) * 0.08))}px`;
        }
        if (!frame) frame = requestAnimationFrame(tick);
      };
      const leave = () => {
        trail.classList.remove("visible");
        ring.classList.remove("visible");
        cancelAnimationFrame(frame);
        frame = 0;
        reset();
      };
      window.addEventListener("pointermove", move, { passive: true });
      document.addEventListener("pointerleave", leave);
      window.addEventListener("blur", leave);
      cleanup = () => {
        cancelAnimationFrame(frame);
        reset();
        trail.remove();
        ring.remove();
        window.removeEventListener("pointermove", move);
        document.removeEventListener("pointerleave", leave);
        window.removeEventListener("blur", leave);
      };
    };
    activate();
    media.addEventListener("change", activate);
    return () => {
      cleanup();
      media.removeEventListener("change", activate);
    };
  }, [enabled]);
  return null;
}
