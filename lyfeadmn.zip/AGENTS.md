<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.

## What Lovable manages

Rules outside this block are the project's own. Change the pieces below in
Lovable, not by hand. With the [Lovable MCP](https://mcp.lovable.dev)
connected, `send_message` asks Lovable to do it; otherwise ask the user to
use the editor.

- **Database.** Do not add or edit `supabase/migrations/` or `drizzle/`.
  Ask Lovable to change the schema.
- **Generated files.** Do not edit a file whose header says it is automatically
  generated.
- **AI gateway.** Keep model calls on Lovable's gateway, and keep
  `LOVABLE_API_KEY` out of browser code.
- **Connectors.** Lovable provides native connectors. `list_connectors` shows
  which are enabled; `add_connector` only returns the dashboard link. When a
  connector is enabled, calls go through the connector gateway and need
  `LOVABLE_API_KEY`. When Lovable does not provide one, users can bring their
  own key and store it in Secrets.
- **Secrets.** Lovable manages them. Do not put secret values in the repo.
<!-- LOVABLE:END -->

## Project rules
- Branding uses one shared Logo component (official icon CDN pointer + separate text wordmark); favicon and installation icons are resized from the same icon. Why: preserve the supplied artwork consistently across screens and devices.
- Visual themes use shared OKLCH tokens and semantic button variants; legacy hero colour aliases must remain contrast pairs, not literal hues. Why: recolouring all screens must not alter behaviour or reduce readability.
- Signed-in pages live under `src/routes/_authenticated/_shell/` (app chrome + onboarding gate); onboarding sits outside `_shell`. Why: one gate for auth, one for onboarding.
- Client data access goes through the browser Supabase client with RLS (`src/hooks/use-data.ts`); every mutation writes an `activity_logs` row via `logActivity`. Why: dashboard activity and counts stay in sync.
- Documents live in the private `documents` bucket under `<user_id>/…` and are only opened via short-lived signed URLs. Why: personal files must never be publicly reachable.
- AI chat streams from `src/routes/api/chat.ts`, which verifies the bearer token, saves both messages, and only reads user data when the client sends `shareContext`. Why: keys stay server-side and data sharing is opt-in.
- Assistant proposals are versioned inside existing message content and executed only by an authenticated confirmation function; use the saved message ID for idempotent entity IDs and explicitly selected documents for file-content sharing. Why: preserve the schema, prevent duplicate creations and require user consent.
- Subscription cost maths lives in `src/lib/costs.ts` with tests in `src/test/costs.test.ts`.
- Account deletion runs in `src/lib/account.functions.ts` (auth-checked server function using the admin client) and must delete every user-owned table and storage folder. Why: app tables have no FK cascade to auth users.
- Nav highlighting reads the router's resolved location, and the shell's onboarding gate reads the cached `profileQuery`. Why: highlighting the pending location showed the old page under the new menu item.
- Dashboard figures come from `src/lib/dashboard-stats.ts` (tested in `src/test/dashboard-stats.test.ts`). Why: one tested source for due-today/overdue/renewal rules.
- App-shell offline support uses generated Workbox with one preview-safe wrapper and a public fallback only; never cache personal HTML or API data. Why: prevent stale previews and private-data caching.
- Notification inbox generation is deduplicated in PostgreSQL and scheduled with one consolidated job; browser delivery requires opt-in and an open app until push is configured. Why: separate saved alerts from actual device delivery.
- Receipt extraction runs in an authenticated server function after explicit consent; suggestion approval is a locked, idempotent database transaction. Why: credentials stay private and suggestions cannot silently create duplicate subscriptions.
- Decorative mouse effects use one bounded DOM animation with pointer/media-query guards and a browser-local opt-out; suggested assistant prompts are drafts, not automatic sends. Why: keep effects lightweight and preserve explicit user control.

- Interface sounds are synthesized in `src/lib/sounds.ts`, gated on a prior user gesture and a browser-local preference, and triggered from one global listener plus explicit send/notify/success calls. Why: no audio files, no autoplay, no duplicate triggers.
- The account menu is the single `ProfileMenu` component shared by sidebar and mobile header. Why: avoid duplicate profile menus.
