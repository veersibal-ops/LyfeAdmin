// @lovable.dev/vite-tanstack-config already includes the following — do NOT add them manually
// or the app will break with duplicate plugins:
//   - TanStack devtools (dev-only, first), tanstackStart, viteReact, tailwindcss, tsConfigPaths,
//     nitro (build-only using cloudflare as a default target), VITE_* env injection, @ path alias,
//     React/TanStack dedupe, error logger plugins, and sandbox detection (port/host/strictPort).
// Never set ssr.external or resolve.external: the Worker has no runtime module resolution, so
// the build fails. Never add compression (compressPublicAssets, vite-plugin-compression):
// hosting already compresses at the edge.
// You can pass additional config via defineConfig({ vite: { ... }, etc... }) if needed.
import { defineConfig } from "@lovable.dev/vite-tanstack-config";
import { VitePWA } from "vite-plugin-pwa";

export default defineConfig({
  vite: {
    plugins: [VitePWA({
      strategies: "generateSW", filename: "sw.js", registerType: "autoUpdate",
      injectRegister: null, manifest: false, devOptions: { enabled: false },
      includeAssets: ["offline.html", "lifeadmin-192.png", "lifeadmin-512.png"],
      workbox: {
        importScripts: ["/notification-events.js"],
        globPatterns: [], cleanupOutdatedCaches: true,
        navigateFallback: null,
        navigateFallbackDenylist: [/^\/api\//, /^\/~oauth/, /^\/auth/, /^\/reset-password/, /^\/\.lovable\//],
        runtimeCaching: [
          { urlPattern: ({ request, url }) => request.mode === "navigate" && !/^\/(api\/|~oauth|auth|reset-password|\.lovable\/)/.test(url.pathname), handler: "NetworkFirst", options: { cacheName: "lifeadmin-navigation", networkTimeoutSeconds: 4, cacheableResponse: { statuses: [] }, precacheFallback: { fallbackURL: "/offline.html" } } },
          { urlPattern: ({ url, sameOrigin }) => sameOrigin && /\/assets\/.*-[a-zA-Z0-9_-]{8,}\.(js|css|png|jpg|woff2)$/.test(url.pathname), handler: "CacheFirst", options: { cacheName: "lifeadmin-assets", expiration: { maxEntries: 100, maxAgeSeconds: 2592000 } } },
        ],
      },
    })],
  },
  tanstackStart: {
    // Redirect TanStack Start's bundled server entry to src/server.ts (our SSR error wrapper).
    // nitro/vite builds from this
    server: { entry: "server" },
  },
});
