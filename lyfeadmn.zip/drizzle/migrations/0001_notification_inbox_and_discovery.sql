ALTER TABLE public.profiles ADD COLUMN notify_reminders boolean NOT NULL DEFAULT true, ADD COLUMN notify_renewals boolean NOT NULL DEFAULT true, ADD COLUMN renewal_lead_days integer NOT NULL DEFAULT 3;
CREATE TABLE public.notifications (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), user_id uuid NOT NULL, kind text NOT NULL CHECK (kind IN ('reminder','renewal')), event_key text NOT NULL, title text NOT NULL, body text NOT NULL, path text NOT NULL, read_at timestamptz, created_at timestamptz NOT NULL DEFAULT now(), UNIQUE(user_id,event_key));
GRANT SELECT, UPDATE, DELETE ON public.notifications TO authenticated; GRANT ALL ON public.notifications TO service_role;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
CREATE POLICY notifications_owner ON public.notifications FOR ALL TO authenticated USING(user_id=auth.uid()) WITH CHECK(user_id=auth.uid());
CREATE TABLE public.subscription_suggestions (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), user_id uuid NOT NULL DEFAULT auth.uid(), name text, amount numeric, currency text, frequency text, next_renewal date, source_name text NOT NULL, status text NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected')), subscription_id uuid REFERENCES public.subscriptions(id) ON DELETE SET NULL, created_at timestamptz NOT NULL DEFAULT now());
GRANT SELECT, INSERT, UPDATE, DELETE ON public.subscription_suggestions TO authenticated; GRANT ALL ON public.subscription_suggestions TO service_role;
ALTER TABLE public.subscription_suggestions ENABLE ROW LEVEL SECURITY;
CREATE POLICY suggestions_owner ON public.subscription_suggestions FOR ALL TO authenticated USING(user_id=auth.uid()) WITH CHECK(user_id=auth.uid());
CREATE OR REPLACE FUNCTION public.generate_due_notifications() RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
BEGIN
INSERT INTO public.notifications(user_id,kind,event_key,title,body,path)
SELECT r.user_id,'reminder','reminder:'||r.id||':'||r.due_at,'Upcoming reminder',r.title,'/reminders' FROM public.reminders r JOIN public.profiles p ON p.id=r.user_id WHERE p.notify_reminders AND NOT r.completed AND r.due_at >= now() AND r.due_at <= now()+make_interval(mins=>p.notify_lead_minutes) ON CONFLICT(user_id,event_key) DO NOTHING;
INSERT INTO public.notifications(user_id,kind,event_key,title,body,path)
SELECT s.user_id,'renewal','renewal:'||s.id||':'||s.next_renewal,'Subscription renewal',s.name||' renews on '||s.next_renewal,'/subscriptions' FROM public.subscriptions s JOIN public.profiles p ON p.id=s.user_id WHERE p.notify_renewals AND s.active AND s.next_renewal >= (now() AT TIME ZONE COALESCE((SELECT name FROM pg_timezone_names WHERE name=p.timezone LIMIT 1),'UTC'))::date AND s.next_renewal <= (now() AT TIME ZONE COALESCE((SELECT name FROM pg_timezone_names WHERE name=p.timezone LIMIT 1),'UTC'))::date+p.renewal_lead_days ON CONFLICT(user_id,event_key) DO NOTHING;
END; $$;
REVOKE ALL ON FUNCTION public.generate_due_notifications() FROM PUBLIC, anon, authenticated; GRANT EXECUTE ON FUNCTION public.generate_due_notifications() TO service_role;
CREATE OR REPLACE FUNCTION public.refresh_my_notifications() RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
BEGIN
IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Unauthorized'; END IF;
INSERT INTO public.notifications(user_id,kind,event_key,title,body,path)
SELECT r.user_id,'reminder','reminder:'||r.id||':'||r.due_at,'Upcoming reminder',r.title,'/reminders' FROM public.reminders r JOIN public.profiles p ON p.id=r.user_id WHERE r.user_id=auth.uid() AND p.notify_reminders AND NOT r.completed AND r.due_at >= now() AND r.due_at <= now()+make_interval(mins=>p.notify_lead_minutes) ON CONFLICT(user_id,event_key) DO NOTHING;
INSERT INTO public.notifications(user_id,kind,event_key,title,body,path)
SELECT s.user_id,'renewal','renewal:'||s.id||':'||s.next_renewal,'Subscription renewal',s.name||' renews on '||s.next_renewal,'/subscriptions' FROM public.subscriptions s JOIN public.profiles p ON p.id=s.user_id WHERE s.user_id=auth.uid() AND p.notify_renewals AND s.active AND s.next_renewal >= (now() AT TIME ZONE COALESCE((SELECT name FROM pg_timezone_names WHERE name=p.timezone LIMIT 1),'UTC'))::date AND s.next_renewal <= (now() AT TIME ZONE COALESCE((SELECT name FROM pg_timezone_names WHERE name=p.timezone LIMIT 1),'UTC'))::date+p.renewal_lead_days ON CONFLICT(user_id,event_key) DO NOTHING;
END; $$;
REVOKE ALL ON FUNCTION public.refresh_my_notifications() FROM PUBLIC,anon; GRANT EXECUTE ON FUNCTION public.refresh_my_notifications() TO authenticated;
CREATE OR REPLACE FUNCTION public.approve_subscription_suggestion(suggestion_id uuid, approved_name text, approved_amount numeric, approved_currency text, approved_frequency text, approved_renewal date) RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE suggestion public.subscription_suggestions; new_id uuid;
BEGIN
SELECT * INTO suggestion FROM public.subscription_suggestions WHERE id=suggestion_id AND user_id=auth.uid() FOR UPDATE;
IF NOT FOUND THEN RAISE EXCEPTION 'Suggestion not found'; END IF;
IF suggestion.status='approved' THEN RETURN suggestion.subscription_id; END IF;
IF suggestion.status<>'pending' THEN RAISE EXCEPTION 'Suggestion was rejected'; END IF;
IF length(trim(approved_name))<1 OR length(approved_name)>120 OR approved_amount<0 OR approved_amount>1000000 OR approved_amount IS NULL OR approved_frequency NOT IN ('weekly','monthly','quarterly','yearly') OR approved_frequency IS NULL OR approved_currency !~ '^[A-Z]{3}$' OR approved_currency IS NULL OR approved_renewal IS NULL THEN RAISE EXCEPTION 'Invalid subscription details'; END IF;
INSERT INTO public.subscriptions(user_id,name,amount,currency,frequency,next_renewal,category,active) VALUES(auth.uid(),trim(approved_name),approved_amount,approved_currency,approved_frequency,approved_renewal,'other',true) RETURNING id INTO new_id;
UPDATE public.subscription_suggestions SET status='approved',subscription_id=new_id WHERE id=suggestion.id;
INSERT INTO public.activity_logs(user_id,action,entity_type,title,entity_id) VALUES(auth.uid(),'created','subscription',trim(approved_name),new_id);
RETURN new_id;
END; $$;
REVOKE ALL ON FUNCTION public.approve_subscription_suggestion(uuid,text,numeric,text,text,date) FROM PUBLIC,anon; GRANT EXECUTE ON FUNCTION public.approve_subscription_suggestion(uuid,text,numeric,text,text,date) TO authenticated;