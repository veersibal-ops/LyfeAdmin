create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text check (char_length(full_name) <= 100),
  phone text check (char_length(phone) <= 30),
  timezone text default 'UTC',
  focus_areas text[] not null default '{}',
  onboarded boolean not null default false,
  notify_email boolean not null default true,
  notify_push boolean not null default false,
  notify_lead_minutes integer not null default 60,
  theme text not null default 'light' check (theme in ('light','dark','system')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select, insert, update on public.profiles to authenticated;
grant all on public.profiles to service_role;
alter table public.profiles enable row level security;
create policy "own profile select" on public.profiles for select to authenticated using (auth.uid() = id);
create policy "own profile insert" on public.profiles for insert to authenticated with check (auth.uid() = id);
create policy "own profile update" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, full_name) values (new.id, coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name'))
  on conflict (id) do nothing;
  return new;
end; $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

create or replace function public.touch_updated_at() returns trigger language plpgsql set search_path = public as $$
begin new.updated_at = now(); return new; end; $$;
create trigger profiles_touch before update on public.profiles for each row execute function public.touch_updated_at();

create table public.reminders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid(),
  title text not null check (char_length(title) between 1 and 200),
  description text check (char_length(description) <= 2000),
  category text not null default 'general' check (category in ('appointment','personal','bill','important_date','general')),
  due_at timestamptz not null,
  completed boolean not null default false,
  completed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index on public.reminders(user_id, due_at);

create table public.documents (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid(),
  title text not null check (char_length(title) between 1 and 200),
  description text check (char_length(description) <= 2000),
  category text not null default 'other' check (category in ('receipt','warranty','personal','household','other')),
  file_path text not null,
  file_name text not null,
  mime_type text,
  size_bytes bigint,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index on public.documents(user_id, created_at desc);

create table public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid(),
  name text not null check (char_length(name) between 1 and 120),
  amount numeric(12,2) not null check (amount >= 0),
  currency text not null default 'AUD',
  frequency text not null default 'monthly' check (frequency in ('weekly','monthly','quarterly','yearly')),
  next_renewal date not null,
  category text not null default 'other' check (category in ('entertainment','utilities','software','health','food','insurance','other')),
  active boolean not null default true,
  notes text check (char_length(notes) <= 1000),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.checklists (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid(),
  title text not null check (char_length(title) between 1 and 150),
  category text not null default 'general' check (category in ('shopping','holiday','moving','cleaning','general','event')),
  is_template boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.checklist_items (
  id uuid primary key default gen_random_uuid(),
  checklist_id uuid not null references public.checklists(id) on delete cascade,
  user_id uuid not null default auth.uid(),
  content text not null check (char_length(content) between 1 and 300),
  completed boolean not null default false,
  position integer not null default 0,
  created_at timestamptz not null default now()
);
create index on public.checklist_items(checklist_id, position);

create table public.activity_logs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid(),
  action text not null check (action in ('created','updated','completed','deleted','uploaded')),
  entity_type text not null,
  entity_id uuid,
  title text not null,
  created_at timestamptz not null default now()
);
create index on public.activity_logs(user_id, created_at desc);

create table public.chat_threads (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid(),
  title text not null default 'New conversation',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table public.chat_messages (
  id uuid primary key default gen_random_uuid(),
  thread_id uuid not null references public.chat_threads(id) on delete cascade,
  user_id uuid not null default auth.uid(),
  role text not null check (role in ('user','assistant')),
  content text not null,
  created_at timestamptz not null default now()
);
create index on public.chat_messages(thread_id, created_at);

do $$ declare t text; begin
  foreach t in array array['reminders','documents','subscriptions','checklists','checklist_items','activity_logs','chat_threads','chat_messages'] loop
    execute format('grant select, insert, update, delete on public.%I to authenticated', t);
    execute format('grant all on public.%I to service_role', t);
    execute format('alter table public.%I enable row level security', t);
    execute format('create policy "own select" on public.%I for select to authenticated using (auth.uid() = user_id)', t);
    execute format('create policy "own insert" on public.%I for insert to authenticated with check (auth.uid() = user_id)', t);
    execute format('create policy "own update" on public.%I for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id)', t);
    execute format('create policy "own delete" on public.%I for delete to authenticated using (auth.uid() = user_id)', t);
  end loop;
  foreach t in array array['reminders','documents','subscriptions','checklists','chat_threads'] loop
    execute format('create trigger %I before update on public.%I for each row execute function public.touch_updated_at()', t || '_touch', t);
  end loop;
end $$;

-- items must belong to a checklist the user owns
create or replace function public.check_item_owner() returns trigger language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from public.checklists c where c.id = new.checklist_id and c.user_id = new.user_id) then
    raise exception 'Checklist not found';
  end if;
  return new;
end; $$;
create trigger checklist_items_owner before insert or update on public.checklist_items for each row execute function public.check_item_owner();

create or replace function public.check_msg_owner() returns trigger language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from public.chat_threads c where c.id = new.thread_id and c.user_id = new.user_id) then
    raise exception 'Conversation not found';
  end if;
  return new;
end; $$;
create trigger chat_messages_owner before insert or update on public.chat_messages for each row execute function public.check_msg_owner();

-- private document storage policies (bucket created separately)
create policy "own docs read" on storage.objects for select to authenticated using (bucket_id = 'documents' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "own docs insert" on storage.objects for insert to authenticated with check (bucket_id = 'documents' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "own docs update" on storage.objects for update to authenticated using (bucket_id = 'documents' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "own docs delete" on storage.objects for delete to authenticated using (bucket_id = 'documents' and (storage.foldername(name))[1] = auth.uid()::text);